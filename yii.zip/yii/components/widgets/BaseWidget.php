<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace components\widgets;

use yii\base\Widget;


class BaseWidget extends Widget
{
	public $params=[];
	
	
}
