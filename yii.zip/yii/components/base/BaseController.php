<?php

namespace components\base;

use app\models\WwdDealLoanType;
use app\models\WwdNav;
use Yii;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\web\NotFoundHttpException;
use components\LuLu;
use yii\base\InvalidParamException;

/**
 * Site controller
 */
class BaseController extends Controller
{
    public $viewParam = [];   //视图用来传递参数变量数组
    public function init()
    {
        parent::init();
    }

    public function noPermission()
    {
        return 'no permission';
    }

    public function actionView($id)
    {
        $locals = [];
        $locals['model'] = $this->findModel($id);

        return $this->render('view', $locals);
    }

    protected function findModel($id)
    {
        throw new NotFoundHttpException('The requested page does not exist.');
    }
}
