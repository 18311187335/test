<?php

namespace components\base;

use Yii;
use yii\base\Model;
use yii\base\Module;

/**
 * Site controller
 */
class BaseModule extends Module
{
}
