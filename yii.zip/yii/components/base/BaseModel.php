<?php

namespace components\base;

use Yii;
use yii\base\Model;

/**
 * Site controller
 */
class BaseModel extends Model
{
}
