<?php

namespace frontend\base;

use app\models\WwdActiveAwardLog;
use app\models\WwdDeal;
use app\models\WwdDealInrepayRepay;
use app\models\WwdDealLoad;
use app\models\WwdDealLoadRepay;
use app\models\WwdDealLoanType;
use app\models\WwdDealMsgList;
use app\models\WwdDealOrder;
use app\models\WwdDealRepay;
use app\models\WwdMessage;
use app\models\WwdMsgBox;
use app\models\WwdNav;
use app\models\WwdRegionConf;
use app\models\WwdUser;
use app\models\WwdUserCarry;
use app\models\WwdUserLevel;
use app\models\WwdUserLog;
use app\models\WwdUserPointLog;
use common\includes\CommonUtility;
use Yii;
use components\base\BaseController;
use yii\data\Pagination;
use yii\web\Response;

class BaseFrontController extends BaseController
{
    public $uinfo;
    public $cache;
    public function init(){
        parent::init();
        $this->cache = Yii::$app->getCache();
        $this->uinfo = Yii::$app->user->getIdentity();
        $navs = WwdNav::find()->where(['pid'=>0,'is_effect'=>1])->orderBy('sort desc')->all();
        Yii::$app->view->params['navDatas'] = $navs;
    }
    //获取指定标信息
    public function getDealInfoByDealId($dealId){
        return WwdDeal::findOne(['id'=>$dealId]);
    }
    //获取指定用户投标的次数
    public function getUserLoadCountByUid($dealid,$uid){
        return WwdDealLoad::find()->where(['deal_id'=>$dealid,'user_id'=>$uid])->count();
    }
    //获取标类别
    public function getLoadType(){
        $dealTypes =  WwdDealLoanType::find()->where(['is_delete'=>0,'is_effect'=>1])->orderBy('sort')->all();
        return $dealTypes;
    }
    //显示并跳转
    public function showAlert($url,$title,$msg){
        Yii::$app->getSession()->setFlash('tip', ['type' => 'warning',
            'duration' => 2000,
            'icon' => 'fa fa-users',
            'message' => $msg,
            'title' => $title,
            'positonY' => 'top',
            'positonX' => 'left']);
        $this->redirect($url);
    }

    /**
     * 会员资金积分变化操作函数
     * @param array $data 包括 score,money,point
     * @param integer $user_id
     * @param string $log_msg 日志内容
     */
    public function modify_account($data,$user_id,$log_msg='')
    {
        $user_info = WwdUser::findOne(['id'=>$user_id]);
        if(intval($data['score'])!=0)
        {
            WwdUser::updateAllCounters(['score'=>intval($data['score'])],['id'=>$user_id]);
        }
        if(intval($data['point'])!=0)
        {
            WwdUser::updateAllCounters(['point'=>intval($data['point'])],['id'=>$user_id]);
        }
        if(floatval($data['money'])!=0)
        {
            WwdUser::updateAllCounters(['money'=>floatval($data['money'])],['id'=>$user_id]);
        }
        if(floatval($data['coupon'])!=0)
        {
            WwdUser::updateAllCounters(['coupon'=>floatval($data['coupon'])],['id'=>$user_id]);
        }

        if(floatval($data['quota'])!=0)
        {
            WwdUser::updateAllCounters(['quota'=>floatval($data['quota'])],['id'=>$user_id]);
        }

        if(floatval($data['lock_money'])!=0)
        {
            if(($user_info->money-floatval($data['lock_money'])<0) && $user_info->money-floatval($data['lock_money'])>=-0.005){
                WwdUser::updateAll(['money'=>0],['id'=>$user_id]);
                $userObj = WwdUser::findOne(['id'=>$user_id]);
                $userObj->updateCounters(['lock_money' => floatval($data['lock_money'])]);
            }else{
                $userObj = WwdUser::findOne(['id'=>$user_id]);
                $userObj->updateCounters(['lock_money' => floatval($data['lock_money'])]);
                $userObj->updateCounters(['money' => -floatval($data['lock_money'])]);
            }
            $data['money'] = $data['money'] - $data['lock_money'];
        }

        if(intval($data['score'])!=0||floatval($data['money'])!=0||intval($data['point'])!=0||floatval($data['quota'])!=0 || floatval($data['lock_money']) != 0)
        {
            $userLogModel = new WwdUserLog();
            $userLogModel->log_info = $log_msg;
            $userLogModel->log_time = time();

            $session = Yii::$app->getSession();
            $adm_session = $session->get(md5(Yii::$app->params['AUTH_KEY']));
            $adm_id = intval($adm_session['adm_id']);
            if(isset($adm_session['adm_id']) && $adm_id = intval($adm_session['adm_id'])){
                $userLogModel->log_admin_id = $adm_id;
            } else {
                $userLogModel->log_user_id = $user_id;
            }
            $userLogModel->money = floatval($data['money']);
            $userLogModel->score = floatval($data['score']);
            $userLogModel->point = floatval($data['point']);
            $userLogModel->quota = floatval($data['quota']);
            $userLogModel->lock_money = floatval($data['lock_money']);
            $userLogModel->user_id = $user_id;
            $userLogModel->insert();
        }
    }
    //更新用户统计   [需要优化]
    public function sys_user_status($user_id, $is_cache = false, $make_cache = false)
    {
        if ($user_id == 0){
            return;
        }
        $data = false;
        if ($make_cache == false) {
            if ($is_cache == true) {
                $key = md5("USER_STATICS_" . $user_id);
                $data = $this->cache->get($key);
            }
        }
        if ($data == false) {
            //留言数
            $data['dp_count'] = WwdMessage::find()->where(['user_id'=>$user_id,'is_effect'=>1])->count();
            //总借款额
            $data['borrow_amount'] = WwdDeal::find()->where(['user_id'=>$user_id,'publish_wait'=>0])->andWhere(['in','deal_status',[4,5]])->sum('borrow_amount');
            //已还本息
            $data['repay_amount'] = WwdDealRepay::find()->where(['user_id'=>$user_id])->sum('repay_money');

            //发布借款笔数
            $data['deal_count'] = WwdDeal::find()->where(['user_id'=>$user_id,'publish_wait'=>0])->count();
            //成功借款笔数
            $data['success_deal_count'] = WwdDeal::find()->where(['user_id'=>$user_id,'publish_wait'=>0])->andWhere(['in','deal_status',[4,5]])->count();
            //还清笔数
            $data['repay_deal_count'] = WwdDeal::find()->where(['deal_status'=>5,'user_id'=>$user_id,'publish_wait'=>0])->count();
            //未还清笔数
            $data['wh_repay_deal_count'] = $data['success_deal_count'] - $data['repay_deal_count'];
            //提前还清笔数
            $data['tq_repay_deal_count'] = WwdDealInrepayRepay::find()->where(['user_id'=>$user_id])->count();
            //正常还清笔数
            $subquery  = WwdDealInrepayRepay::find()->select('id')->where(['user_id'=>$user_id]);
            $data['zc_repay_deal_count'] = WwdDeal::find()->where(['deal_status'=>5,'user_id'=>$user_id,'publish_wait'=>0])->andWhere(['not in', 'id',$subquery])->count();
            //加权平均借款利率
            $data['avg_rate'] = WwdDeal::find()->where([['in','deal_status',[4,5]],'user_id'=>$user_id,'publish_wait'=>0])->select('sum(rate)/count(*)')->one();
            //平均每笔借款金额
            $data['avg_borrow_amount'] = $data['borrow_amount'] / $data['success_deal_count'];

            //逾期本息
            $data['yuqi_amount'] = WwdDealRepay::find()->where(['user_id'=>$user_id])->andWhere(['in','status',[2,3]])->select("(sum(repay_money) + sum(impose_money)) as new_amount")->one();
            //逾期费用
            $data['yuqi_impose'] = WwdDealRepay::find()->where(['user_id'=>$user_id])->andWhere(['in','status',[2,3]])->sum('repay_money');

            //逾期次数
            $data['yuqi_count'] = WwdDealRepay::find()->where(['user_id'=>$user_id,'status'=>2])->count();
            //严重逾期次数
            $data['yz_yuqi_count'] = WwdDealRepay::find()->where(['user_id'=>$user_id,'status'=>3])->count();

            //待还本息
            $data['need_repay_amount'] = 0;
            //待还管理费
            $data['need_manage_amount'] = 0;
            $deals = WwdDeal::find()->where(['user_id'=>$user_id,'publish_wait'=>0])->andWhere(['in','deal_status',[4,5]])->select('id');
            if ($deals) {
                require_once APP_ROOT_PATH . "app/Lib/deal.php";
                foreach ($deals as $k => $v) {
                    $deal = get_deal($v['id']);
                    $loan = get_deal_load_list($deal);
                    foreach ($loan as $kk => $vv) {
                        if ($vv['status'] == 0) {
                            $data['need_repay_amount'] += $vv['month_repay_money'];
                            $data['need_manage_amount'] += $vv['month_manage_money'];
                        }
                    }
                }
            }


            $load_info = $GLOBALS['db']->getRow("SELECT (sum(repay_money)-sum(self_money)) as load_earnings,sum(repay_money) AS load_repay_money FROM " . DB_PREFIX . "deal_load_repay WHERE user_id=$user_id");
            //已赚利息
            $data['load_earnings'] = $load_info['load_earnings'];
            //已回收本息
            $data['load_repay_money'] = $load_info['load_repay_money'];

            //已赚提前还款违约金
            $data['load_tq_impose'] = $GLOBALS['db']->getOne("SELECT sum(impose_money) FROM " . DB_PREFIX . "deal_load_repay use index(idx_1) WHERE status = 0 AND user_id=$user_id");
            //已赚逾期罚息
            $data['load_yq_impose'] = $GLOBALS['db']->getOne("SELECT sum(impose_money) FROM " . DB_PREFIX . "deal_load_repay use index(idx_1) WHERE status in (2,3) AND user_id=$user_id");

            //借出加权平均收益率
            $data['load_avg_rate'] = $GLOBALS['db']->getOne("SELECT sum(rate)/count(*) FROM " . DB_PREFIX . "deal_load dl LEFT JOIN " . DB_PREFIX . "deal d ON d.id=dl.deal_id WHERE d.deal_status in(4,5) AND dl.user_id=$user_id");

            //总借出笔数
            $u_load = $GLOBALS['db']->getRow("SELECT count(*) as load_count,sum(dl.money) as load_money FROM " . DB_PREFIX . "deal_load dl LEFT JOIN " . DB_PREFIX . "deal d ON d.id=dl.deal_id WHERE d.deal_status in(4,5) AND dl.user_id=$user_id");
            $data['load_count'] = $u_load['load_count'];
            //总借出金额
            $data['load_money'] = $u_load['load_money'];


            //已回收笔数
            $data['reback_load_count'] = $GLOBALS['db']->getOne("SELECT count(*)  FROM " . DB_PREFIX . "deal_load dl LEFT JOIN " . DB_PREFIX . "deal d ON d.id=dl.deal_id WHERE d.deal_status =5 AND dl.user_id=$user_id");
            //待回收笔数
            $data['wait_reback_load_count'] = $data['load_count'] - $data['reback_load_count'];

            //待回收本息
            $data['load_wait_repay_money'] = 0;
            //获取跟用户相关的还款中的标

            //全部需回收的本息
            $all_load_wait_repay_money = 0;
            $user_loads = $GLOBALS['db']->getAll("SELECT dl.id,dl.money,d.repay_time_type,d.loantype,d.repay_time,d.rate FROM " . DB_PREFIX . "deal_load dl LEFT JOIN " . DB_PREFIX . "deal d ON d.id=dl.deal_id WHERE dl.is_repay=0 and dl.user_id =$user_id AND  d.deal_status = 4 and d.is_delete = 0 and d.is_effect=1 and d.publish_wait =0  ");
            foreach ($user_loads as $k => $v) {
                switch (intval($v['loantype'])) {
                    case  0 :
                        //等额本息
                        $all_load_wait_repay_money += pl_it_formula($v['money'], $v['rate'] / 12 / 100, $v['repay_time']) * $v['repay_time'];
                        break;
                    case  1 :
                        //付息还本
                        $all_load_wait_repay_money += $v['money'] + av_it_formula($v['money'], $v['rate'] / 12 / 100) * $v['repay_time'];
                        break;
                    case  2 :
                        //到期本息
                        if (intval($v['repay_time_type']) == 0)
                            $v['repay_time'] = 1;
                        $all_load_wait_repay_money += $v['money'] + $v['money'] * $v['rate'] / 12 / 100 * $v['repay_time'];
                        break;
                }
            }

            //已回收的
            $load_repay_money = $GLOBALS['db']->getOne("SELECT sum(repay_money) AS load_repay_money FROM " . DB_PREFIX . "deal_load_repay WHERE user_id=$user_id AND deal_id in (SELECT id FROM " . DB_PREFIX . "deal WHERE deal_status =4 and is_delete=0 and is_effect=1  and publish_wait=0 )");
            $data['load_wait_repay_money'] = round($all_load_wait_repay_money, 2) - round($load_repay_money, 2);

            if ($GLOBALS['db']->getOne("SELECT count(*) FROM " . DB_PREFIX . "user_sta WHERE user_id=" . $user_id) > 0)
                $GLOBALS['db']->autoExecute(DB_PREFIX . "user_sta", $data, "UPDATE", "user_id=" . $user_id);
            else {
                $data['user_id'] = $user_id;
                $GLOBALS['db']->autoExecute(DB_PREFIX . "user_sta", $data, "INSERT");
            }

            if ($data['deal_count'] > 0 || $data['load_count']) {
                if ($data['deal_count'] > 0)
                    $u_data['is_borrow_in'] = 1;
                if ($data['load_count'] > 0)
                    $u_data['is_borrow_out'] = 1;
                $GLOBALS['db']->autoExecute(DB_PREFIX . "user", $u_data, "UPDATE", "id=" . $user_id);
            }
            if ($is_cache == true || $make_cache == true) {
                $this->cache->set($key, $data);
            }
        }
        return $data;
    }
    //获得GMT的秒数
    protected function get_gmtime(){
        return time() - date('Z');
    }
    //还原格式化时间
    protected function to_date($utc_time, $format = 'Y-m-d H:i:s'){
        return CommonUtility::to_date($utc_time,$format);
    }
    //还原格式化后的时间戳
    protected function to_timespan($str, $format = 'Y-m-d H:i:s'){
        return CommonUtility::to_timespan($str,$format);
    }
    //下个月时间戳
    protected function next_replay_month($time){
        return $this->to_timespan(date("Y-m-d", strtotime('+1 month',$time)), "Y-m-d");
    }
    /**
     * 等额本息还款计算方式
     * $money 贷款金额
     * $rate 月利率
     * $remoth 还几个月
     * 返回  每月还款额
     */
    protected function pl_it_formula($money, $rate, $remoth){
        return CommonUtility::pl_it_formula($money,$rate,$remoth);
    }

    /**
     * 按月还款计算方式
     * $total_money 贷款金额
     * $rate 年利率
     * 返回月应该还多少利息
     */
    protected function av_it_formula($total_money, $rate)
    {
        return CommonUtility::av_it_formula($total_money,$rate);
    }

    /**
     * 等额本息还款计算方式
     * $money 贷款金额
     * $rate 日利率
     * $remoth 还几天
     * 返回  每月还款额
     */
    protected function pl_it_formula_day($money, $rate, $remoth)
    {
        return CommonUtility::pl_it_formula_day($money,$rate,$remoth);
    }

    /**
     * 按月还款计算方式
     * $total_money 贷款金额
     * $rate 日利率
     * 返回月应该还多少利息
     */
    protected function av_it_formula_day($total_money, $rate, $day)
    {
        return CommonUtility::av_it_formula_day($total_money,$rate,$day);
    }
     /**
     * 还款列表
     */
    public function get_deal_load_list($deal){
         $loan_list = [];
         $time = $this->get_gmtime();
         $true_repay_time = $deal['repay_time'];

        //当为天的时候
        //if($deal['repay_time_type'] == 0){
            // 合并1
            /*$last_repay_time = $deal['repay_start_time'] + 86400*$deal['repay_time'];
            $repay_start_time = $deal['repay_start_time'];
            for($i=0;$i<$deal['repay_time'];$i++){
                $repay_start_time = $this->next_replay_month($repay_start_time);
                if($repay_start_time > $last_repay_time){
                    break;
                }
            }
            $true_repay_time = $i+1;*/
            // 合并1

            /*$r_y = $this->to_date($deal['repay_start_time'],"Y");
            $r_m = $this->to_date($deal['repay_start_time'],"m");
            $r_d = $this->to_date($deal['repay_start_time'],"d");
            if($r_m-1 <=0){
                $r_m = 12;
                $r_y = $r_y-1;
            }
            else{
                $r_m = $r_m - 1;
            }*/

            //$deal["repay_start_time"]  = to_timespan($r_y."-".$r_m."-".$r_d,"Y-m-d") + $deal['repay_time']*24*3600;
        //}

        $repay_day = $deal['repay_start_time'];
        if($deal['repay_time_type'] == 0){////按日计息
            //$repay_start_time = $repay_day;
            // 合并1
            $last_repay_time = $deal['repay_start_time'] + 86400 * $deal['repay_time']; //开始还款到还款完成的时间
            $repay_start_time = $deal['repay_start_time'];
            for($i=0;$i<$deal['repay_time'];$i++){
                $repay_start_time = $this->next_replay_month($repay_start_time);             //利用开始还款时间进行累加处理
                if($repay_start_time > $last_repay_time){
                    break;
                }
            }
            $true_repay_time = $i+1;        //实际还款月数？
            // 合并1

            //总的必须还多少本息
            //本额等息
            if($deal['loantype'] == 0){
                $deal['remain_repay_money'] = $deal['borrow_amount'] + round($this->pl_it_formula_day($deal['borrow_amount'],$deal['rate']/100/365,$deal['repay_time']),2);
            }else{
                if($deal['loantype']==1){
                    //每月还息，到期还本
                    $deal['remain_repay_money'] = $deal['borrow_amount'] + round($this->av_it_formula_day($deal['borrow_amount'],$deal['rate']/100/365,$deal['repay_time']),2);
                }else{
                    $repay_time = intval(($this->get_gmtime()-$deal['repay_start_time'])/86400);
                    if($repay_time > $deal['repay_time']){
                        $repay_time = $deal['repay_time'];
                    }
                    //每月还息，到期还本
                    $deal['remain_repay_money'] = $deal['borrow_amount'] + round($this->av_it_formula_day($deal['borrow_amount'],$deal['rate']/100/365,$repay_time),2);
                }
            }

            $remain_repay_money = $deal['remain_repay_money'];
            $remail_repay_amount = $deal['borrow_amount'];
            for($i=0;$i<$true_repay_time;$i++){         //处理实际月数？
                $loan_list[$i]['impose_day'] = 0;
                /**
                 * status 1提前,2准时还款，3逾期还款 4严重逾期
                 */
                $loan_list[$i]['status'] = 0;
                $pre_repay_day = $repay_day;
                $repay_day = $loan_list[$i]['repay_day'] = $this->next_replay_month($repay_day); //返回时间戳

                if($i+1 == $true_repay_time){ //循环最后一次处理
                    $repay_day = $last_repay_time;               //处理repay_day
                    $loan_list[$i]['repay_day'] = $repay_day;
                }

                $days = ($repay_day - $pre_repay_day)/86400;   //实时还款时间 - 开始预期还款时间 =  还款天数差值
                //月还本息
                if($deal['loantype'] == 2){
                    $loan_list[$i]['month_repay_money'] = 0;
                }elseif($deal['loantype'] == 1){
                    $loan_list[$i]['month_repay_money'] = $this->av_it_formula_day($deal['borrow_amount'],$deal['rate']/100/365,$days);
                }else{
                    $loan_list[$i]['month_repay_money'] = round($remail_repay_amount/$deal['repay_time']*$days,2);
                }

                //最后一个月还本息 确定是月?
                if($i+1 == $true_repay_time){ //循环最后一次处理
                    $loan_list[$i]['month_repay_money'] = $remain_repay_money;
                }else{
                    $remain_repay_money -= $loan_list[$i]['month_repay_money'];
                }

                //判断是否已经还完
                $repay_item = WwdDealRepay::find()->where(['deal_id'=>$deal['id'],'repay_time'=>$repay_day])->one();
                $loan_list[$i]['true_repay_time'] = 0;
                //已还
                $loan_list[$i]['month_has_repay_money'] = 0;
                if($repay_item){
                    $loan_list[$i]['true_repay_time'] = $repay_item->true_repay_time;
                    $loan_list[$i]['month_has_repay_money'] = $repay_item->repay_money;
                    $loan_list[$i]['month_manage_money'] = 0;

                    $loan_list[$i]['has_repay'] = 1;
                    $loan_list[$i]['status'] = $repay_item->status+1;
                    $loan_list[$i]['month_repay_money'] -=$loan_list[$i]['repay_money'];
                    $loan_list[$i]['impose_money'] = $repay_item->impose_money;

                    //真实还多少
                    $loan_list[$i]['month_has_repay_money_all'] = $loan_list[$i]['month_has_repay_money'] + $deal['month_manage_money']+$loan_list[$i]['impose_money'];

                    //总的必须还多少
                    $loan_list[$i]['month_need_all_repay_money'] = 0;
                }else{
                    //管理费
                    if($deal['loantype'] == 2)
                    {
                        $loan_list[$i]['month_manage_money'] = 0;
                        if($i+1 == $true_repay_time){  //最后一个月处理
                            $loan_list[$i]['month_manage_money'] = $deal['borrow_amount']* trim(Yii::$app->params['MANAGE_FEE']) /100 * $true_repay_time;
                        }
                    }else{
                        $loan_list[$i]['month_manage_money'] = $deal['borrow_amount']* trim(Yii::$app->params['MANAGE_FEE']) /100;
                    }
                    //判断是否罚息
                    if($time > ($repay_day + 23*3600 + 59*60 + 59+86400)&& $loan_list[$i]['month_repay_money'] > 0){
                        //晚多少天
                        $loan_list[$i]['status'] = 3;
                        $time_span = $this->to_timespan($this->to_date($time-86400,"Y-m-d"),"Y-m-d");
                        $next_time_span = $this->to_timespan($this->to_date($repay_day,"Y-m-d"),"Y-m-d");
                        $day  = ceil(($time_span-$next_time_span)/24/3600);

                        $loan_list[$i]['impose_day'] = $day;

                        $impose_fee = trim(Yii::$app->params['IMPOSE_FEE_DAY1']);
                        //$manage_impose_fee = trim(Yii::$app->params['MANAGE_IMPOSE_FEE_DAY1']);
                        if($day > 31){
                            $loan_list[$i]['status'] = 4;
                            $impose_fee = trim(Yii::$app->params['IMPOSE_FEE_DAY2']);
                            //$manage_impose_fee = trim(Yii::$app->params['MANAGE_IMPOSE_FEE_DAY2']);
                        }

                        //罚息
                        if($deal['loantype'] == 0){
                            $loan_list[$i]['impose_money'] = $loan_list[$i]['month_repay_money']*$impose_fee*$day/100;
                        }elseif($deal['loantype'] == 1){//每月还息，到期还本
                            if($i+1 == $true_repay_time){
                                $loan_list[$i]['impose_money'] = ($deal['borrow_amount'] + $deal['borrow_amount'] * $deal['rate']/12/100)*$impose_fee*$day/100;
                            }else{
                                $loan_list[$i]['impose_money'] = ($deal['borrow_amount'] * $deal['rate']/12/100)*$impose_fee*$day/100;
                            }
                        }elseif($deal['loantype'] == 2){
                            //到期还款 只有最后一个月超出才罚息
                            if($i+1 == $true_repay_time){
                                $loan_list[$i]['impose_money'] = $loan_list[$i]['month_repay_money']*$impose_fee*$day/100;
                            } else {
                                $loan_list[$i]['impose_money'] = 0;
                            }
                        }
                        //罚管理费
                        //$loan_list[$i]['impose_money'] += $loan_list[$i]['month_repay_money']*$manage_impose_fee*$day/100;
                    }
                    //总的必须还多少
                    $loan_list[$i]['month_need_all_repay_money'] =  round($loan_list[$i]['month_repay_money'],2) + round($loan_list[$i]['month_manage_money'],2) + round($loan_list[$i]['impose_money'],2);
                }
                $repay_item_site = WwdDealLoadRepay::find()->where(['deal_id'=>$deal['id'],'repay_time'=>$repay_day,'status'=>4])->one();
                if($repay_item_site){
                    $loan_list[$i]['status'] = 5;
                    $loan_list[$i]['true_repay_time'] = $repay_item_site->true_repay_time;
                }
            }
        }else{ //按月
            for($i=0;$i<$true_repay_time;$i++){
                $loan_list[$i]['impose_day'] = 0;
                /**
                 * status 1提前,2准时还款，3逾期还款 4严重逾期
                 */
                $loan_list[$i]['status'] = 0;
                $repay_day = $loan_list[$i]['repay_day'] = $this->next_replay_month($repay_day);
                //月还本息
                if($deal['loantype'] == 2){
                    $loan_list[$i]['month_repay_money'] = 0;
                } else{
                    $loan_list[$i]['month_repay_money'] = $deal['month_repay_money'];
                }
                //最后一个月还本息
                if($i+1 == $true_repay_time){
                    $loan_list[$i]['month_repay_money'] = $deal['last_month_repay_money'];
                }

                //判断是否已经还完
                $repay_item = WwdDealRepay::find()->where(['deal_id'=>$deal['id'],'repay_time'=>$repay_day])->one();
                $loan_list[$i]['true_repay_time'] = 0;
                //已还
                $loan_list[$i]['month_has_repay_money'] = 0;
                if($repay_item){
                    $loan_list[$i]['true_repay_time'] = $repay_item->true_repay_time;
                    $loan_list[$i]['month_has_repay_money'] = $repay_item->repay_money;
                    $loan_list[$i]['month_manage_money'] = 0;

                    $loan_list[$i]['has_repay'] = 1;
                    $loan_list[$i]['status'] = $repay_item->status + 1;
                    $loan_list[$i]['month_repay_money'] -=$loan_list[$i]['repay_money'];
                    $loan_list[$i]['impose_money'] = $repay_item->impose_money;

                    //真实还多少
                    $loan_list[$i]['month_has_repay_money_all'] = $loan_list[$i]['month_has_repay_money'] + $deal['month_manage_money']+$loan_list[$i]['impose_money'];

                    //总的必须还多少
                    $loan_list[$i]['month_need_all_repay_money'] = 0;
                } else{
                    //管理费
                    if($deal['loantype'] == 2)
                    {
                        $loan_list[$i]['month_manage_money'] = 0;
                        if($i+1 == $true_repay_time){
                            $loan_list[$i]['month_manage_money'] = $deal['borrow_amount']* trim(Yii::$app->params['MANAGE_FEE']) /100 * $true_repay_time;
                        }
                    } else {
                        $loan_list[$i]['month_manage_money'] = $deal['borrow_amount']* trim(Yii::$app->params['MANAGE_FEE']) /100;
                    }
                    //判断是否罚息
                    if($time > ($repay_day+ 23*3600 + 59*60 + 59+86400)&& $loan_list[$i]['month_repay_money'] > 0){
                        //晚多少天
                        $loan_list[$i]['status'] = 3;
                        $time_span = $this->to_timespan($this->to_date($time-86400,"Y-m-d"),"Y-m-d");
                        $next_time_span = $this->to_timespan($this->to_date($repay_day,"Y-m-d"),"Y-m-d");
                        $day  = ceil(($time_span-$next_time_span)/24/3600);

                        $loan_list[$i]['impose_day'] = $day;

                        $impose_fee = trim(Yii::$app->params['IMPOSE_FEE_DAY1']);
                        //$manage_impose_fee = trim(Yii::$app->params['MANAGE_IMPOSE_FEE_DAY1']);
                        if($day > 31){
                            $loan_list[$i]['status'] = 4;
                            $impose_fee = trim(Yii::$app->params['IMPOSE_FEE_DAY2']);
                            //$manage_impose_fee = trim(Yii::$app->params['MANAGE_IMPOSE_FEE_DAY2']);
                        }

                        //罚息
                        if($deal['loantype'] == 0){
                            $loan_list[$i]['impose_money'] = $loan_list[$i]['month_repay_money']*$impose_fee*$day/100;
                        } elseif ($deal['loantype'] == 1) { //每月还息，到期还本
                            if($i+1 == $true_repay_time){
                                $loan_list[$i]['impose_money'] = ($deal['borrow_amount'] + $deal['borrow_amount'] * $deal['rate']/12/100)*$impose_fee*$day/100;
                            }else{
                                $loan_list[$i]['impose_money'] = ($deal['borrow_amount'] * $deal['rate']/12/100)*$impose_fee*$day/100;
                            }
                        } elseif($deal['loantype'] == 2){
                            //到期还款 只有最后一个月超出才罚息
                            if($i+1 == $true_repay_time)
                                $loan_list[$i]['impose_money'] = $loan_list[$i]['month_repay_money']*$impose_fee*$day/100;
                            else{
                                $loan_list[$i]['impose_money'] = 0;
                            }
                        }
                        //罚管理费
                        //$loan_list[$i]['impose_money'] += $loan_list[$i]['month_repay_money']*$manage_impose_fee*$day/100;
                    }


                    //总的必须还多少
                    $loan_list[$i]['month_need_all_repay_money'] =  round($loan_list[$i]['month_repay_money'],2) + round($loan_list[$i]['month_manage_money'],2) + round($loan_list[$i]['impose_money'],2);
                }
                $repay_item_site = WwdDealLoadRepay::find()->where(['deal_id'=>$deal['id'],'repay_time'=>$repay_day,'status'=>4])->one();
                if($repay_item_site){
                    $loan_list[$i]['status'] = 5;
                    $loan_list[$i]['true_repay_time'] = $repay_item_site['true_repay_time'];
                }
            }
        }

        $load_list = WwdDealLoad::findAll(['deal_id'=>$deal['id']]);
        $success_time = $deal['repay_start_time'];
        $success_date = $this->to_date($success_time,"Y-m-d 00:00:00");
        $success_time = $this->to_timespan($success_date);///满标当天0时时间戳

        $buxi = 0;///补息
        foreach($load_list as $k=>$v){
            $days_time = $success_time - $v['create_time'];
            if($days_time<=0){
                continue;
            }
            $days = ceil($days_time/86400);
            if($deal['loantype']==0){
                $buxi += round($this->pl_it_formula_day($v['money'],$deal['rate']/365/100,$days),2);
            }else{
                $buxi += round($this->av_it_formula_day($v['money'],$deal['rate']/365/100,$days),2);
            }

        }
        if($deal['loantype']==2){
            $loan_list[count($loan_list)-1]['month_repay_money'] += $buxi;
            $loan_list[count($loan_list)-1]['month_need_all_repay_money'] += $buxi;
        }else{
            $loan_list[0]['month_repay_money'] += $buxi;
            $loan_list[0]['month_need_all_repay_money'] += $buxi;
        }

        return $loan_list;
    }
    //获取指定用户的累计收益
    protected function getUserAccumuIncome($user_id){
        /***按天**/
        $total = 0;
        $dealInfo = [];
        $dealLoadRes = WwdDealLoad::find()->where(['user_id'=>$user_id])->all();
        foreach($dealLoadRes as $dr){
            $dealId = $dr['deal_id'];
            if(!isset($dealInfo[$dealId])){
                $dealInfo[$dealId] = WwdDeal::findOne(['id'=>$dealId]);
            }
            $dinfo = $dealInfo[$dealId];
            if($dinfo['deal_status'] >= 4){
                $days = intval(($this->to_timespan($this->to_date($dinfo['repay_start_time'], "Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($dr['create_time'], "Y-m-d 00:00:00"))) / 86400);
                $lixi = round($dr['money'] * $dinfo['rate'] / 100 / 365 * $days, 2);
                if ($lixi < 0) {
                    $lixi = 0;
                }
                if ($dinfo['deal_status'] != 5) {
                    $days = intval(($this->to_timespan($this->to_date($this->get_gmtime(), "Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($dinfo['repay_start_time'], "Y-m-d 00:00:00"))) / 86400);
                } else {
                    $days = intval(($this->to_timespan($this->to_date($dinfo['last_repay_time'], "Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($dinfo['repay_start_time'], "Y-m-d 00:00:00"))) / 86400);
                }

                if ($dinfo['loantype'] == 0) {
                    $repay_money = round($this->pl_it_formula_day($dr['money'], $dinfo['rate'] / 365 / 100, $days), 2);
                } else {
                    $repay_money = round($this->av_it_formula_day($dr['money'], $dinfo['rate'] / 365 / 100, $days), 2);
                }
                $lixi += $repay_money;
            }else{
                $days = intval(($this->to_timespan($this->to_date($this->get_gmtime(), "Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($dr['create_time'], "Y-m-d 00:00:00"))) / 86400);

                $lixi = round($dr['money'] * $dinfo['rate'] / 100 / 365 * $days, 2);
            }
            $total += $lixi;
        }
        /***按天**/
        /***按月**/
        $mlixi = 0;
        $monthLoadRes = WwdDealLoadRepay::find()->where(['user_id'=>$user_id])->all();
        foreach($monthLoadRes as $mr){
            $dealId = $mr['deal_id'];
            if(!$dealInfo[$dealId]){
                $dealInfo[$dealId] = WwdDeal::findOne(['id'=>$dealId]);
            }
            $dinfo = $dealInfo[$dealId];
            if($dinfo['repay_time_type'] === 1){
                $ml = ($mr['repay_money'] - $mr['self_money'] + $mr['impose_money']);
                $mlixi += round(floatval($ml),2);
            }
        }
        /***按月**/
        $invest_money = $total + $mlixi;
        return $invest_money;
    }

    protected function getTotalLixi($user_id){
        $result = WwdDealLoad::getTotalLixi($user_id);
        $total_lixi = 0;
        foreach ($result as $v) {
            $deal = $v['dealinfo'];
            if (!$deal) {
                continue;
            }
            if ($v['deal_status'] >= 4) {
                $success_time = $deal['repay_start_time'];
            } else {
                $success_time = $this->get_gmtime();
            }
            $success_date = $this->to_date($success_time, "Y-m-d 00:00:00");
            $success_time = $this->to_timespan($success_date);///满标当天0时时间戳


            $days_time = $success_time - $v['create_time'];
            if ($days_time <= 0) {
                $days_time = 0;
            }
            $days = ceil($days_time / 86400);
            if ($deal['loantype'] == 0) {
                $buxi = round($this->pl_it_formula_day($v['money'], $deal['rate'] / 365 / 100, $days), 2);
            } else {
                $buxi = round($this->av_it_formula_day($v['money'], $deal['rate'] / 365 / 100, $days), 2);
            }

            if ($deal['repay_time_type'] == 0) {
                if ($deal['deal_status'] >= 4) {
                    $repay_time = intval(($this->get_gmtime() - $v['repay_start_time']) / 86400);
                } else {
                    $repay_time = intval(($this->get_gmtime() - $v['create_time']) / 86400);
                }
                if ($deal['loantype'] == 0) {
                    $total_lixi += $buxi + round($this->pl_it_formula_day($v['money'], $deal['rate'] / 365 / 100, $repay_time), 2);

                } else {
                    $total_lixi += $buxi + round($this->av_it_formula_day($v['money'], $deal['rate'] / 365 / 100, $repay_time), 2);

                }
            } else {
                $total_lixi += $v['money'] * $deal['rate'] / 100 / 12 * $deal['repay_time'];

            }
        }
        return $total_lixi;
    }
    /**
     * 会员信息发送
     *
     * @param $title 标题
     * @param $content 内容
     * @param $from_user_id 发件人
     * @param $to_user_id 收件人
     * @param $create_time 时间
     * @param $sys_msg_id 系统消息ID
     * @param $only_send true为只发送，生成发件数据，不生成收件数据
     * @param $fav_id 相关ID
     */
    protected function send_user_msg($title,$content,$from_user_id,$to_user_id,$create_time,$sys_msg_id=0,$only_send=false,$is_notice = false,$fav_id = 0)
    {
        $group_arr = [$from_user_id,$to_user_id];
        sort($group_arr);
        if($sys_msg_id>0){
            $group_arr[] = $sys_msg_id;
        }
        if($is_notice > 0){
            $group_arr[] = $is_notice;
        }
        $msgboxModel = new WwdMsgBox();
        $msgboxModel->title = $title;
        $msgboxModel->content = addslashes($content);
        $msgboxModel->from_user_id = $from_user_id;
        $msgboxModel->to_user_id = $to_user_id;
        $msgboxModel->create_time = $create_time;
        $msgboxModel->system_msg_id = $sys_msg_id;
        $msgboxModel->type = 0;
        $groupKey = implode("_",$group_arr);
        $msgboxModel->group_key = $groupKey;
        $msgboxModel->is_notice = intval($is_notice);
        $msgboxModel->insert();
        $id = Yii::$app->getDb()->getLastInsertID();
        if($is_notice){
            $msgboxModel = new WwdMsgBox();
            $msgboxModel->updateAll(['group_key'=>$groupKey."_".$id],['id'=>$id]);
        }
        if(!$only_send) {
            $msgboxModel = new WwdMsgBox();
            $msgboxModel->title = $title;
            $msgboxModel->content = addslashes($content);
            $msgboxModel->from_user_id = $from_user_id;
            $msgboxModel->to_user_id = $to_user_id;
            $msgboxModel->create_time = $create_time;
            $msgboxModel->system_msg_id = $sys_msg_id;
            $groupKey = implode("_",$group_arr);
            $msgboxModel->group_key = $groupKey;
            $msgboxModel->is_notice = intval($is_notice);
            $msgboxModel->type = 1; //记录发件
            $msgboxModel->insert();   //原系统是insert，考虑是否为update
        }
    }
    //记录日志
    protected function msgListLog($email,$sType,$title,$content,$send_time,$isSend,$uid,$isHtml){
        $dealMsgListModel = new WwdDealMsgList();
        $dealMsgListModel->dest = $email;
        $dealMsgListModel->send_type = $sType;
        $dealMsgListModel->title = $title;
        $dealMsgListModel->content = addslashes($content);
        $dealMsgListModel->send_time = $send_time;
        $dealMsgListModel->is_send = $isSend;
        $dealMsgListModel->create_time = $this->get_gmtime();
        $dealMsgListModel->user_id = $uid;
        $dealMsgListModel->is_html = $isHtml;
        $dealMsgListModel->insert(); //插入
    }
    //积分日志记录
    protected function pointLog($uid,$atype,$val,$msg){
        $poing_log = new WwdUserPointLog();
        $poing_log->user_id = $uid;
        $poing_log->action_type = $atype;
        $poing_log->value = $val;
        $poing_log->msg = $msg;
        $poing_log->dateline = $this->get_gmtime();
        $ret = $poing_log->insert();
        return $ret;
    }
    //奖励日志
    protected function awardLog($uid,$val){
        $activeAwardModel = new WwdActiveAwardLog();
        $activeAwardModel->user_id = $uid;
        $activeAwardModel->coupon = $val;
        $activeAwardModel->dateline = $this->get_gmtime();
        $activeAwardModel->insert();
    }
    /*
     * 获取post提交数据
     *
     */
    protected function get_post_data($heepay_server, $post_string){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $heepay_server);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
    }

    /**
     * 用户还款列表 [需优化]
     * 1,重复代码
     */
    protected function get_deal_user_load_list($user_load_info,$loantype,$repay_time_type = 1,$deal = array(),$true_time = false){
        $loan_list = [];
        if($true_time!==false){
            $time = $true_time;
        }else{
            $time = $this->get_gmtime();
        }

        $success_time = $deal['repay_start_time'];
        $success_date = $this->to_date($success_time,"Y-m-d 00:00:00");
        $success_time = $this->to_timespan($success_date);///满标当天0时时间戳


        $days_time = $success_time - $user_load_info['create_time'];
        if($days_time<=0){
            $days_time = 0;
        }
        $days = ceil($days_time/86400);
        if($deal['loantype']==0){
            $buxi = round($this->pl_it_formula_day($user_load_info['money'],$deal['rate']/365/100,$days),2);
        }else{
            $buxi = round($this->av_it_formula_day($user_load_info['money'],$deal['rate']/365/100,$days),2);
        }

        //当为天的时候
        if($repay_time_type == 0){
            $true_repay_time = 1;
            if($user_load_info['repay_start_time'] == 0){
                $user_load_info['repay_start_time'] = $this->get_gmtime();
            }
            $last_repay_time = $user_load_info['repay_start_time'] + 86400*$user_load_info['repay_time'];
            $repay_start_time = $user_load_info['repay_start_time'];
            for($i=0;$i<$user_load_info['repay_time'];$i++){
                $repay_start_time = $this->next_replay_month($repay_start_time);
                if($repay_start_time > $last_repay_time){
                    break;
                }
            }
            $true_repay_time = $i+1;

            //总的必须还多少本息
            //本额等息
            if($deal['loantype'] == 0){
                $remain_repay_money = $user_load_info['money'] + round($this->pl_it_formula_day($user_load_info['money'],$deal['rate']/100/365,$deal['repay_time']),2)+$buxi;
            }else{
                if($deal['loantype']==1){
                    //每月还息，到期还本
                    $remain_repay_money = $user_load_info['money'] + round($this->av_it_formula_day($user_load_info['money'],$deal['rate']/100/365,$deal['repay_time']),2)+$buxi;
                }else{
                    $repay_time = intval(($this->get_gmtime()-$deal['repay_start_time'])/86400);
                    if($repay_time > $deal['repay_time']){
                        $repay_time = $deal['repay_time'];
                    }
                    //每月还息，到期还本
                    $remain_repay_money = $user_load_info['money'] + round($this->av_it_formula_day($user_load_info['money'],$deal['rate']/100/365,$repay_time),2)+$buxi;
                }
            }

            $repay_day = $user_load_info['repay_start_time'];
            for($i=0;$i<$true_repay_time;$i++){

                $loan_list[$i]['impose_money'] = 0;

                if($user_load_info['id']){
                    $loan_list[$i]['id'] = $user_load_info['id'];
                }
                /**
                 * status 1提前,2准时还款，3逾期还款 4严重逾期
                 */
                $loan_list[$i]['status'] = 0;
                $pre_repay_day = $repay_day;
                $repay_day = $loan_list[$i]['repay_day'] = $this->next_replay_month($repay_day);

                if($i+1==$true_repay_time){
                    $repay_day = $last_repay_time;
                    $loan_list[$i]['repay_day'] = $repay_day;
                }

                $days = ($repay_day - $pre_repay_day)/86400;

                //月还本息
                if($deal['loantype'] == 2){
                    $loan_list[$i]['month_repay_money'] = 0;
                    $lixi = 0;
                }elseif($deal['loantype'] == 1){
                    $loan_list[$i]['month_repay_money'] = $this->av_it_formula_day($user_load_info['money'],$deal['rate']/100/365,$days);
                    if($i==0){
                        $loan_list[$i]['month_repay_money'] += $buxi;
                    }
                    $lixi = $loan_list[$i]['month_repay_money'];
                }else{
                    $loan_list[$i]['month_repay_money'] = round($user_load_info['money']/$deal['repay_time']*$days,2);
                    if($i==0){
                        $loan_list[$i]['month_repay_money'] += $buxi;
                    }
                }

                //最后一个月还本息
                if($i+1 == $true_repay_time){
                    $loan_list[$i]['month_repay_money'] = $remain_repay_money;
                }else{
                    $remain_repay_money -= $loan_list[$i]['month_repay_money'];
                }

                //判断是否已经还完
                $repay_item = WwdDealLoadRepay::getRepayItem($user_load_info['user_id'],$user_load_info['deal_id'],$repay_day,$i,$user_load_info['u_key']);

                //管理费
                $manageFee = Yii::$app->params['MANAGE_FEE'];
                if($loantype == 2)
                {
                    $loan_list[$i]['month_manage_money'] = 0;
                    if($i+1 == $true_repay_time){
                        $loan_list[$i]['month_manage_money'] = $user_load_info['money']* $manageFee/(100-$manageFee) * $true_repay_time;
                    }
                } else{
                    $loan_list[$i]['month_manage_money'] = $user_load_info['money']* $manageFee/(100-$manageFee);
                }

                //已还
                $loan_list[$i]['month_has_repay_money'] = 0;
                if($repay_item){
                    $loan_list[$i]['true_repay_time'] = $repay_item['true_repay_time'];
                    $loan_list[$i]['month_has_repay_money'] = $repay_item['repay_money'];

                    $loan_list[$i]['has_repay'] = 1;
                    $loan_list[$i]['status'] = $repay_item['status']+1;
                    $loan_list[$i]['month_repay_money'] -=$loan_list[$i]['repay_money'];
                    $loan_list[$i]['impose_money'] = $repay_item['impose_money'];

                    //真实还多少
                    $loan_list[$i]['month_has_repay_money_all'] = $loan_list[$i]['month_has_repay_money'] + $user_load_info['month_manage_money']+$loan_list[$i]['impose_money'];
                }else{
                    //判断是否罚息
                    if($time > ($repay_day + 23*3600 + 59*60 + 59) && $loan_list[$i]['month_repay_money'] > 0){
                        //晚多少天
                        //获得真正的还款
                        $true_time = WwdDealRepay::findOne(['deal_id'=>$user_load_info['deal_id'],'repay_time'=>$repay_day])->true_repay_time;
                        if($true_time == 0){
                            $true_time = $time;
                        }
                        $time_span = $this->to_timespan($this->to_date($true_time-86400,"Y-m-d"),"Y-m-d");
                        $next_time_span = $this->to_timespan($this->to_date($repay_day,"Y-m-d"),"Y-m-d");
                        $day  = ceil(($time_span-$next_time_span)/24/3600);

                        if($day >0){
                            //普通逾期
                            $loan_list[$i]['status'] = 3;
                            $impose_fee = Yii::$app->params['IMPOSE_FEE_DAY1'];
                            if($day > 31){//严重逾期
                                $loan_list[$i]['status'] = 4;
                                $impose_fee = Yii::$app->params['IMPOSE_FEE_DAY2'];
                            }
                            //罚息
                            if($loantype == 0){
                                $loan_list[$i]['impose_money'] = $loan_list[$i]['month_repay_money'] *$impose_fee*$day/100;
                            }elseif($loantype == 1){
                                $loan_list[$i]['impose_money'] = $lixi *$impose_fee*$day/100;
                            }elseif($loantype == 2){
                                $loan_list[$i]['impose_money'] = $lixi *$impose_fee*$day/100;
                            }
                            //罚管理费
                            //$loan_list[$i]['impose_money'] += $loan_list[$i]['month_repay_money']*$manage_impose_fee*$day/100;
                        }else{
                            $loan_list[$i]['has_repay'] = 0;
                        }
                    }
                }
                $loan_list[$i]['month_repay_money'] = round($loan_list[$i]['month_repay_money'],2);
                $loan_list[$i]['month_manage_money'] = round($loan_list[$i]['month_manage_money'],2);
                $loan_list[$i]['impose_money'] = round($loan_list[$i]['impose_money'],2);
            }
        }else{
            $true_repay_time = $user_load_info['repay_time'];
            $repay_day = $user_load_info['repay_start_time'];
            for($i=0;$i<$true_repay_time;$i++){
                $loan_list[$i]['impose_money'] = 0;
                if($user_load_info['id']){
                    $loan_list[$i]['id'] = $user_load_info['id'];
                }
                /**
                 * status 1提前,2准时还款，3逾期还款 4严重逾期
                 */
                $loan_list[$i]['status'] = 0;
                $repay_day = $loan_list[$i]['repay_day'] = $this->next_replay_month($repay_day);

                //月还本息
                if($loantype == 0)
                {
                    $loan_list[$i]['month_repay_money'] = $this->pl_it_formula($user_load_info['money'],$user_load_info['rate']/12/100,$true_repay_time);

                    //第一个月补息
                    if($i==0){
                        $loan_list[$i]['month_repay_money'] += $buxi;
                    }

                    //最后一个月还本息
                    if($i+1 == $true_repay_time){
                        $loan_list[$i]['month_repay_money'] = $loan_list[$i]['month_repay_money']*$true_repay_time - round($loan_list[$i]['month_repay_money'],2)*($true_repay_time-1);
                    }
                }elseif($loantype == 1){
                    $lixi = $loan_list[$i]['month_repay_money'] = $this->av_it_formula($user_load_info['money'],$user_load_info['rate']/12/100);

                    //第一个月补息
                    if($i==0){
                        $loan_list[$i]['month_repay_money'] += $buxi;
                    }

                    //最后一个月还本息
                    if($i+1 == $true_repay_time){
                        $lixi = $loan_list[$i]['month_repay_money'] = ($user_load_info['money'] + $loan_list[$i]['month_repay_money']*$true_repay_time) - round($loan_list[$i]['month_repay_money'],2)*($true_repay_time-1);
                    }
                }elseif($loantype == 2){
                    $lixi = $loan_list[$i]['month_repay_money'] = 0;
                    //最后一个月还本息
                    if($i+1 == $true_repay_time){
                        $lixi = $loan_list[$i]['month_repay_money'] = $user_load_info['money'] + $user_load_info['money']*$user_load_info['rate']/12/100*$true_repay_time + $buxi;
                    }
                }

                //判断是否已经还完
                $repay_item = WwdDealLoadRepay::getRepayItem($user_load_info['user_id'],$user_load_info['deal_id'],$repay_day,$i,$user_load_info['u_key']);

                //管理费
                $manageFee = Yii::$app->params['MANAGE_FEE'];
                if($loantype == 2)
                {
                    $loan_list[$i]['month_manage_money'] = 0;
                    if($i+1 == $true_repay_time){
                        $loan_list[$i]['month_manage_money'] = $user_load_info['money']* $manageFee/(100-$manageFee) * $true_repay_time;
                    }
                } else{
                    $loan_list[$i]['month_manage_money'] = $user_load_info['money']* $manageFee/(100-$manageFee);
                }

                //已还
                $loan_list[$i]['month_has_repay_money'] = 0;
                if($repay_item){
                    $loan_list[$i]['true_repay_time'] = $repay_item['true_repay_time'];
                    $loan_list[$i]['month_has_repay_money'] = $repay_item['repay_money'];

                    $loan_list[$i]['has_repay'] = 1;
                    $loan_list[$i]['status'] = $repay_item['status']+1;
                    $loan_list[$i]['month_repay_money'] -=$loan_list[$i]['repay_money'];
                    $loan_list[$i]['impose_money'] = $repay_item['impose_money'];
                    //真实还多少
                    $loan_list[$i]['month_has_repay_money_all'] = $loan_list[$i]['month_has_repay_money'] + $user_load_info['month_manage_money']+$loan_list[$i]['impose_money'];
                }else{
                    //判断是否罚息
                    if($time > ($repay_day + 23*3600 + 59*60 + 59) && $loan_list[$i]['month_repay_money'] > 0){
                        //晚多少天
                        //获得真正的还款
                        $true_time = WwdDealRepay::findOne(['deal_id'=>$user_load_info['deal_id'],'repay_time'=>$repay_day])->true_repay_time;
                        if($true_time == 0){
                            $true_time = $time;
                        }
                        $time_span = $this->to_timespan($this->to_date($true_time-86400,"Y-m-d"),"Y-m-d");
                        $next_time_span = $this->to_timespan($this->to_date($repay_day,"Y-m-d"),"Y-m-d");
                        $day  = ceil(($time_span-$next_time_span)/24/3600);

                        if($day >0){
                            //普通逾期
                            $loan_list[$i]['status'] = 3;
                            $impose_fee = Yii::$app->params['IMPOSE_FEE_DAY1'];
                            if($day > 31){//严重逾期
                                $loan_list[$i]['status'] = 4;
                                $impose_fee = Yii::$app->params['IMPOSE_FEE_DAY2'];
                            }

                            //罚息
                            if($loantype == 0){
                                $loan_list[$i]['impose_money'] = $loan_list[$i]['month_repay_money'] *$impose_fee*$day/100;
                            }elseif($loantype == 1){
                                $loan_list[$i]['impose_money'] = $lixi *$impose_fee*$day/100;
                            }elseif($loantype == 2){
                                $loan_list[$i]['impose_money'] = $lixi *$impose_fee*$day/100;
                            }
                        }else{
                            $loan_list[$i]['has_repay'] = 0;
                        }
                    }
                }
                $loan_list[$i]['month_repay_money'] = round($loan_list[$i]['month_repay_money'],2);
                $loan_list[$i]['month_manage_money'] = round($loan_list[$i]['month_manage_money'],2);
                $loan_list[$i]['impose_money'] = round($loan_list[$i]['impose_money'],2);
            }
        }
        return $loan_list;
    }
    //交易记录，需要分页
    protected function getlist($mode = "index") {
        $user_id = $this->uinfo['id'];
        if($this->uinfo['is_company'] == 0){
            $query = WwdDealLoad::find()->joinWith('deal')
                ->where([
                    WwdDealLoad::tableName().'.user_id'=>$user_id,
                    WwdDealLoad::tableName().'.is_transfer'=>0,
                    WwdDeal::tableName().'.is_effect' => 1,
                    WwdDeal::tableName().'.is_delete' => 0,
                    WwdDeal::tableName().'.publish_wait'=>0])
                ->andWhere(['in',WwdDeal::tableName().'.deal_status',[1,2,4,5]]);

            $countQuery = clone $query; //优化实例化对象
            $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
            $list = $query->orderBy(WwdDealLoad::tableName().'.create_time desc')
                ->offset($pages->offset)
                ->limit($pages->limit)
                ->all();
            foreach($list as $k=>$v){
                if($v['deal']['repay_time_type'] == 0){
                   //$list[$k]['borrow_amount_format'] = number_format($v['deal']['borrow_amount'],2);
                   //$list[$k]['rate_format'] = number_format($v['deal']['rate'],2);
                    //本息还款金额
                    //$list[$k]['month_repay_money'] = $this->pl_it_formula($v['deal']['borrow_amount'],$v['deal']['rate']/365/100,$v['deal']['repay_time']);
                    //$list[$k]['month_repay_money_format'] =  number_format($list[$k]['month_repay_money'],2);
                    if($v['deal']['deal_status'] == 1){
                        //还需多少钱
                        //$list[$k]['need_money'] = number_format(($v['deal']['borrow_amount'] - $v['deal']['load_money']),2);
                        //百分比
                        //$list[$k]['progress_point'] = $v['deal']['load_money']/$v['deal']['borrow_amount']*100;

                    }elseif($v['deal']['deal_status'] == 2 || $v['deal']['deal_status'] == 5) {
                        //$list[$k]['progress_point'] = 100;
                    }elseif($v['deal']['deal_status'] == 4){
                        //百分比
                        $list[$k]['remain_repay_money'] = $list[$k]['month_repay_money'] * $v['deal']['repay_time'];
                        //还有多少需要还
                        $list[$k]['need_remain_repay_money'] = $list[$k]['remain_repay_money'] - $v['deal']['repay_money'];
                        //还款进度条
                        $list[$k]['progress_point'] =  round($v['repay_money']/$list[$k]['remain_repay_money']*100,2);
                    }
                    $user_location = "";
                    $userCity = WwdRegionConf::findOne(['id'=>$this->uinfo['city_id']]);
                    if($userCity){
                        $user_location = $userCity['name'];
                    }
                    $userProvince = WwdRegionConf::findOne(['id'=>$this->uinfo['province_id']]);
                    if($userProvince){
                        $user_location = $userProvince['name'];
                    }

                    //$list[$k]['user_location'] = $user_location;
                    $levelRes = WwdUserLevel::findOne(['id'=>$this->uinfo['level_id']]);
                    if($levelRes){
                        $list[$k]['point_level']  = $levelRes['name'];
                    }

                    /*if($v['deal']['deal_status']==4 || $v['deal']['deal_status']==5){
                        $last_month_time = $v['deal']['repay_start_time'];
                        $last_month_time = $last_month_time + 86400 * $v['deal']['repay_time'];
                    }*/

                    $deal = $v->deal; //关联查询
                    if($deal['deal_status']>=4){
                        //用户回款
                        $user_load_ids = WwdDealLoad::findAll(['id'=>$v['id']]);
                        foreach($user_load_ids as $kk=>$vv){
                            /*$vv['repay_start_time'] = $deal['repay_start_time'];
                            $vv['repay_time'] = $deal['repay_time'];
                            $vv['rate'] = $deal['rate'];
                            $vv['u_key'] = $kk;*/
                            $days = intval(($this->to_timespan($this->to_date($deal['repay_start_time'],"Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($v['create_time'],"Y-m-d 00:00:00")))/86400);
                            $lixi = $v['money']*$deal['rate']/100/365*$days;
                            if($lixi<0){
                                $lixi = 0;
                            }
                            if($deal['deal_status']!=5){
                                $days = intval(($this->to_timespan($this->to_date($this->get_gmtime(),"Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($deal['repay_start_time'],"Y-m-d 00:00:00")))/86400);
                            }else{
                                $days = intval(($this->to_timespan($this->to_date($deal['last_repay_time'],"Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($deal['repay_start_time'],"Y-m-d 00:00:00")))/86400);
                            }

                            if($deal['loantype']==0){
                                $repay_money = round($this->pl_it_formula_day($vv['money'],$deal['rate']/365/100,$days),2);
                            }else{
                                $repay_money = round($this->av_it_formula_day($vv['money'],$deal['rate']/365/100,$days),2);
                            }
                            $lixi += $repay_money;
                        }
                    }else{
                        $days = intval(($this->to_timespan($this->to_date($this->get_gmtime(),"Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($v['dltime'],"Y-m-d 00:00:00")))/86400);
                        $lixi = $v['u_load_money']*$deal['rate']/100/365*$days;
                    }
                    $more_list_money = $lixi;
                    //$list[$k]['last_month_time'] = $last_month_time;
                    $list[$k]['more_list_money'] = $more_list_money;
                }else{
                    $list[$k]['borrow_amount_format'] = number_format($v['borrow_amount'],2);
                    $list[$k]['rate_format'] = number_format($v['rate'],2);
                    //本息还款金额
                    $list[$k]['month_repay_money'] = $this->pl_it_formula($v['borrow_amount'],$v['rate']/12/100,$v['repay_time']);
                    $list[$k]['month_repay_money_format'] =  number_format($list[$k]['month_repay_money'],2);

                    if($v['deal_status'] == 1){
                        //还需多少钱
                        $list[$k]['need_money'] = number_format($v['borrow_amount'] - $v['load_money'],2);
                        //百分比
                        $list[$k]['progress_point'] = $v['load_money']/$v['borrow_amount']*100;
                    }elseif($v['deal_status'] == 2 || $v['deal_status'] == 5) {
                        $list[$k]['progress_point'] = 100;
                    } elseif($v['deal_status'] == 4){
                        //百分比
                        $list[$k]['remain_repay_money'] = $list[$k]['month_repay_money'] * $v['repay_time'];
                        //还有多少需要还
                        $list[$k]['need_remain_repay_money'] = $list[$k]['remain_repay_money'] - $v['repay_money'];
                        //还款进度条
                        $list[$k]['progress_point'] =  round($v['repay_money']/$list[$k]['remain_repay_money']*100,2);
                    }
                    $user_location = "";
                    $userCity = WwdRegionConf::findOne(['id'=>$this->uinfo['city_id']]);
                    if($userCity){
                        $user_location = $userCity['name'];
                    }
                    $userProvince = WwdRegionConf::findOne(['id'=>$this->uinfo['province_id']]);
                    if($userProvince){
                        $user_location = $userProvince['name'];
                    }

                    $list[$k]['user_location'] = $user_location;
                    $list[$k]['point_level'] = WwdUserLevel::findOne(['id'=>$v['level_id']])->name;

                    if($v['deal_status']==4 || $v['deal_status']==5){
                        $last_month_time = $v['repay_start_time'];
                        for($i=0; $i<=$v['repay_time']-1; $i++)
                        {
                            $last_month_time = $this->next_replay_month($last_month_time);
                        }
                    }
                    $deal = $v->deal;
                    if($deal['deal_status']>=4){
                        //用户回款
                        $user_load_ids = WwdDealLoad::findAll(['id'=>$v['id']]);
                        foreach($user_load_ids as $kk=>$vv){

                            $vv['repay_start_time'] = $deal['repay_start_time'];
                            $vv['repay_time'] = $deal['repay_time'];
                            $vv['rate'] = $deal['rate'];
                            $vv['u_key'] = $kk;
                            $user_loan_list = $this->get_deal_user_load_list($vv,$deal['loantype'],$deal['repay_time_type']);

                            $self_money = 0;
                            $repay_money = 0;
                            $impose_money = 0;

                            $days = intval(($this->to_timespan($this->to_date($deal['repay_start_time'],"Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($v['dltime'],"Y-m-d 00:00:00")))/86400);
                            $lixi = $v['u_load_money']*$deal['rate']/100/365*$days;
                            if($lixi<0){
                                $lixi = 0;
                            }

                            foreach($user_loan_list as $kkk=>$vvv){
                                if($vvv['repay_day']<$this->get_gmtime()-86400){
                                    $lixi = 0;
                                    $repay_money = WwdDealLoadRepay::find()->where(['deal_id'=>$v['deal_id'],'user_id'=>$user_id,'load_id'=>$vvv['id'],'repay_time'=>$vvv['repay_day']])->sum('repay_money');
                                    $repay_money = number_format($repay_money,2);
                                    $impose_money = WwdDealLoadRepay::find()->where(['deal_id'=>$v['deal_id'],'user_id'=>$user_id,'load_id'=>$vvv['id'],'repay_time'=>$vvv['repay_day']])->sum('impose_money');
                                    $impose_money = number_format($impose_money,2);
                                    $self_money = WwdDealLoadRepay::find()->where(['deal_id'=>$v['deal_id'],'user_id'=>$user_id,'load_id'=>$vvv['id'],'repay_time'=>$vvv['repay_day']])->sum('self_money');
                                    $self_money = number_format($self_money,2);
                                }else{
                                    $repay_money = $vvv['month_repay_money'];
                                    $impose_money = $vvv['impose_money'];
                                    if($deal['loantype']==0){//等额本息的时候才通过公式计算剩余多少本金
                                        $self_money = $vv['money']/$deal['repay_time'];////$vv['month_repay_money'] - get_benjin($kk,$deal['repay_time'],$v['money'],$vv['month_repay_money'],$deal['rate'])*$deal['rate']/12/100;
                                    }
                                    elseif($deal['loantype']==1){//每月还息，到期还本
                                        if($kkk+1 == count($user_loan_list)){//判断是否是最后一期
                                            $self_money = $vv['money'];
                                        }
                                        else{
                                            $self_money = 0;
                                        }
                                    }
                                    elseif($deal['loantype']==2){//到期还本息
                                        if($kkk+1 == count($user_loan_list)){//判断是否是最后一期
                                            $self_money = $vv['money'];
                                        }
                                        else{
                                            $self_money = 0;
                                        }
                                    }
                                }
                            }

                            $lixi += $repay_money - $self_money + $impose_money;

                        }
                    }else{
                        $days = intval(($this->to_timespan($this->to_date($this->get_gmtime(),"Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($v['dltime'],"Y-m-d 00:00:00")))/86400);
                        $lixi = $v['u_load_money']*$deal['rate']/100/365*$days;
                    }
                    $more_list_money = $lixi;

                    $list[$k]['last_month_time'] = $last_month_time;
                    $list[$k]['more_list_money'] = $more_list_money;
                }
            }
        }else{
            if($this->uinfo['is_company']==1){
                $repay_list =  WwdDeal::find()->where(['user_id'=>$user_id,'deal_status'=>4,'is_effect'=>1,'is_delete'=>0])->orderBy('next_repay_time ASC')->all();
            }elseif($this->uinfo['is_company']==2){
                $repay_list =  WwdDeal::find()->where(['agency_id'=>$user_id,'deal_status'=>4,'is_effect'=>1,'is_delete'=>0])->orderBy('next_repay_time ASC')->all();
            }elseif($this->uinfo['is_company']==3){
                $repay_list = WwdDeal::find()->where(['deal_status'=>4,'is_effect'=>1,'is_delete'=>0])->orderBy('next_repay_time ASC')->all();
            }
            foreach($repay_list as $k=>$v){
                $repay_list[$k]['fee'] = intval($v['borrow_amount']*$v['services_fee']/100/10000);
                if($v['repay_time_type']==0){
                    if($v['loantype']==0){
                        $repay_list[$k]['repay_total'] = $v['borrow_amount'] + round($this->pl_it_formula_day($v['borrow_amount'],$v['rate']/365/100,$v['repay_time']),2);
                    }else{
                        $repay_list[$k]['repay_total'] = $v['borrow_amount'] + round($this->av_it_formula_day($v['borrow_amount'],$v['rate']/365/100,$v['repay_time']),2);
                    }

                }else{
                    if($v['loantype']==0){
                        $repay_list[$k]['repay_total'] = $v['borrow_amount'] + round($this->pl_it_formula($v['borrow_amount'],$v['rate']/12/100,$v['repay_time']),2);
                    }else{
                        $repay_list[$k]['repay_total'] = $v['borrow_amount'] + round($this->av_it_formula($v['borrow_amount'],$v['rate']/12/100,$v['repay_time'])*$v['repay_time'],2);
                    }
                }
            }
            $this->viewParam['repay_list'] = $repay_list;

            if($GLOBALS['user_info']['is_company']==1){
                $query = WwdDeal::find()->where(['user_id'=>$user_id,'is_effect'=>1,'is_delete'=>0])
                    ->andWhere(['in','deal_status',[1,2,5]]);
            }elseif($GLOBALS['user_info']['is_company']==2){
                $query = WwdDeal::find()->where(['agency_id'=>$user_id,'is_effect'=>1,'is_delete'=>0])
                    ->andWhere(['in','deal_status',[1,2,5]]);
            }elseif($GLOBALS['user_info']['is_company']==3){
                $query = WwdDeal::find()->where(['is_effect'=>1,'is_delete'=>0])
                    ->andWhere(['in','deal_status',[1,2,5]]);
            }

            $countQuery = clone $query; //优化实例化对象
            $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
            $list = $query->orderBy('create_time desc')
                ->offset($pages->offset)
                ->limit($pages->limit)
                ->all();
            foreach($list as $k=>$v){
                $list[$k]['fee'] = intval($v['borrow_amount']*$v['services_fee']/100/10000);
                if($v['repay_time_type']==0){
                    $list[$k]["repay_total"] = $v['borrow_amount'] + round($v['borrow_amount']*$v['rate']/365/12*$v['repay_time'],2);
                }else{
                    $list[$k]["repay_total"] = $v['borrow_amount'] + round($v['borrow_amount']*$v['rate']/100/12*$v['repay_time'],2);
                }
            }
        }
        $this->viewParam['list'] = $list;
        $this->viewParam['pages'] = $pages;
        $this->viewParam['pate_title'] = '交易记录';
        return $this->render('invest',$this->viewParam);
    }
    //交易记录 还款记录
    protected function getrepay(){
        $user_id = $this->uinfo['id'];
        if($this->uinfo['is_company']==0){
            $query = WwdDealLoadRepay::find()->joinWith('deal')
                ->joinWith('dealLoad')
                ->where([
                    WwdDeal::tableName().'.is_effect' => 1,
                    WwdDeal::tableName().'.is_delete' => 0,
                    WwdDealLoadRepay::tableName().'.user_id'=>$user_id]);
            $countQuery = clone $query; //优化实例化对象
            $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
            $list = $query->orderBy('id desc')
                ->offset($pages->offset)
                ->limit($pages->limit)
                ->all();
            foreach($list as $k=>$v){
               /* $dealdetail = $GLOBALS['db']->getRow("SELECT d.*,dl.money as u_load_money FROM ".DB_PREFIX."deal d
                        LEFT JOIN ".DB_PREFIX."deal_load as dl on d.id = dl.deal_id
                        LEFT JOIN ".DB_PREFIX."user u ON u.id=d.user_id
                        WHERE dl.id = ".$v['load_id']);
                foreach($dealdetail as $kk=>$vv){
                    $list[$k][$kk] = $vv;
                }*/
                //$v = $list[$k];
                if($v['deal']['repay_time_type']==0){
                    //$list[$k]['borrow_amount_format'] = format_price($v['borrow_amount']);

                    //$list[$k]['rate_format'] = number_format($v['rate'],2);
                    //本息还款金额
                    //$list[$k]['month_repay_money'] = $this->pl_it_formula($v['borrow_amount'],$v['rate']/365/100,$v['repay_time']);
                    //$list[$k]['month_repay_money_format'] =  format_price($list[$k]['month_repay_money']);

                    if($v['deal']['deal_status'] == 1){
                        //还需多少钱
                        //$list[$k]['need_money'] = format_price($v['borrow_amount'] - $v['load_money']);

                        //百分比
                       // $list[$k]['progress_point'] = $v['load_money']/$v['borrow_amount']*100;

                    } elseif($v['deal']['deal_status'] == 2 || $v['deal']['deal_status'] == 5)
                    {
                       // $list[$k]['progress_point'] = 100;
                    } elseif($v['deal']['deal_status'] == 4){
                        //百分比
                        $list[$k]['remain_repay_money'] = $list[$k]['month_repay_money'] * $v['repay_time'];
                        //还有多少需要还
                        $list[$k]['need_remain_repay_money'] = $list[$k]['remain_repay_money'] - $v['repay_money'];
                        //还款进度条
                        $list[$k]['progress_point'] =  round($v['repay_money']/$list[$k]['remain_repay_money']*100,2);
                    }

                    /*$user_location = $GLOBALS['db']->getOneCached("select name from ".DB_PREFIX."region_conf where id = ".intval($v['city_id']));
                    if($user_location=='')
                        $user_location = $GLOBALS['db']->getOneCached("select name from ".DB_PREFIX."region_conf where id = ".intval($v['province_id']));

                    $list[$k]['user_location'] = $user_location;
                    $list[$k]['point_level'] = $GLOBALS['db']->getOne("select name from ".DB_PREFIX."user_level where id = ".intval($v['level_id']));*/

                    if($v['deal']['deal_status']==4 || $v['deal']['deal_status']==5){
                        $last_month_time = $v['deal']['repay_start_time'];
                        $last_month_time = $last_month_time + 86400 * $v['repay_time'];
                    }

                    //$list[$k]['last_month_time'] = $last_month_time;
                }else{
                    $list[$k]['borrow_amount_format'] = format_price($v['borrow_amount']);

                    $list[$k]['rate_format'] = number_format($v['rate'],2);
                    //本息还款金额
                    $list[$k]['month_repay_money'] = pl_it_formula($v['borrow_amount'],$v['rate']/12/100,$v['repay_time']);
                    $list[$k]['month_repay_money_format'] =  format_price($list[$k]['month_repay_money']);

                    if($v['deal_status'] == 1){
                        //还需多少钱
                        $list[$k]['need_money'] = format_price($v['borrow_amount'] - $v['load_money']);

                        //百分比
                        $list[$k]['progress_point'] = $v['load_money']/$v['borrow_amount']*100;

                    }
                    elseif($v['deal_status'] == 2 || $v['deal_status'] == 5)
                    {
                        $list[$k]['progress_point'] = 100;
                    }
                    elseif($v['deal_status'] == 4){
                        //百分比
                        $list[$k]['remain_repay_money'] = $list[$k]['month_repay_money'] * $v['repay_time'];
                        //还有多少需要还
                        $list[$k]['need_remain_repay_money'] = $list[$k]['remain_repay_money'] - $v['repay_money'];
                        //还款进度条
                        $list[$k]['progress_point'] =  round($v['repay_money']/$list[$k]['remain_repay_money']*100,2);
                    }

                    /*$user_location = $GLOBALS['db']->getOneCached("select name from ".DB_PREFIX."region_conf where id = ".intval($v['city_id']));
                    if($user_location=='')
                        $user_location = $GLOBALS['db']->getOneCached("select name from ".DB_PREFIX."region_conf where id = ".intval($v['province_id']));

                    $list[$k]['user_location'] = $user_location;
                    $list[$k]['point_level'] = $GLOBALS['db']->getOne("select name from ".DB_PREFIX."user_level where id = ".intval($v['level_id']));*/

                    if($v['deal_status']==4 || $v['deal_status']==5){
                        $last_month_time = $v['repay_start_time'];
                        for($i=0; $i<=$v['repay_time']-1; $i++)
                        {
                            $last_month_time = $this->next_replay_month($last_month_time);
                        }
                    }
                    $list[$k]['last_month_time'] = $last_month_time;
                }
            }
        }elseif($this->uinfo['is_company']==1 || $this->uinfo['is_company']==2){
            //输出借款记录
            $query = WwdDealRepay::find()->joinWith('deal')->where([
                WwdDeal::tableName().'.is_effect' => 1,
                WwdDeal::tableName().'.is_delete' => 0,
                WwdDealRepay::tableName().'.user_id'=>$user_id]);
            $countQuery = clone $query; //优化实例化对象
            $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
            $list = $query->orderBy('id desc')
                ->offset($pages->offset)
                ->limit($pages->limit)
                ->all();
        }
        $this->viewParam['list'] = $list;
        $this->viewParam['pages'] = $pages;
        $this->viewParam['pate_title'] = '交易记录';
        return $this->render('invest',$this->viewParam);
    }
    //交易记录 充值记录
    protected function getrecharge(){
        $user_id = $this->uinfo['id'];
        $query = WwdDealOrder::find()->where(['user_id'=>$user_id, 'pay_status'=>2]);
        $countQuery = clone $query; //优化实例化对象
        $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
        $list = $query->orderBy('update_time desc')
            ->offset($pages->offset)
            ->limit($pages->limit)
            ->all();
        $this->viewParam['list'] = $list;
        $this->viewParam['pages'] = $pages;
        return $this->render('invest',$this->viewParam);
    }
    //交易记录 提现记录
    protected function getcarry(){
        $user_id = $this->uinfo['id'];
        $query = WwdUserCarry::find()->where(['user_id'=>$user_id]);
        $countQuery = clone $query; //优化实例化对象
        $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
        $list = $query->orderBy('create_time desc')
            ->offset($pages->offset)
            ->limit($pages->limit)
            ->all();
        $this->viewParam['list'] = $list;
        $this->viewParam['pages'] = $pages;
        return $this->render('invest',$this->viewParam);
    }
    //AJAX的JSON响应
    protected function showAjaxMsg($status,$msg,$url){
        $result['status'] = $status;
        $result['info'] = $msg;
        $result['jump'] = $url;
        Yii::$app->response->format = Response::FORMAT_JSON;;
        return $result;
    }

}