<?php

namespace frontend\base;

use Yii;
use components\base\BaseActiveRecord;

class BaseFrontActiveRecord extends BaseActiveRecord
{
}