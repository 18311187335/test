<?php

namespace frontend\base;

use Yii;
use components\base\BaseModel;

class BaseFrontModel extends BaseModel
{
}