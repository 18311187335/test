<?php

namespace frontend\base;

use Yii;
use components\base\BaseAction;

class BaseFrontAction extends BaseAction
{
}