<?php
namespace frontend\controllers;

use app\models\WwdCodeLog;
use app\models\WwdMailList;
use app\models\WwdMobileList;
use app\models\WwdPayment;
use app\models\WwdRegisterLog;
use app\models\WwdUser;
use app\models\WwdUserPointLog;
use common\includes\CommonUtility;
use frontend\actions\VerifyAction;
use frontend\base\BaseFrontController;
use Yii;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;
use yii\base\Exception;
use yii\base\InvalidParamException;
use yii\base\UserException;
use yii\web\BadRequestHttpException;
use yii\filters\AccessControl;
use yii\web\HttpException;

/**
 * Index controller
 */
class UserController extends BaseFrontController
{
    public $layout = "default";
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['login','register'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'allow' => true,
                        'roles' => ['@'],
                        'denyCallback' => function ($rule, $action) {throw new \Exception('您无权访问该页面');},
                    ],
                ],
            ]
        ];
    }
    public function actionRegister()
    {
        $request = Yii::$app->request->get();
        if(isset($request['inv_uid'])){
            $inv_uid = intval($request['inv_uid']);
            $this->viewParam['inv_uid'] = $inv_uid;
        }
        $this->viewParam['seo_keywords'] = "注册";
        $this->viewParam['seo_title'] = "注册-家财猫";

        return $this->render("register",$this->viewParam);
    }

    public function actionDoregister()
    {
        $jumpUrl = Yii::$app->urlManager->createUrl('user/register');
        $user_data = Yii::$app->request->post();
        $verify = new VerifyAction('verify',$this->controller);
        if(isset($user_data['verify']) && !$verify->validate($user_data['verify'],false))
        {
            $this->showAlert($jumpUrl,'注册','验证码失败！');
        }
        foreach($user_data as $k=>$v)
        {
            $user_data[$k] = htmlspecialchars(addslashes($v));
        }
        $preg2= '/^\d+$/i';
        if(preg_match($preg2,trim($user_data['user_name']))){
            $this->showAlert($jumpUrl,'注册','用户名不能为纯数字！');
        }

        if(trim($user_data['user_pwd'])!=trim($user_data['user_pwd_confirm']))
        {
            $this->showAlert($jumpUrl,'注册','两次密码输入不一样！');
        }
        if(trim($user_data['user_pwd'])=='')
        {
            $this->showAlert($jumpUrl,'注册','密码不能为空！');
        }

        $user_data['pid'] = $GLOBALS['ref_uid'];
        $isExist = WwdUser::find()->where(['mobile'=>$user_data['mobile'],'mobilepassed'=>1])->count();
        $isExistNoPass = WwdUser::findOne(['mobile'=>$user_data['mobile'],'mobilepassed'=>0]);
        $inv_uid = intval($user_data['inv_uid']);
        if(strlen($inv_uid)>8){
            $invInfo = WwdUser::findOne(['mobile'=>$inv_uid]);
            if($invInfo){
                $inv_uid = $invInfo->id;
            }
        }
        $user_id = 0;
        if($isExist > 0){
            $this->showAlert($jumpUrl,'注册','手机号已经存在！');exit;
        }elseif($isExistNoPass){
            $user_id = $isExistNoPass['id'];
            $code = $isExistNoPass['code'];
            $user_pwd = md5($user_data['user_pwd'].$code);
            WwdUser::updateAll(['user_name'=>$user_data['user_name'],'user_pwd'=>$user_pwd,'is_company'=>0,'inv_uid'=>intval($inv_uid)],['id'=>$user_id]);
            $res = array("status"=>1,"info"=>"","data"=>$user_id);
        }else{
            $user_data['inv_uid'] = $inv_uid;
            $userModel = new WwdUser();
            $userModel->insert(false,$user_data);
            $user_id = $userModel->id;
            $errors = $userModel->getFirstErrors();
            $res = ['status'=>1,"info"=>"","data"=>$user_id];
            if(!empty($errors)){
                $errMsg = current($errors);
                $res = ['status'=>0,"info"=>$errMsg,"data"=>$user_id];
            }
        }

        $register_log = array();
        $register_log['ip'] = Yii::$app->request->getUserIP();
        $register_log['dateline'] = $this->get_gmtime();
        $registerLogModel = new WwdRegisterLog();
        $registerLogModel->insert(false,$register_log);

        if($_REQUEST['subscribe']==1)
        {
            $subscribeMailCount = WwdMailList::find()->where(['mail_address'=>$user_data['email']])->count();
            //订阅
            if($subscribeMailCount == 0)
            {
                $mail_item['city_id'] = intval($_REQUEST['city_id']);
                $mail_item['mail_address'] = $user_data['email'];
                $mail_item['is_effect'] = Yii::$app->params['USER_VERIFY'];
                $mailistModel = new WwdMailList();
                $mailistModel->insert($mail_item);
            }
            $subscribeMobCount  = WwdMobileList::find()->where(['mobile'=>$user_data['mobile']])->count();
            if($user_data['mobile']!=''&&$subscribeMobCount==0)
            {
                $mobile['city_id'] = intval($_REQUEST['city_id']);
                $mobile['mobile'] = $user_data['mobile'];
                $mobile['is_effect'] = Yii::$app->params['USER_VERIFY'];
                $mobileModel = new WwdMobileList();
                $mobileModel->insert($mobile);
            }
        }
        if($res['status'] == 1)
        {
            $user_id = intval($res['data']);
            //更新来路
            WwdUser::updateAll(['referer'=>Yii::$app->request->referrer],['id'=>$user_id]);
            $user_info = WwdUser::findOne(['id'=>$user_id]);
            if($user_info['is_effect']==1)
            {
                $this->viewParam['mobile'] = $user_data['mobile'];
                $this->viewParam['user_name'] = $user_data['user_name'];
                $this->viewParam['user_pwd'] = $user_data['user_pwd'];
                $this->viewParam['preurl'] = $user_data['preurl'];

                $op = Yii::$app->session->get('bind_mobile_verify_0_ip');
                if($op['time']){
                    $wait = $op['time'] + 60 - $this->get_gmtime();
                }else{
                    $wait = 0;
                }
                $this->viewParam['wait'] = $wait;
                $this->viewParam['seo_title'] = '注册-家财猫';
                $this->viewParam['seo_keywords'] = '注册';
                return $this->render('mobile',$this->viewParam);
            }
            else
            {
                $this->showAlert('/',"注册",'注册成功');
            }
        }
        else
        {
            $this->showAlert($jumpUrl,'注册',$errMsg);
        }
    }
    public function actionDomobile()
    {
        $jumpUrl = Yii::$app->urlManager->createUrl('user/register');
        $mobile = htmlspecialchars(addslashes(trim($_REQUEST['mobile'])));
        $user_name = htmlspecialchars(addslashes(trim($_REQUEST['user_name'])));
        $userinfo = WwdUser::findOne(['mobile'=>$mobile,'mobilepassed'=>0]);
        if($_REQUEST['isajax']==1){
            if(!$userinfo){
                echo json_encode(array("status"=>-1));exit;
            }

            if($userinfo['bind_verify']==trim($_POST['validatecode'])){
                echo json_encode(array("status"=>1));
            }else{
                echo json_encode(array("status"=>-1));
            }exit;
        }else{
            if(!$userinfo){
                $this->redirect("/");
            }
            $isExist = WwdUser::find()->where(['user_name'=>$user_name,'mobilepassed'=>1])->count();
            if($isExist>0){
                $this->showAlert($jumpUrl,"注册","很抱歉，您提交的用户名刚刚被注册，请重新注册");
            }

            if($userinfo['bind_verify']==trim($_POST['validatecode']) && ($this->get_gmtime()-$userinfo['verify_create_time'])<120){
                $pointFold = Yii::$app->params['point_fold'];
                WwdUser::updateAll(['mobile'=>$mobile,'mobilepassed'=>1,'coupon'=>0],['id'=>$userinfo['id']]);
                WwdUser::updateAllCounters(['point'=>200*$pointFold],['id'=>$userinfo['id']]);

                $poing_log = array();
                $poing_log['user_id'] = $userinfo['id'];
                $poing_log['action_type'] = 2;
                $poing_log['value'] = 200*$pointFold;
                $poing_log['msg'] = "注册送积分 ".$poing_log['value']."分";
                $poing_log['dateline'] = $this->get_gmtime();
                $userPointLog = new WwdUserPointLog();
                $userPointLog->insert($poing_log);

                /***端午活动***/
                $start_time = $this->to_timespan("2015-06-16 10:00:00");
                $end_time = $this->to_timespan("2015-06-23 22:00:00");

                $time = $this->get_gmtime();

                if($time>=$start_time && $time < $end_time){
                    WwdUser::updateAllCounters(['experience'=>1000],['id'=>$userinfo['id']]);
                    $this->send_user_msg("", "恭喜您获得1000元注册体验金", 0, $userinfo['id'], $this->get_gmtime(),0,false,1,0);
                }
                /***端午活动***/

                $code_log = WwdCodeLog::findAll(['mobile'=>$mobile]);
                if($code_log){
                    foreach($code_log as $k=>$v){
                        WwdUser::updateAllCounters(['coupon'=>$v['value']],['id'=>$userinfo['id']]);
                    }
                }
                $this->viewParam['user_name'] = $this->uinfo['user_name'];
                $this->viewParam['preurl'] = $_REQUEST['preurl'];
                $this->viewParam['seo_title'] = "注册-家财猫";
                $this->viewParam['seo_keywords'] = "注册";
                $this->render('mobilepass',$this->viewParam);
            }else{
                $this->showAlert($jumpUrl,'注册','验证失败！');
            }
        }
    }
    public function actionHeepaybind(){
        $userinfo = $GLOBALS['user_info'];
        if(!$userinfo){
            $this->redirect("/");
        }


        $idno = htmlspecialchars(addslashes(trim($_REQUEST['idno'])));
        $real_name = htmlspecialchars(addslashes(trim($_REQUEST['realname'])));

        if($_REQUEST['isajax']==1){
            if(!CommonUtility::getIDCardInfo($idno)){
                echo json_encode(array("status"=>-1));exit;
            }
            echo json_encode(array("status"=>1));exit;
        }else{

            if(!$userinfo){
                $this->redirect(Yii::$app->urlManager->createUrl('user/login'));
            }
            $this->viewParam['userinfo'] = $userinfo;

            if(!$idno){
                $this->render("heepaybind",$this->viewParam);
                /*if($userinfo['is_company']==0){
                    $GLOBALS['tmpl']->display("user_heepay_bind.html");exit;
                }elseif($userinfo['is_company']==1){
                    $GLOBALS['tmpl']->display("company_heepay_bind.html");exit;
                }elseif($userinfo['is_company']==2){
                    $user_agency = $GLOBALS['db']->getRow("SELECT * FROM ".DB_PREFIX."user_agency where user_id = ".$userinfo['id']);
                    $GLOBALS['tmpl']->assign("user_agency",$user_agency);
                    $GLOBALS['tmpl']->display("agency_mobile_pass.html");exit;
                }*/
            }
            $idCount = WwdUser::find()->where(['idno'=>$idno,'idcardpassed'=>1])->count();
            if($idCount > 0){
                $bindurl = Yii::$app->urlManager->createUrl('user/heepaybind');
                $this->showAlert($bindurl,"绑卡","身份证已经存在");
            }

            if(!$userinfo['heepay_no']){
                $heepayid = 4;
                $payment_info = WwdPayment::findOne(['id'=>$heepayid]);
                $payment_info['config'] = unserialize($payment_info['config']);
                $timestamp = (time()+ date('Z'))*1000;
                $notify_url = Yii::$app->urlManager->createUrl('paynotify/heepaynotify');
                $return_url = Yii::$app->urlManager->createUrl('paynotify/heepayreturn');

                $key = $payment_info['config']['heepay_key'];

                $signKey = md5($payment_info['config']['heepay_account']."|".$GLOBALS['heepay_config']['agent_user_id_pre'].$userinfo['id']."|".$idno."|".$userinfo['mobile']."|".$notify_url."|".$real_name."|".$return_url."|".$timestamp."|".$key);
                WwdUser::updateAll(['idno'=>$idno,'real_name'=>$real_name],['id'=>$userinfo['id']]);
            }
            if($userinfo['is_company']==1){
                if($GLOBALS['db']->getOne("SELECT COUNT(1) FROM ".DB_PREFIX."user_company WHERE user_id = ".$userinfo['id'])>0){
                    $user_company = $GLOBALS['db']->getRow("SELECT * FROM ".DB_PREFIX."user_company WHERE user_id = ".$userinfo['id']);
                    $user_company['license'] = $_POST['license_0'];
                    $user_company['identity'] = "";
                    $user_company['credit_report'] = "";
                    $user_company['residence'] = "";
                    $user_company['lease'] = "";
                    $user_company['public_account'] = "";
                    foreach($_POST as $k=>$v){
                        if(preg_match("/^idcard_?/", $k)){
                            if($v!=""){
                                $user_company['identity'] .= $v.",";
                            }
                        }elseif(preg_match("/^credit_?/", $k)){
                            if($v!=""){
                                $user_company['credit_report'] .= $v.",";
                            }
                        }elseif(preg_match("/^residence_?/", $k)){
                            if($v!=""){
                                $user_company['residence'] .= $v.",";
                            }
                        }elseif(preg_match("/^lease_?/", $k)){
                            if($v!=""){
                                $user_company['lease'] .= $v.",";
                            }
                        }elseif(preg_match("/^account_?/", $k)){
                            if($v!=""){
                                $user_company['public_account'] .= $v.",";
                            }
                        }
                    }
                    $GLOBALS['db']->autoExecute(DB_PREFIX."user_company",$user_company,'UPDATE','id='.$user_company['id']);

                }else{
                    $user_company = array();
                    $user_company['user_id'] = $userinfo['id'];
                    $user_company['license'] = $_POST['license_0'];
                    $user_company['identity'] = "";
                    $user_company['credit_report'] = "";
                    $user_company['residence'] = "";
                    $user_company['lease'] = "";
                    $user_company['public_account'] = "";
                    foreach($_POST as $k=>$v){
                        if(preg_match("/^idcard_?/", $k)){
                            if($v!=""){
                                $user_company['identity'] .= $v.",";
                            }
                        }elseif(preg_match("/^credit_?/", $k)){
                            if($v!=""){
                                $user_company['credit_report'] .= $v.",";
                            }
                        }elseif(preg_match("/^residence_?/", $k)){
                            if($v!=""){
                                $user_company['residence'] .= $v.",";
                            }
                        }elseif(preg_match("/^lease_?/", $k)){
                            if($v!=""){
                                $user_company['lease'] .= $v.",";
                            }
                        }elseif(preg_match("/^account_?/", $k)){
                            if($v!=""){
                                $user_company['public_account'] .= $v.",";
                            }
                        }
                    }
                    $GLOBALS['db']->autoExecute(DB_PREFIX."user_company",$user_company,'INSERT');
                }
            }elseif($userinfo['is_company']==2){
                if($GLOBALS['db']->getOne("SELECT COUNT(1) FROM ".DB_PREFIX."user_agency WHERE user_id = ".$userinfo['id'])>0){
                    $user_agency = $GLOBALS['db']->getRow("SELECT * FROM ".DB_PREFIX."user_agency WHERE user_id = ".$userinfo['id']);
                    $user_agency['license'] = $_POST['license'];
                    $user_agency['permit'] = $_POST['permit'];
                    $user_agency['taxation'] = $_POST['taxation'];
                    $user_agency['organization'] = $_POST['organization'];
                    $GLOBALS['db']->autoExecute(DB_PREFIX."user_agency",$user_agency,'UPDATE','id='.$user_agency['id']);
                }else{
                    $user_agency = array();
                    $user_agency['user_id'] = $userinfo['id'];
                    $user_agency['license'] = $_POST['license'];
                    $user_agency['permit'] = $_POST['permit'];
                    $user_agency['taxation'] = $_POST['taxation'];
                    $user_agency['organization'] = $_POST['organization'];
                    $GLOBALS['db']->autoExecute(DB_PREFIX."user_agency",$user_agency,'INSERT');
                }
            }
            if($userinfo['heepay_no']){
                showSuccess("资料更新成功",0,url("index"));exit;
            }
            header('Content-type: text/html; charset=gb2312');
            $str = '<form action="'.$GLOBALS['heepay_config']['P2PBindAgreeUserV2'].'" method="POST" id="testform">
                				<input type="hidden" name="agent_id" value="'.$payment_info['config']['heepay_account'].'" /><br />
                				<input type="hidden" name="agent_user_id" value="'.$GLOBALS['heepay_config']['agent_user_id_pre'].$userinfo['id'].'" /><br />
                				<input type="hidden" name="id_card" value="'.$idno.'" /><br />
                				<input type="hidden" name="mobile" value="'.$userinfo['mobile'].'" /><br />
                				<input type="hidden" name="notify_url" value="'.$notify_url.'" /><br />
                				<input type="hidden" name="personal_name" value="'.iconv("utf-8","gb2312",$real_name).'" /><br />
                				<input type="hidden" name="return_url" value="'.$return_url.'" /><br />
                				<input type="hidden" name="timestamp" value="'.$timestamp.'" /><br />
                				<input type="hidden" name="sign" value="'.$signKey.'" /><br />

                			</form><script>document.getElementById("testform").submit();</script>';
            echo $str;
        }
    }
    public function actionLogin()
    {
        if (!\Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        } else {
            return $this->render('login', [
                'model' => $model,
            ]);
        }
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($model->sendEmail(Yii::$app->params['adminEmail'])) {
                Yii::$app->session->setFlash('success', 'Thank you for contacting us. We will respond to you as soon as possible.');
            } else {
                Yii::$app->session->setFlash('error', 'There was an error sending email.');
            }

            return $this->refresh();
        } else {
            return $this->render('contact', [
                'model' => $model,
            ]);
        }
    }

    public function actionAbout()
    {
        return $this->render('about');
    }

    public function actionSignup()
    {
        $model = new SignupForm();
        if ($model->load(Yii::$app->request->post())) {
            if ($user = $model->signup()) {
                if (Yii::$app->getUser()->login($user)) {
                    return $this->goHome();
                }
            }
        }

        return $this->render('signup', [
            'model' => $model,
        ]);
    }

    public function actionRequestPasswordReset()
    {
        $model = new PasswordResetRequestForm();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($model->sendEmail()) {
                Yii::$app->getSession()->setFlash('success', 'Check your email for further instructions.');

                return $this->goHome();
            } else {
                Yii::$app->getSession()->setFlash('error', 'Sorry, we are unable to reset password for email provided.');
            }
        }

        return $this->render('requestPasswordResetToken', [
            'model' => $model,
        ]);
    }

    public function actionResetPassword($token)
    {
        try {
            $model = new ResetPasswordForm($token);
        } catch (InvalidParamException $e) {
            throw new BadRequestHttpException($e->getMessage());
        }

        if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {
            Yii::$app->getSession()->setFlash('success', 'New password was saved.');

            return $this->goHome();
        }

        return $this->render('resetPassword', [
            'model' => $model,
        ]);
    }

    public function actionError()
    {
        if (($exception = Yii::$app->getErrorHandler()->exception) === null) {
            return '';
        }

        if ($exception instanceof HttpException) {
            $code = $exception->statusCode;
        } else {
            $code = $exception->getCode();
        }
        if ($exception instanceof Exception) {
            $name = $exception->getName();
        } else {
            $name = $this->defaultName ?: Yii::t('yii', 'Error');
        }
        if ($code) {
            $name .= " (#$code)";
        }

        if ($exception instanceof UserException) {
            $message = $exception->getMessage();
        } else {
            $message = $this->defaultMessage ?: Yii::t('yii', 'An internal server error occurred.');
        }

        if (Yii::$app->getRequest()->getIsAjax()) {
            return "$name: $message";
        } else {
            return $this->controller->render($this->view ?: $this->id, [
                'name' => $name,
                'message' => $message,
                'exception' => $exception,
            ]);
        }
    }
}
