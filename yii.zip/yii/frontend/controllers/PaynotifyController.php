<?php
/**
 * Created by PhpStorm.
 * User: King
 * Date: 2015/8/14
 * Time: 10:45
 */

namespace frontend\controllers;


use app\models\WwdPayment;
use app\models\WwdUser;
use frontend\base\BaseFrontController;

class PaynotifyController extends BaseFrontController
{
    public $enableCsrfValidation = false; //禁用回调通知

    public function  actionHeepaynotify(){
        $result_code = htmlspecialchars(addslashes(trim($_REQUEST['result_code'])));
        $result_msg = addslashes(trim($_REQUEST['result_msg']));
        $bind_code = htmlspecialchars(addslashes(trim($_REQUEST['bind_code'])));
        $agent_user_id = htmlspecialchars(addslashes(trim($_REQUEST['agent_user_id'])));
        $timestamp = htmlspecialchars(addslashes(trim($_REQUEST['timestamp'])));
        $sign = htmlspecialchars(addslashes(trim($_REQUEST['sign'])));
        $heepayid = 4;
        $payment_info = WwdPayment::findOne(['id'=>$heepayid]);
        $payment_info['config'] = unserialize($payment_info['config']);

        $key = $payment_info['config']['heepay_key'];
        $signKey = md5($agent_user_id."|".$bind_code."|".$result_code."|".iconv("gbk","utf-8",$result_msg)."|".$timestamp."|".$key);

        if($sign == $signKey){
            $uid = substr($agent_user_id,strlen($GLOBALS['heepay_config']['agent_user_id_pre']),strlen($agent_user_id)-strlen($GLOBALS['heepay_config']['agent_user_id_pre']));
            if($result_code=="0001"){
                $val = 700* \Yii::$app->params['point_fold'];
                WwdUser::updateAll(['heepay_no'=>$bind_code,'idcardpassed'=>1,'idcardpassed_time'=>$this->get_gmtime()],['id'=>$uid]);
                WwdUser::updateAllCounters(['point'=>$val],['id'=>$uid]);
                $msg = "认证送积分 ".$val ."分";
                $this->pointLog($uid,2,$val,$msg);
                echo "ok";
            }elseif($result_code=="0002" || $result_code=="0003" || $result_code=="0005"){
                $val = 700* \Yii::$app->params['point_fold'];
                WwdUser::updateAll(['heepay_no'=>$bind_code],['id'=>$uid]);
                WwdUser::updateAllCounters(['point'=>$val], ['id' =>$uid]);
                $msg = "认证送积分 ".$val ."分";
                $this->pointLog($uid,2,$val,$msg);
            }elseif($result_code=="0004"){
                echo "fail";
            }else{
                echo "fail";
            }
        }else{
            echo "fail";
        }
    }

    public function actionHeepayreturn(){
        $result_code = htmlspecialchars(addslashes(trim($_REQUEST['result_code'])));
        $result_msg = addslashes(trim($_REQUEST['result_msg']));
        $bind_code = htmlspecialchars(addslashes(trim($_REQUEST['bind_code'])));
        $agent_user_id = htmlspecialchars(addslashes(trim($_REQUEST['agent_user_id'])));
        $timestamp = htmlspecialchars(addslashes(trim($_REQUEST['timestamp'])));
        $sign = htmlspecialchars(addslashes(trim($_REQUEST['sign'])));

        $heepayid = 4;

        $payment_info = WwdPayment::findOne(['id'=>$heepayid]);
        $payment_info['config'] = unserialize($payment_info['config']);

        $key = $payment_info['config']['heepay_key'];
        $signKey = md5($agent_user_id."|".$bind_code."|".$result_code."|".iconv("gbk","utf-8",$result_msg)."|".$timestamp."|".$key);
        $url = \Yii::$app->urlManager->createUrl('/');
        if($sign == $signKey){

            $start_time = $this->to_timespan("2015-06-16 10:00:00");
            $end_time = $this->to_timespan("2015-06-23 22:00:00");

            $time = $this->get_gmtime();

            if($time>=$start_time && $time < $end_time){
                $url = \Yii::$app->urlManager->createUrl('index/zongzi')."?first=1";
            }

            if($result_code=="0001"){
                $this->showAlert($url,"绑卡","账号绑定成功，身份证号通过审核");
            }elseif($result_code=="0002" || $result_code=="0003"){
                $this->showAlert($url,"绑卡","账号绑定成功，身份证号未通过审核");
            }elseif($result_code=="0004"){
                $this->showAlert($url,"绑卡","账号已经绑定过，不能重复");
            }elseif($result_code=="0005"){
                $this->showAlert($url,"绑卡","账号绑定成功");
            }else{
                $this->showAlert($url,"绑卡","绑定失败");
            }
        }else{
            $this->showAlert($url,"绑卡","验证失败");
        }
    }

}