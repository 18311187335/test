<?php
namespace frontend\controllers;

use app\models\WwdArticle;
use app\models\WwdArticleCate;

use frontend\base\BaseFrontController;
use Yii;
use yii\data\Pagination;
use yii\di\Instance;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;

/**
 * News controller 新闻相关控制器
 */
class NewsController extends BaseFrontController
{
    public function init(){
        parent::init();
    }
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [   //access 有名行为
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                       // 'roles' => ['?'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }


    public function actionIndex()
    {
        if($request = Yii::$app->request->get()){
            $cate_id = intval($request['cate_id']);

            $query = WwdArticle::find()->where(['is_effect' => 1, 'is_delete' => 0,'cate_id'=>$cate_id])->orderBy('sort ASC,create_time DESC');
            $countQuery = clone $query; //优化实例化对象
            $totalCount =  $countQuery->count();
            $pages = new Pagination(['totalCount' =>$totalCount,'defaultPageSize'=>10]);
            $this->viewParam['pages'] = $pages;
            $article_list = $query->offset($pages->offset)
                ->limit($pages->limit)
                ->all();
            $this->viewParam['totalCount'] = $totalCount;
            $id = 0;
            if(isset($request['id'])){
                $id = intval($request['id']);
                $article_list = WwdArticle::findOne(['id'=>$id]);
            }
            $this->viewParam['id'] = $id;

            if(isset($request['show_qq'])) {
                $show_qq = intval($request['show_qq']);
            }

            $pid = 0;     //子菜单父ID
            $pcate = [];  //子菜单父菜单内容
            $cateList = WwdArticleCate::find()->andWhere(['in','id',[2,5,12,19,22,47,53]])->where(['pid'=>0,'is_effect'=>1,'is_delete'=>0])->orderBy('sort ASC')->all();
            foreach($cateList as &$ca){
                if($cate_id == $ca->id){
                    $pcate[] = $ca;
                }
                $subCate = WwdArticleCate::find()->where(['pid'=>$ca['id'],'is_effect'=>1,'is_delete'=>0])->orderBy("sort ASC")->all();
                if($subCate){
                    foreach($subCate as &$sc){
                        if($sc->id == $cate_id){
                            $pid = $ca->id;
                            $pcate[] = $sc;
                        }
                    }
                    $ca['subCate'] = $subCate;
                }
            }
            $this->viewParam['cateList'] = $cateList;
            $this->viewParam['article_list'] = $article_list;
            $this->viewParam['pid'] = $pid;
            $this->viewParam['pcate'] = $pcate;
            $this->viewParam['cateId'] = $cate_id;
            $this->viewParam['show'] = 1;
            return $this->render('index',$this->viewParam);
            //$GLOBALS['tmpl']->assign('show_qq',$show_qq);
        }
        $this->showAlert(Yii::$app->urlManager->createUrl("index"),"提示","请求参数有误！");
    }
}
