<?php
namespace frontend\controllers;

use app\models\WwdActiveAwardLog;
use app\models\WwdChangeLog;
use app\models\WwdDeal;
use app\models\WwdDealLoad;
use app\models\WwdPayment;
use app\models\WwdUser;
use app\models\WwdUserAgency;
use app\models\WwdUserCompany;
use app\models\WwdUserPointLog;
use frontend\base\BaseFrontController;
use Yii;
use yii\data\Pagination;
use yii\filters\AccessControl;

class DealController extends BaseFrontController
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['index', 'deal_notify', 'deal_return'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'allow' => true,
                        'roles' => ['@'],
                        'denyCallback' => function ($rule, $action) {
                            throw new \Exception('您无权访问该页面');
                        },
                    ],
                ],
            ]
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ]
        ];
    }

    public function actionIndex()
    {
        $uid = Yii::$app->user->id;
        $data = [];
        $uinfo = Yii::$app->user->getIdentity();
        $data['uinfo'] = $uinfo;
        $dealId = Yii::$app->request->get('id', 0);
        if (!$dealId) {
            echo "不存在标";
            exit;
        }
        $dealInfo = $this->getDealInfoByDealId($dealId);

        $contract_show = 0;
        $loadOrderCount = WwdDealLoad::find()->where(['deal_id' => $dealId, 'user_id' => $uid])->count();
        if ($dealInfo->deal_status >= 4 && $loadOrderCount > 0) {
            $contract_show = 1;
        }
        $data['contract_show'] = $contract_show;

        /*融资方信息*/
        $dealCompanyExtInfoRes = WwdUserCompany::findOne(['user_id' => $dealInfo->user_id]);
        $data['dealCompanyExtInfo'] = $dealCompanyExtInfoRes;
        $dealCompanyExtInfo = [];
        if ($dealCompanyExtInfoRes->license) {
            $dealCompanyExtInfo[] = $dealCompanyExtInfoRes->license;
        }
        if ($dealCompanyExtInfoRes->identity) {
            $identity = explode(",", $dealCompanyExtInfoRes->identity);
            foreach ($identity as $iv) {
                if ($iv != "") {
                    $dealCompanyExtInfo[] = $iv;
                }
            }
        }
        if ($dealCompanyExtInfoRes->credit_report) {
            $credit_report = explode(",", $dealCompanyExtInfoRes->credit_report);
            foreach ($credit_report as $cv) {
                if ($cv != "") {
                    $dealCompanyExtInfo[] = $cv;
                }
            }
        }
        if ($dealCompanyExtInfoRes->residence) {
            $residence = explode(",", $dealCompanyExtInfoRes->residence);
            foreach ($residence as $rv) {
                if ($rv != "") {
                    $dealCompanyExtInfo[] = $rv;
                }
            }
        }
        if ($dealCompanyExtInfoRes->lease) {
            $lease = explode(",", $dealCompanyExtInfoRes->lease);
            foreach ($lease as $lv) {
                if ($lv != "") {
                    $dealCompanyExtInfo[] = $lv;
                }
            }
        }
        if ($dealCompanyExtInfoRes->public_account) {
            $public_account = explode(",", $dealCompanyExtInfoRes->public_account);
            foreach ($public_account as $pv) {
                if ($pv != "") {
                    $dealCompanyExtInfo[] = $pv;
                }
            }
        }
        $data['dealCompanyInfo'] = $dealCompanyExtInfoRes;
        $data['dealCompanyExtInfo'] = $dealCompanyExtInfo;
        /*融资方信息*/

        /*担保方信息*/
        $agencyImages = [];
        if ($dealInfo->agency_id) {
            $agency = WwdUser::findOne(['id' => $dealInfo->agency_id]);
            $angencyInfoRes = WwdUserAgency::findOne(['user_id' => $dealInfo->agency_id]);

            if ($angencyInfoRes->license) {
                $agencyImages[] = $angencyInfoRes->license;
            }
            $permit = explode(",", $angencyInfoRes->permit);
            foreach ($permit as $pev) {
                if ($pev != "") {
                    $agencyImages[] = $pev;
                }
            }
            $taxation = explode(",", $angencyInfoRes->taxation);
            foreach ($taxation as $tav) {
                if ($tav != "") {
                    $agencyImages[] = $tav;
                }
            }
            $organization = explode(",", $angencyInfoRes->organization);
            foreach ($organization as $orgv) {
                if ($orgv != "") {
                    $agencyImages[] = $orgv;
                }
            }
            $data['agency'] = $agency;
            $data['angencyInfoRes'] = $angencyInfoRes;
            $data['agencyImages'] = $agencyImages;
        }
        /*担保方信息*/

        $mortgage = explode(";", $dealInfo->mortgage);
        unset($mortgage[count($mortgage) - 1]);
        foreach ($mortgage as $k => $v) {
            if (substr($v, 0, 2) == "./") {
                $mortgage[$k] = substr($v, 1, strlen($v) - 1);
            }
        }
        $data['mortgage'] = $mortgage;

        if ($dealInfo->start_time + 86400 * $dealInfo->enddate > time() && $dealInfo->deal_status == 1) {
            $enddate = $dealInfo->start_time + 86400 * $dealInfo->enddate - time();
        } else {
            $enddate = 0;
        }
        $data['enddate'] = $enddate;

        $dealLoadList = WwdDealLoad::getLoadListByDealid($dealId);
        $data['dealLoadList'] = $dealLoadList;
        $data['dealInfo'] = $dealInfo;
        return $this->render("index", $data);
    }

    public function actionBid()
    {
        if ($request = Yii::$app->request->post()) {
            /*
        //如果未绑定手机(暂未实现)
         1,模板 user_mobile.html
           动作 user/domobile
        */
            $id = $request['id'];
            $data = [];
            $dealInfo = $this->getDealInfoByDealId($id);
            $loadMoney = $request['loadmoney'];
            $data['load_money'] = $loadMoney;
            if (!$loadMoney || $loadMoney % $dealInfo->min_loan_money != 0) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '请输入正确的金额');
            }
            if ($this->uinfo->is_company) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '只有投资者账户才能投资');
            }
            if (!$dealInfo) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '标已过期');
            }
            $loadDealNum = $this->getUserLoadCountByUid($id, $this->uinfo->id);
            if ($loadDealNum > 0 && $dealInfo->is_new == 1) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '新手标只有新手才能投资');
            }
            if ($this->uinfo->id == $dealInfo->user_id) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '不能投自己的标');
            }
            $need_money = $loadMoney - $this->uinfo->money;
            if ($need_money < 0) {
                $need_money = 0;
            }
            $data['need_money'] = $need_money;
            if ($loadMoney - $this->uinfo->coupon == 0) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '单笔投资不能全部使用代金券，请您提高投资额度');
            }
            $mobile = substr_replace($this->uinfo->mobile, "****", 3, 4);
            $data['mobilenum'] = $mobile;
            $agency = WwdUser::findOne(['id' => $dealInfo->agency_id]);
            $data['angency'] = $agency;
            $data['deal'] = $dealInfo;
            $data["seo_title"] = "确认投标-家财猫";
            $data["seo_keywords"] = "确认投标";
            $data['userinfo'] = $this->uinfo;
            return $this->render("bid", $data);
        }
        $this->showAlert(Yii::$app->urlManager->createUrl("deals"), "提示", '请求参数有误');
    }

    public function actionDobid()
    {
        if ($request = Yii::$app->request->post()) {
            $ajax = isset($request["ajax"]) ? intval($request["ajax"]) : "0";
            $id = intval($request["id"]);
            $bidMoney = $request['bid_money'];
            if ($this->uinfo->is_company) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '只有投资者账户才能投资');
            }
            $dealInfo = $this->getDealInfoByDealId($id);
            if (!$dealInfo) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '标无效');
            }
            if ($bidMoney <= 0 || $bidMoney < $dealInfo['min_loan_money']) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '投资金额无效');
            }
            $loadDealNum = $this->getUserLoadCountByUid($id, $this->uinfo->id);
            if ($loadDealNum > 0 && $dealInfo->is_new == 1) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '新手标只有新手才能投资');
            }

            if (floatval($dealInfo->max_loan_money) > 0 && floatval($bidMoney) > floatval($dealInfo->max_loan_money)) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '投资金额不能大于投资限额');
            }

            //投资金额倍数判断[暂时去除]

            if (floatval(($dealInfo->load_money / $dealInfo->borrow_amount) * 100) >= 100) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '此标已经满标！');
            }

            if (floatval($dealInfo->deal_status) != 1) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '此标无法投资！');
            }

            $need_money = $bidMoney - $this->uinfo->money;
            if ($need_money < 0) {
                $need_money = 0;
            }
            $data['need_money'] = $need_money;
            if ($bidMoney - $this->uinfo->coupon == 0) {
                $this->showAlert(Yii::$app->request->referrer, "提示", '单笔投资不能全部使用代金券，请您提高投资额度');
            }

            $fee = floatval($dealInfo->services_fee) / 100;
            $vote_fee_amt = round($bidMoney * $fee, 2);      //网站手续费

            if (floatval($bidMoney) - round($this->uinfo->money, 2) > 0.00001) {
                $this->showAlert(Yii::$app->urlManager->createUrl("uc_money/incharge"), "提示", '帐户没有足够的余额');
            }

            //判断所投的钱是否超过了剩余投标额度
            if (floatval($bidMoney) > (round($dealInfo->borrow_amount, 2) - round($dealInfo->load_money, 2))) {
                $this->showAlert(Yii::$app->urlManager->createUrl("uc_money/incharge"), "提示", '投资金额超出标的剩余可投金额');
            }

            /*if ($ajax) {
                \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
                $result['status'] = 1;
                $result['info'] = 1;
                $result['jump'] = '';
                return $result;
            }*/

            $heepayid = 4;
            $paymentInfo = WwdPayment::findOne(['id' => intval($heepayid)]);
            $paymentInfo['config'] = unserialize($paymentInfo->config);
            $agent_id = $paymentInfo['config']['heepay_account'];
            $key = $paymentInfo['config']['heepay_key'];
            $agent_bill_no = $this->uinfo->id . time();

            $agent_project_code = Yii::$app->params['code_pre'] . $id;
            $agent_project_name = $dealInfo->name;
            $benefit_bind_code = $this->uinfo->heepay_no;
            $note = "";
            $notify_url = Yii::$app->urlManager->createUrl("deal/deal_notify");
            $project_amt = $dealInfo->borrow_amount;
            $return_url = Yii::$app->urlManager->createUrl("deal/deal_return");
            $timestamp = (time() + 28800) * 1000;
            $vote_amt = $bidMoney - $vote_fee_amt;
            $vote_bind_code = $this->uinfo->heepay_no;

            $coupon_change = round(floatval($bidMoney), 2);
            if ($this->uinfo->coupon <= $coupon_change) {
                $coupon_change = $this->uinfo->coupon;
            }
            $vote_prize_amt = $coupon_change;             //投资奖励金额

            $sign = md5($agent_bill_no . "|" . $agent_id . "|" . $agent_project_code . "|" . $agent_project_name . "|" . $benefit_bind_code . "|" . $note . "|" . $notify_url . "|" . $project_amt . "|" . $return_url . "|" . $timestamp . "|" . $vote_amt . "|" . $vote_bind_code . "|" . $vote_fee_amt . "|" . $vote_prize_amt . "|" . $key);
            Yii::$app->response->charset = 'gb2312';
            $str = '<form action="' . Yii::$app->params['heepay_conf']['AgreeUserVoteProject'] . '" method="POST" id="testform">
                	<input type="hidden" name="agent_bill_no" value="' . $agent_bill_no . '" />
                	<input type="hidden" name="agent_id" value="' . $agent_id . '" />
                	<input type="hidden" name="agent_project_code" value="' . $agent_project_code . '" />
                	<input type="hidden" name="agent_project_name" value="' . iconv("utf-8", "gb2312", $agent_project_name) . '" />
                	<input type="hidden" name="benefit_bind_code" value="' . $benefit_bind_code . '" />
                	<input type="hidden" name="note" value="' . $note . '" />
                	<input type="hidden" name="notify_url" value="' . $notify_url . '" />
                	<input type="hidden" name="project_amt" value="' . $project_amt . '" />
                	<input type="hidden" name="return_url" value="' . $return_url . '" />
                	<input type="hidden" name="timestamp" value="' . $timestamp . '" />
                	<input type="hidden" name="vote_amt" value="' . $vote_amt . '" />
                	<input type="hidden" name="vote_bind_code" value="' . $vote_bind_code . '" />
                	<input type="hidden" name="vote_fee_amt" value="' . $vote_fee_amt . '" />
                	<input type="hidden" name="vote_prize_amt" value="' . $vote_prize_amt . '" />
                	<input type="hidden" name="sign" value="' . $sign . '" />
                </form><script>document.getElementById("testform").submit();</script>';
            $this->renderContent($str);
        }
        $this->showAlert(Yii::$app->urlManager->createUrl("deals"), "提示", '请求参数有误');
    }

    //回调页面
    public function actionDeal_notify()
    {
        if ($request = Yii::$app->request->post()) {
            $agent_bill_no = htmlspecialchars(addslashes(trim($request['agent_bill_no'])));
            $agent_project_code = htmlspecialchars(addslashes(trim($request['agent_project_code'])));
            $project_type = htmlspecialchars(addslashes(trim($request['project_type'])));
            $result_code = htmlspecialchars(addslashes(trim($request['result_code'])));
            $result_msg = addslashes(trim($request['result_msg']));
            $timestamp = htmlspecialchars(addslashes(trim($request['timestamp'])));
            $vote_amt = htmlspecialchars(addslashes(trim($request['vote_amt'])));
            $vote_bind_code = htmlspecialchars(addslashes(trim($request['vote_bind_code'])));
            $vote_fee_amt = htmlspecialchars(addslashes(trim($request['vote_fee_amt'])));
            $vote_note = htmlspecialchars(addslashes(trim($request['vote_note'])));
            $vote_prize_amt = htmlspecialchars(addslashes(trim($request['vote_prize_amt'])));
            $heepayid = 4;
            $payment_info = WwdPayment::findOne(['id'=>intval($heepayid)]);
            $payment_info['config'] = unserialize($payment_info['config']);
            $key = $payment_info['config']['heepay_key'];
            $signKey = md5($agent_bill_no . "|" . $agent_project_code . "|" . $project_type . "|" . $result_code . "|" . iconv("gb2312", "utf-8", $result_msg) . "|" . $timestamp . "|" . $vote_amt . "|" . $vote_bind_code . "|" . $vote_fee_amt . "|" . $vote_note . ($vote_prize_amt ? ("|" . $vote_prize_amt) : "") . "|" . $key);
            $sign = htmlspecialchars(addslashes(trim($request['sign'])));

            if ($signKey == $sign) {
                if(WwdDealLoad::find()->where(['agent_bill_no'=>$agent_bill_no])->count()  ||  $result_code != "0001"){
                    exit("ok");
                }
                $id = substr($agent_project_code, 7, strlen($agent_project_code) - 7);
                $user_info = WwdUser::findOne(['heepay_no'=>$vote_bind_code]);
                $coupon_change = $vote_prize_amt;
                $money_change = floatval($vote_amt) - floatval($coupon_change) + floatval($vote_fee_amt);
                $dealLoadModel = new WwdDealLoad;
                $dealLoadModel->user_id = $user_info->id;
                $dealLoadModel->user_name = $user_info->user_name;
                $dealLoadModel->deal_id = $id;
                $dealLoadModel->money = floatval($vote_amt) + floatval($vote_fee_amt);
                $dealLoadModel->create_time = time();
                $dealLoadModel->agent_bill_no = $agent_bill_no;
                $dealLoadModel->insert();
                $load_id = Yii::$app->db->getLastInsertID();
                if ($load_id > 0) {
                    //更改资金记录
                    $msg = sprintf('编号%s的投标,付款单号%s', $id, $load_id);
                    if ($money_change == round($user_info->money, 2)) {
                        $money_change = $user_info->money;
                    }
                    $this->modify_account(array('money' => - $money_change, 'coupon' => - $coupon_change, 'score' => 0), $user_info->id, $msg);
                    $deal = $this->getDealInfoByDealId($id);
                    $money_change_value = - $money_change;
                    $money_left = round($this->uinfo->money, 2);
                    $changelogModel = new WwdChangeLog();
                    $changelogModel->user_id = $user_info->id;
                    $changelogModel->type_id = 3;
                    $changelogModel->money_change = $money_change_value;
                    $changelogModel->money_left = $money_left;
                    $changelogModel->create_time  = time();
                    $changelogModel->detail = $deal->name;

                    $this->sys_user_status($user_info->id);
                    //超过一半的时候
                    $activefold = 1;
                    $activestart = $this->to_timespan("2015-01-19 00:00:00");/////活动
                    $activeend = $this->to_timespan("2015-03-01 00:00:00");/////活动
                    $start_time = $this->to_timespan("2015-06-16 10:00:00");
                    $end_time = $this->to_timespan("2015-06-23 22:00:00");
                    
                    if (WwdDealLoad::find()->where(['user_id'=>$user_info->id])->count() == 1) {
                        $pointFold = Yii::$app->params['point_fold'];
                        $val = 100 * $pointFold;
                        $msg = "首单送积分 " .$val . "分";
                        $this->pointLog($user_info->id,2, $val,$msg);
                        $this->modify_account(["point" => $val], $user_info->id);
                        if ($user_info["inv_uid"] > 0 && WwdUser::find()->where(['id'=>$user_info->inv_uid,'mobilepassed'=>1])->count()) {
                            $val = 800 * $pointFold;
                            $msg = "邀请用户成功注册送积分 " . $val . "分";
                            $this->pointLog($user_info->inv_uid,2, $val,$msg);
                            WwdUser::updateAllCounters(['point'=>$val],['id'=>$user_info->inv_uid]);

                            $time = $this->get_gmtime();
                            if ($time >= $start_time && $time < $end_time) {
                                WwdUser::updateAllCounters(['experience'=>2000],['id'=>$user_info->inv_uid]);
                                $title = "";
                                $content = "恭喜您成功邀请好友  " . $user_info->real_name . "  " . $user_info->mobile . " 注册投资，获得2000元体验金";
                                $this->send_user_msg($title, $content, 0, $user_info->inv_uid, $this->get_gmtime(), 0, false, 1, 0);
                            }
                        }

                        /*******活动********/
                        if ($this->get_gmtime() >= $activestart && $this->get_gmtime() < $activeend && $vote_amt >= 10000) {
                            $activefold = 5;

                            if (WwdUser::find()->where(['id'=>$user_info->inv_uid])->count()) {
                                $this->awardLog($user_info->id,10);
                                $this->awardLog($user_info->inv_uid,10);
                            }
                        }
                        /*******活动********/
                    }
                    if (WwdUser::find()->where(['id'=>$user_info->inv_uid])->count() == 1) {
                        /*******首笔返利1%*******/
                        $time = $this->get_gmtime();
                        $heepayid = 4;

                        $paymentInfoRes = WwdPayment::find()->where(['id'=>intval($heepayid)])->one();
                        $payment_info = [];
                        $payment_info['config'] = unserialize($paymentInfoRes->config);

                        $heepay_server = Yii::$app->params['heepay_config']['TransitAgentToPerson'];
                        $heepay_no = WwdUser::find()->where(['id'=>$user_info->id])->select('heepay_no')->one();
                        $heepay_no =  $heepay_no->heepay_no;
                        $money = round((floatval($vote_amt) + floatval($vote_fee_amt)) / 100, 2);
                        $reason = "首笔返利1%";
                        if ($money > 1000) {
                            $money = 1000;
                        }
                        $agent_id = $payment_info['config']['heepay_account'];
                        $details = $heepay_no . "^" . $money;
                        $timestamp = (time() + 28800) * 1000;
                        $transit_no = time() . "_" . $user_info->id;
                        $key = $payment_info['config']['heepay_key'];
                        $sign = md5($agent_id . "|" . $details . "|" . $reason . "|" . $timestamp . "|" . $transit_no . "|" . $key);
                        $post_string = "agent_id=$agent_id&details=$details&reason=" . iconv("utf-8", "gb2312", $reason) . "&timestamp=$timestamp&transit_no=$transit_no&sign=$sign";
                        $return = $this->get_post_data($heepay_server, $post_string);
                        $result = explode("|", $return);
                        if ($result[0] == "ret_code=0000") {
                            $this->modify_account(array("money" => $money), $user_info->id, "首单返利1%");
                        }

                        $title = "";
                        $content = "首笔投资返现" . $money . "元已经到账，请您查收";
                        $this->send_user_msg($title, $content, 0, $user_info->id, $this->get_gmtime(), 0, false, 1, 0);
                        /*******首笔返利1%*******/
                    }

                    if ($this->get_gmtime() >= $activestart && $this->get_gmtime() < $activeend) {/////活动
                        if ($vote_amt >= 100000) {
                            $activefold = 5;/////活动
                        }
                        $day_start = $this->to_timespan($this->to_date($this->get_gmtime(), "Y-m-d"));
                        if (WwdDealLoad::find()->where(['user_id'=>$user_info->id])->andWhere(['>=','create_time',$day_start])->count() <= 3) {
                            if ($vote_amt >= 1000) {
                                WwdUser::updateAllCounters(['active_num1'=>1],['id'=>$user_info->id]);
                            } else {
                                WwdUser::updateAllCounters(['active_num2'=>1],['id'=>$user_info->id]);
                            }
                        }
                    } //活动
                    $val =intval($vote_amt / 100 * $GLOBALS['point_fold'] * $activefold);;
                    $msg = "投资送积分 " . $val . "分";
                    $this->pointLog($user_info->id,2, $val,$msg);
                    $this->modify_account(["point" => $val], $user_info->id);

                    if ($deal['deal_status'] == 1 && $deal['progress_point'] >= 50 && $deal['progress_point'] <= 60 && $deal['is_send_half_msg'] == 0) {
                        $msg_conf = get_user_msg_conf($deal['user_id']);
                        //邮件
                        if (app_conf("MAIL_ON")) {
                            if (!$msg_conf || intval($msg_conf['mail_half']) == 1) {
                                $load_tmpl = $GLOBALS['db']->getRowCached("select * from " . DB_PREFIX . "msg_template where name = 'TPL_DEAL_HALF_EMAIL'");
                                $user_info = $GLOBALS['db']->getRow("select email,user_name from " . DB_PREFIX . "user where id = " . $deal['user_id']);
                                $tmpl_content = $load_tmpl['content'];
                                $notice['user_name'] = $user_info['user_name'];
                                $notice['deal_name'] = $deal['name'];
                                $notice['deal_url'] = get_domain() . $deal['url'];
                                $notice['site_name'] = app_conf("SHOP_TITLE");
                                $notice['site_url'] = get_domain() . APP_ROOT;
                                $notice['help_url'] = get_domain() . url("index", "helpcenter");
                                $notice['msg_cof_setting_url'] = get_domain() . url("index", "uc_msg#setting");
                                $GLOBALS['tmpl']->assign("notice", $notice);
                                $msg = $GLOBALS['tmpl']->fetch("str:" . $tmpl_content);
                                $msg_data['dest'] = $user_info['email'];
                                $msg_data['send_type'] = 1;
                                $title = "您的借款列表“" . $deal['name'] . "”招标过半！";
                                $content = addslashes($msg);
                                $this->msgListLog($user_info['email'],1,$title,$content,0,0,$deal['user_id'],$load_tmpl['is_html']);//插入
                            }
                        }
                        //更新
                        WwdDeal::updateAll(['is_send_half_msg'=>1],['id'=>$id]);
                    }
                    echo "ok";
                } else {
                    echo "fail";
                }
            } else {
                echo "fail";
            }
        }
        echo "fail";
    }

    //返回页面
    public function actionDeal_return()
    {
        $request = Yii::$app->request->post();
        $agent_bill_no = htmlspecialchars(addslashes(trim($request['agent_bill_no'])));
        $agent_project_code = htmlspecialchars(addslashes(trim($request['agent_project_code'])));
        $project_type = htmlspecialchars(addslashes(trim($request['project_type'])));
        $result_code = htmlspecialchars(addslashes(trim($request['result_code'])));
        $result_msg = addslashes(trim($request['result_msg']));
        $timestamp = htmlspecialchars(addslashes(trim($request['timestamp'])));
        $vote_amt = htmlspecialchars(addslashes(trim($request['vote_amt'])));
        $vote_bind_code = htmlspecialchars(addslashes(trim($request['vote_bind_code'])));
        $vote_fee_amt = htmlspecialchars(addslashes(trim($request['vote_fee_amt'])));
        $vote_note = htmlspecialchars(addslashes(trim($request['vote_note'])));
        $vote_prize_amt = htmlspecialchars(addslashes(trim($request['vote_prize_amt'])));
        $heepayid = 4;
        $payment_info = $GLOBALS['db']->getRow("select id,config,logo from " . DB_PREFIX . "payment where id=" . intval($heepayid));
        $payment_info['config'] = unserialize($payment_info['config']);
        $key = $payment_info['config']['heepay_key'];
        $signKey = md5($agent_bill_no . "|" . $agent_project_code . "|" . $project_type . "|" . $result_code . "|" . iconv("gb2312", "utf-8", $result_msg) . "|" . $timestamp . "|" . $vote_amt . "|" . $vote_bind_code . "|" . $vote_fee_amt . "|" . $vote_note . ($vote_prize_amt ? ("|" . $vote_prize_amt) : "") . "|" . $key);
        $sign = htmlspecialchars(addslashes(trim($request['sign'])));
        if ($signKey == $sign) {
            $id = substr($agent_project_code, 7, strlen($agent_project_code) - 7);
            if ($result_code == "0001") {
                showSuccess('投标成功', 0, url("index", "deal", array("id" => $id)));
            } else {
                showErr('投标失败', 0, url("index", "deal", array("id" => $id)));
            }
        } else {
            showErr('验证失败', 0, url("shop"));
        }
    }
}