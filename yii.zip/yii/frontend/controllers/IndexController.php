<?php
namespace frontend\controllers;

use app\models\WwdArticle;
use app\models\WwdDeal;
use common\traits\Dealtraits;
use frontend\base\BaseFrontController;
use Yii;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;
use yii\base\Exception;
use yii\base\InvalidParamException;
use yii\base\UserException;
use yii\db\Query;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use yii\web\HttpException;

/**
 * Index controller
 */
class IndexController extends BaseFrontController
{
    use Dealtraits;
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'signup'],
                'rules' => [
                    [
                        'actions' => ['signup'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'verify'=>[
                'class'=>'frontend\actions\VerifyAction'
            ],
            'ajaxCheckField'=>[
                'class'=>'frontend\actions\checkFieldAction'
            ],
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    public function actionIndex()
    {
        $deaList = WwdDeal::find()->where(['publish_wait'=>0])->andWhere(['in','deal_status',[1,2,4]])->orderBy("deal_status ASC,is_recommend DESC,
        (load_money/borrow_amount) DESC, update_time DESC,sort DESC,id DESC")->one();
        $data = [];
        $data['best_list'] = $deaList;
        $articListRes = (new Query())->from('wwd_article a')->select('a.*')
            ->leftJoin('wwd_article_cate ac', '`ac`.`id` = `a`.`cate_id`')
            ->where(['ac.type_id'=>2,'ac.is_effect'=>1,'ac.is_delete'=>0, 'a.is_effect'=>1,'a.is_delete'=>0])
            ->limit(7)
            ->orderBy('a.create_time desc')
            ->all();
        $data['notice_list'] = $articListRes;

        $mediaListRes = WwdArticle::find()->where(['cate_id'=>53])->limit(5)->orderBy('create_time desc')->all();
        $data['media_list'] = $mediaListRes;

        $today = $this->to_timespan($this->to_date($this->get_gmtime(),"Y-m-d 00:00:00"));
        $start_30 = $today - 30*86400;
        $rank_30 = (new Query())->from('wwd_deal_load l')->select('u.mobile,SUM(l.money) AS total')
            ->leftJoin('wwd_user u', 'l.user_id = u.id')
            ->where(['>','l.create_time',$start_30])
            ->groupBy('l.user_id')
            ->orderBy('total DESC')
            ->limit(5)
            ->all();
        $data['rank_30'] = $rank_30;

        $rank_history = (new Query())->from('wwd_deal_load l')->select('u.mobile,SUM(l.money) AS total')
            ->leftJoin('wwd_user u', 'l.user_id = u.id')
            ->groupBy('l.user_id')
            ->orderBy('total DESC')
            ->limit(5)
            ->all();
        $data['rank_history'] = $rank_history;

        return $this->render('index',$data);
    }

    public function actionLogin()
    {
        if (!\Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        } else {
            return $this->render('login', [
                'model' => $model,
            ]);
        }
    }

    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionContact()
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($model->sendEmail(Yii::$app->params['adminEmail'])) {
                Yii::$app->session->setFlash('success', 'Thank you for contacting us. We will respond to you as soon as possible.');
            } else {
                Yii::$app->session->setFlash('error', 'There was an error sending email.');
            }

            return $this->refresh();
        } else {
            return $this->render('contact', [
                'model' => $model,
            ]);
        }
    }

    public function actionAbout()
    {
        return $this->render('about');
    }

    public function actionSignup()
    {
        $model = new SignupForm();
        if ($model->load(Yii::$app->request->post())) {
            if ($user = $model->signup()) {
                if (Yii::$app->getUser()->login($user)) {
                    return $this->goHome();
                }
            }
        }

        return $this->render('signup', [
            'model' => $model,
        ]);
    }

    public function actionRequestPasswordReset()
    {
        $model = new PasswordResetRequestForm();
        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            if ($model->sendEmail()) {
                Yii::$app->getSession()->setFlash('success', 'Check your email for further instructions.');

                return $this->goHome();
            } else {
                Yii::$app->getSession()->setFlash('error', 'Sorry, we are unable to reset password for email provided.');
            }
        }

        return $this->render('requestPasswordResetToken', [
            'model' => $model,
        ]);
    }

    public function actionResetPassword($token)
    {
        try {
            $model = new ResetPasswordForm($token);
        } catch (InvalidParamException $e) {
            throw new BadRequestHttpException($e->getMessage());
        }

        if ($model->load(Yii::$app->request->post()) && $model->validate() && $model->resetPassword()) {
            Yii::$app->getSession()->setFlash('success', 'New password was saved.');

            return $this->goHome();
        }

        return $this->render('resetPassword', [
            'model' => $model,
        ]);
    }
    public function actionTests(){
        $this->testt();
        $a = [];
        if($a == 0){
            echo "123";
        }else{
            echo "ddd";
        }
       /* $query = WwdDeal::find()->where(['user_id'=>5441,'publish_wait'=>0])->andWhere(['in','deal_status',[4,5]]);
        $query->select('sum(borrow_amount)/count(*) ');
        //var_dump($query->createCommand()->getRawSql());
        WwdDeal::find()->where([['in','deal_status',[4,5]],'user_id'=>5441,'publish_wait'=>0])->select('sum(rate)/count(*)');
        $heepay_no = WwdUser::find()->where(['id'=>5441])->select('heepay_no')->one();
        var_dump($heepay_no->heepay_no);
        $only_send = 0;
        $msgboxModel = new WwdMsgBox();
        $msgboxModel->title = 11;
        $msgboxModel->content = addslashes(22);
        $msgboxModel->from_user_id = 11;
        $msgboxModel->to_user_id = 22;
        $msgboxModel->create_time = 22;
        $msgboxModel->system_msg_id = 33;
        $msgboxModel->type = 0;
        $groupKey = 44;
        $msgboxModel->group_key = $groupKey;
        $msgboxModel->is_notice = intval(11);
        //$msgboxModel->fav_id = intval(33);
        $msgboxModel->insert(false);
        $id = Yii::$app->getDb()->getLastInsertID();
var_dump($id);
        if(!$only_send) {
            $msgboxModel->type = 1; //��¼����
            $msgboxModel->insert();
        }*/
    }
    public function actionError()
    {
        if (($exception = Yii::$app->getErrorHandler()->exception) === null) {
            return '';
        }

        if ($exception instanceof HttpException) {
            $code = $exception->statusCode;
        } else {
            $code = $exception->getCode();
        }
        if ($exception instanceof Exception) {
            $name = $exception->getName();
        } else {
            $name = $this->defaultName ?: Yii::t('yii', 'Error');
        }
        if ($code) {
            $name .= " (#$code)";
        }

        if ($exception instanceof UserException) {
            $message = $exception->getMessage();
        } else {
            $message = $this->defaultMessage ?: Yii::t('yii', 'An internal server error occurred.');
        }

        if (Yii::$app->getRequest()->getIsAjax()) {
            return "$name: $message";
        } else {
            return $this->controller->render($this->view ?: $this->id, [
                'name' => $name,
                'message' => $message,
                'exception' => $exception,
            ]);
        }
    }
}
