<?php
namespace frontend\controllers;

use app\models\WwdDeal;
use frontend\base\BaseFrontController;
use Yii;
use yii\data\Pagination;
use yii\filters\AccessControl;

class DealsController extends BaseFrontController
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['index'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'allow' => true,
                        'roles' => ['@'],
                        'denyCallback' => function ($rule, $action) {throw new \Exception('您无权访问该页面');},
                    ],
                ],
            ]
        ];
    }
    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ]
        ];
    }
    public function actionIndex()
    {
        $data = [];
        $dealtype = Yii::$app->request->get('dealtype',0);
        $dealstate = Yii::$app->request->get('dealstate',0);
        $deallimit = Yii::$app->request->get('deallimit',0);
        $profitratio = Yii::$app->request->get('profitratio',0);
        $data['dealtype'] = $dealtype;
        $data['dealstate'] = $dealstate;
        $data['deallimit'] = $deallimit;
        $data['profitratio'] = $profitratio;

        $query = WwdDeal::find()->where(['is_effect' => 1, 'is_delete' => 0,'publish_wait'=>0])->orderBy('sort desc');

        //项目类别
        if($dealtype!="0"){
            $query->andFilterWhere(['type_id'=>$dealtype]);
        }

        //项目状态
        if($dealstate == "1"){
            $query->andFilterWhere(['in','deal_status',[1,2]]);
        }elseif($dealstate == "2"){
            $query->andFilterWhere(['in','deal_status',4]);
        }elseif($dealstate == "3"){
            $query->andFilterWhere(['in','deal_status',3]);
        }
        //项目期限
        if($deallimit=='1'){
            $tmp = explode("to","0to3");
        }elseif($deallimit=='2'){
            $tmp = explode("to","3to6");
        }elseif($deallimit=='3'){
            $tmp = explode("to","6to12");
        }elseif($deallimit=='4'){
            $tmp = explode("to","12to");
        }
        if(isset($tmp) && $tmp[0]!=""){
            $tmp0 = $tmp[0]*30; //天
            $tmp1 = $tmp[0];    //月

            $query->andFilterWhere(['or',
                ['and',
                    ['>=','repay_time',$tmp0],
                    ['repay_time_type'=>0]],
                ['and',
                    ['>=','repay_time',$tmp1],
                    ['repay_time_type'=>1]]]); //and ( repay_time_type = 0 and repay_time >= $a*30 ) or ( repay_time_type = 1 and repay_time >= $a )
            if($tmp[1] != "") {
                $tmp2 = $tmp[1]*30; //天
                $tmp3 = $tmp[1];    //月
                $query->andFilterWhere(['or',
                    ['and',
                        ['<','repay_time',$tmp2],
                        ['repay_time_type'=>0]],
                    ['and',
                        ['<','repay_time',$tmp3],
                        ['repay_time_type'=>1]]]); //and ( repay_time_type = 0 and repay_time >= $a*30 ) or ( repay_time_type = 1 and repay_time >= $a )
            }
        }

        //项目收益
        if($profitratio=='1'){
            $ptmp = explode("to","0to8");
        }elseif($profitratio=='2'){
            $ptmp = explode("to","8to12");
        }elseif($profitratio=='3'){
            $ptmp = explode("to","12to15");
        }elseif($profitratio=='4'){
            $ptmp = explode("to","15to");
        }

        if(isset($ptmp) && $ptmp[0]!=""){
            $query->andFilterWhere(['>=','rate',$ptmp[0]]);
            if($ptmp[1] != ""){
                $query->andFilterWhere(['<','rate',$ptmp[1]]);
            }
        }

        $dealTypes = $this->getLoadType();
        $data['dealTypes'] = $dealTypes;
        $data['dealTypeFilterUrl'] = Yii::$app->urlManager->createUrl("/deals/index")."?".http_build_query(['dealstate'=>$dealstate,
                'deallimit'=>$deallimit,
                'profitratio'=>$profitratio,
            ]);

        $dealStats = Yii::$app->params['dealStats'];
        $data['dealStats'] = $dealStats;
        $data['dealStatsFilterUrl'] =  Yii::$app->urlManager->createUrl("/deals/index")."?".http_build_query(['dealtype'=>$dealtype,
            'deallimit'=>$deallimit,
            'profitratio'=>$profitratio,
        ]);

        $dealLimits = Yii::$app->params['dealLimits'];
        $data['dealLimits'] = $dealLimits;
        $data['dealLimitsFilterUrl'] =  Yii::$app->urlManager->createUrl("/deals/index")."?".http_build_query(['dealtype'=>$dealtype,
            'dealstate'=>$dealstate,
            'profitratio'=>$profitratio,
        ]);

        $profitRatios = Yii::$app->params['profitRatios'];
        $data['profitRatios'] = $profitRatios;
        $data['profitRatiosFilterUrl'] =  Yii::$app->urlManager->createUrl("/deals/index")."?".http_build_query(['dealtype'=>$dealtype,
            'dealstate'=>$dealstate,
            'deallimit'=>$deallimit,
        ]);

        $countQuery = clone $query; //优化实例化对象
        $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
        $data["pages"] = $pages;

        $dealList = $query->select(['id','name','borrow_amount','repay_time_type','load_money','borrow_amount', 'deal_status','rate','repay_time',])
            ->offset($pages->offset)
            ->limit($pages->limit)
            ->all();
        foreach($dealList as &$dl){
            $dl['ratio'] = ($dl['load_money']/$dl['borrow_amount'])*100;
        }
        $data['dealList'] = $dealList;
        return $this->render("index",$data);
    }
}