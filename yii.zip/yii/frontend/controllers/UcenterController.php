<?php
namespace frontend\controllers;

use app\models\WwdArticle;
use app\models\WwdDeal;
use app\models\WwdDealDuanwu;
use app\models\WwdDealDuanwuLoad;
use app\models\WwdDealLoad;
use app\models\WwdDealLoadRepay;
use app\models\WwdDealOrder;
use app\models\WwdExchangeConf;
use app\models\WwdMsgBox;
use app\models\WwdPayment;
use app\models\WwdRegionConf;
use app\models\WwdUser;
use app\models\WwdUserAgency;
use app\models\WwdUserCarry;
use app\models\WwdUserCompany;
use app\models\WwdUserLevel;
use app\models\WwdUserPointLog;
use frontend\base\BaseFrontController;
use Yii;
use common\models\LoginForm;
use frontend\models\PasswordResetRequestForm;
use frontend\models\ResetPasswordForm;
use frontend\models\SignupForm;
use frontend\models\ContactForm;
use yii\base\Exception;
use yii\base\InvalidParamException;
use yii\base\UserException;
use yii\data\Pagination;
use yii\web\BadRequestHttpException;
use yii\filters\AccessControl;
use yii\web\HttpException;

/**
 * Index controller
 */
class UcenterController extends BaseFrontController
{
    public $menuflag = 0;
    public $menupflag = 0;
    public function init(){
        parent::init();
        $this->layout = "ucenter";
        $this->view->params['uinfo'] = $this->uinfo;
        $this->view->params['menuflag'] = &$this->menuflag;
        $this->view->params['menupflag'] = &$this->menupflag;
    }
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'actions' => ['login'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'allow' => true,
                        'roles' => ['@'],
                        'denyCallback' => function ($rule, $action) {
                            throw new \Exception('您无权访问该页面');
                        },
                    ],
                ],
            ]
        ];
    }

    /*个人中心*/
    public function actionIndex()
    {
        $this->menuflag = 0;
        $user_id = $this->uinfo->id;
        $user_info = $this->uinfo;
        $user_count = 0;                                     //暂时页面没有展示
        if ($user_info['mobilepassed'] == 1) {
            $user_count += 1;
        }

        if ($user_info['idcardpassed'] == 1) {
            $user_count += 1;
        }

        if ($user_info['email'] != "") {
            $user_count += 1;
        }

        if ($user_info['pay_pwd'] != "") {
            $user_count += 1;
        }

        $user_count_total = $user_count / 4 * 100;

        //输出公告
        $notice_list = WwdArticle::getNotification(3);           //暂时页面没有展示
        $this->viewParam['notice_list'] = $notice_list;
        $this->viewParam['invest_money'] = $this->getUserAccumuIncome($user_id);

        //待收本金
        $total_invest = WwdDealLoad::getWaitCapital($user_id);
        $repay_invest= WwdDealLoadRepay::getWaitCapital($user_id);

        //满标/还款投资
        $total_lixi = $this->getTotalLixi($user_id);
        if ($user_info['is_company'] == 0) {
            //待收本金
            $total_invest = $total_invest - $repay_invest;
            $this->viewParam['total_invest'] = $total_invest;
            $this->viewParam['total_lixi']   = $total_lixi;

            //全部
            $invest_list['investall_list'] = WwdDealLoad::getLoadRecord($user_id,[1,2,4,5],6);
            //投标中
            $invest_list['investing_list'] = WwdDealLoad::getLoadRecord($user_id,[1,2],6);
            ///还款中
            $invest_list['investrepaying_list'] = WwdDealLoad::getLoadRecord($user_id,[4],6);
            ///已还清
            $invest_list['investrepayed_list'] = WwdDealLoad::getLoadRecord($user_id,[5],6);
            foreach ($invest_list as $invest_k => $invest_v) {
                if(!$invest_v){
                    continue;
                }
                foreach ($invest_v as $k => $v) {
                    if ($v['dealinfo']['deal_status'] >= 4) {
                        $end_time = $v['dealinfo']['repay_start_time'];

                        if ($v['dealinfo']['repay_time_type'] == 1) {
                            for ($i = 0; $i < $v['dealinfo']['repay_time']; $i++) {
                                $end_time = $this->next_replay_month($end_time);
                            }
                        } else {
                            $end_time = $end_time + 86400 * $v['dealinfo']['repay_time'];
                        }
                        $invest_list[$invest_k][$k]['dealinfo']['end_time'] = $this->to_date($end_time, "Y-m-d");
                    } else {
                        $invest_list[$invest_k][$k]['dealinfo']['end_time'] = " - ";
                    }
                    if ($v['dealinfo']['deal_status'] >= 4) {
                        //用户回款
                        //$user_load_ids = $GLOBALS['db']->getAll("SELECT id,deal_id,user_id,money,is_transfer,create_time FROM " . DB_PREFIX . "deal_load WHERE id=" . $v['dlid']);
                        $user_load_ids = WwdDealLoad::findAll(['id'=>$v['id']]);
                        foreach ($user_load_ids as $kk => $vv) {

                            $vparam['repay_start_time'] = $v['dealinfo']['repay_start_time'];
                            $vparam['repay_time'] = $v['dealinfo']['repay_time'];
                            $vparam['rate'] = $v['dealinfo']['rate'];
                            $vparam['create_time'] = $v['create_time'];
                            $vparam['id'] = $v['id'];
                            $vparam['user_id'] = $v['user_id'];
                            $vparam['deal_id'] = $v['deal_id'];
                            $vparam['money'] = $v['money'];
                            $vparam['u_key'] = $kk;
                            if ($v['dealinfo']['repay_time_type'] == 0) {
                                $user_loan_list = $this->get_deal_user_load_list($vparam, $v['dealinfo']['loantype'], $v['dealinfo']['repay_time_type'], $v['dealinfo']);
                            } else {
                                $user_loan_list = $this->get_deal_user_load_list($vparam, $v['dealinfo']['loantype'], $v['dealinfo']['repay_time_type']);
                            }

                            if ($v['dealinfo']['deal_status'] >= 4) {
                                $success_time = $v['dealinfo']['repay_start_time'];
                            } else {
                                $success_time = $this->get_gmtime();
                            }
                            $success_date = $this->to_date($success_time, "Y-m-d 00:00:00");
                            $success_time = $this->to_timespan($success_date);///满标当天0时时间戳


                            $days_time = $success_time - $v['create_time'];
                            if ($days_time <= 0) {
                                $days_time = 0;
                            }
                            $days = ceil($days_time / 86400);
                            if ($v['dealinfo']['loantype'] == 0) {
                                $buxi = round($this->pl_it_formula_day($vv['money'], $v['dealinfo']['rate'] / 365 / 100, $days), 2);
                            } else {
                                $buxi = round($this->av_it_formula_day($vv['money'], $v['dealinfo']['rate'] / 365 / 100, $days), 2);
                            }
                            $self_money = 0;
                            $repay_money = 0;
                            $impose_money = 0;
                            foreach ($user_loan_list as $kkk => $vvv) {
                                if ($vvv['repay_day'] < $this->get_gmtime() - 86400) {
                                    $repay_money = WwdDealLoadRepay::find()->where(['deal_id'=>$v['id'],'user_id'=>$vv['user_id'],'load_id'=>$vvv['id'],'repay_time'=> $vvv['repay_day']])->sum('repay_money');
                                    $repay_money = round($repay_money,2);
                                    $impose_money = WwdDealLoadRepay::find()->where(['deal_id'=>$v['id'],'user_id'=>$vv['user_id'],'load_id'=>$vvv['id'],'repay_time'=> $vvv['repay_day']])->sum('impose_money');
                                    $impose_money = round($impose_money,2);
                                    $self_money = WwdDealLoadRepay::find()->where(['deal_id'=>$v['id'],'user_id'=>$vv['user_id'],'load_id'=>$vvv['id'],'repay_time'=> $vvv['repay_day']])->sum('self_money');
                                    $self_money = round($self_money,2);
                                } else {
                                    $repay_money = round($vvv['month_repay_money'], 2);
                                    $impose_money = round($vvv['impose_money'], 2);
                                    if ($v['dealinfo']['loantype'] == 0) {//等额本息的时候才通过公式计算剩余多少本金
                                        $self_money = round($vv['money'] / $v['dealinfo']['repay_time'], 2);////$vv['month_repay_money'] - get_benjin($kk,$deal['repay_time'],$v['money'],$vv['month_repay_money'],$deal['rate'])*$deal['rate']/12/100;
                                    } elseif ($v['dealinfo']['loantype'] == 1) {//每月还息，到期还本
                                        if ($kkk + 1 == count($user_loan_list)) {//判断是否是最后一期
                                            $self_money = $vv['money'];
                                        } else {
                                            $self_money = 0;
                                        }
                                    } elseif ($v['dealinfo']['loantype'] == 2) {//到期还本息
                                        if ($kkk + 1 == count($user_loan_list)) {//判断是否是最后一期
                                            $self_money = $vv['money'];
                                        } else {
                                            $self_money = 0;
                                        }
                                    }
                                }
                            }
                            $lixi = 0;
                            if ($v['dealinfo']['repay_time_type'] == 0) {
                                if ($v['dealinfo']['deal_status'] != 5) {
                                    $days = intval(($this->to_timespan($this->to_date($this->get_gmtime(), "Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($v['dealinfo']['repay_start_time'], "Y-m-d 00:00:00"))) / 86400);
                                } else {
                                    $days = intval(($this->to_timespan($this->to_date($v['dealinfo']['last_repay_time'], "Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($v['dealinfo']['repay_start_time'], "Y-m-d 00:00:00"))) / 86400);
                                }

                                if ($v['dealinfo']['loantype'] == 0) {
                                    $repay_money = $buxi + round($this->pl_it_formula_day($vv['money'], $v['dealinfo']['rate'] / 365 / 100, $days), 2);
                                } else {
                                    $repay_money = $buxi + round($this->av_it_formula_day($vv['money'], $v['dealinfo']['rate'] / 365 / 100, $days), 2);
                                }
                                $lixi += $repay_money;
                            } else {
                                $lixi += $repay_money - $self_money + $impose_money;
                            }
                            $invest_list[$invest_k][$k]['dealinfo']['income'] = $lixi;
                        }
                    } else {
                        $days = intval(($this->to_timespan($this->to_date($this->get_gmtime(), "Y-m-d 00:00:00")) - $this->to_timespan($this->to_date($v['create_time'], "Y-m-d 00:00:00"))) / 86400);

                        $lixi = $v['money'] * $v['dealinfo']['rate'] / 100 / 365 * $days;
                        $invest_list[$invest_k][$k]['dealinfo']['income'] = $lixi;
                    }
                    $invest_list[$invest_k][$k]['dealinfo']["url"] = Yii::$app->urlManager->createUrl("deal")."?id=".$v['id'];
                }
            }
        } else {
            $where = [1=>1];;
            if ($user_info['is_company'] == 1) {
                $where = ['user_id'=>$user_id];;
            } elseif ($user_info['is_company'] == 2) {
                $where = ['agency_id'=>$user_id];
            }
            $invest_list['investall_list'] = WwdDeal::find()->where($where)->limit(6)->orderBy('create_time Desc')->all();
            $invest_list['investing_list'] = WwdDeal::find()->where($where)->andWhere(['in','deal_status',[1,2]])->limit(6)->orderBy('create_time Desc')->all();
            $invest_list['investrepaying_list'] = WwdDeal::find()->where($where)->andWhere(['in','deal_status',[4]])->limit(6)->orderBy('create_time Desc')->all();;;
            $invest_list['investrepayed_list'] = WwdDeal::find()->where($where)->andWhere(['in','deal_status',[5]])->limit(6)->orderBy('create_time Desc')->all();;;
        }

        $this->viewParam['invest_list'] = $invest_list;
        $all_money = $user_info['money'] + $user_info['lock_money'] + $total_invest + $total_lixi;
        $this->viewParam['all_money'] = $all_money;

        //推荐借款列表
        $deal_list = WwdDeal::getDealList([1,2,4]," deal_status ASC, update_time DESC,sort DESC,id DESC",11);//get_deal_list
        $this->viewParam['best_list'] = $deal_list[0];
        if ($deal_list[0]['agency_id']) {
            $agency_info = WwdUserAgency::findOne(['id'=>$deal_list[0]['agency_id']]);
            $this->viewParam['agency_info'] = $agency_info;
        }

        $kid_i = 0;
        $this->viewParam['kid_i'] = $kid_i;

        //最新借款列表
        $deal_list = WwdDeal::getDealList([1,2,4]," deal_status ASC, update_time DESC,sort DESC,id DESC",5);
        $this->viewParam['deal_list'] = $deal_list;

        ///体验金收益
        $to_date = $this->to_date($this->get_gmtime(), "Y-m-d 00:00:00");
        $time = $this->to_timespan($to_date);///满标当天0时时间戳
        $tiyan_lixi = 0;
        $duanwu_load = WwdDealDuanwuLoad::findAll(['user_id'=>$user_id]);
        $duanwuDealInfo = [];
        foreach ($duanwu_load as $k => $v) {
            if(!isset($duanwuDealInfo[$v['deal_id']])){
                $duanwuDealInfo[$v['deal_id']] = WwdDealDuanwu::findOne(['id'=>$v['deal_id']]);
            }
            $duanwuInfo = $duanwuDealInfo[$v['deal_id']] ;
            $days_time = $time - $this->to_timespan($this->to_date($v['create_time'], "Y-m-d 00:00:00"));

            $days = ceil($days_time / 86400);

            if ($days > $duanwuInfo['repay_time']) {
                $days = $duanwuInfo['repay_time'];
            }

            if ($v['loantype'] == 0) {
                $tiyan_lixi += round($this->pl_it_formula_day($v['money'], $duanwuInfo['rate'] / 365 / 100, $days), 2);
            } else {
                $tiyan_lixi += round($this->av_it_formula_day($v['money'], $duanwuInfo['rate'] / 365 / 100, $days), 2);
            }
        }
        $this->viewParam['tiyan_lixi'] = $tiyan_lixi;
        $this->viewParam['user_data'] = $user_info;
        $this->viewParam['user_count'] = $user_count_total;
        $this->viewParam['seo_title'] = "我的家财猫-家财猫";
        $this->viewParam['seo_keywords'] = "我的家财猫";
        return $this->render("index",$this->viewParam);
    }
    //我的积分
    public function actionScore(){
        $this->menupflag = 4;
        $this->menuflag = 9;

        $query = WwdUserPointLog::find()->where(['user_id'=>$this->uinfo['id']]);
        $countQuery = clone $query; //优化实例化对象
        $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>10]);
        $this->viewParam["pages"] = $pages;

        $exchangeList = $query->offset($pages->offset)
            ->orderBy('dateline DESC')
            ->limit($pages->limit)
            ->all();
        foreach($exchangeList as $v){
            $v->dateline = $this->to_date($v->dateline);
        }
        $this->viewParam['exchangeList'] = $exchangeList;
        $this->viewParam['product_list1'] = WwdExchangeConf::find()->where(['type'=>1])->orderBy('sort ASC')->all();
        $this->viewParam['product_list2'] = WwdExchangeConf::find()->where(['type'=>2])->orderBy('sort ASC')->all();

        return $this->render("score",$this->viewParam);
    }
    //资金统计
    public function actionEarnings(){
        $this->menupflag = 1;
        $this->menuflag = 0;

        $user_id = $this->uinfo['id'];
        //$user_statics = $this->sys_user_status($user_id);   //需要优化

        $repay_invest_arr = WwdDealLoadRepay::getInvestArr($user_id);

        $sum_capital = WwdDealLoad::sumCapital($user_id);
        $sum_capital = $sum_capital - isset($repay_invest_arr['self_money'])?$repay_invest_arr['self_money']:0;
        $user_statics['repay_capital'] = $sum_capital?$sum_capital:0;///待收本金

        $directlist = WwdDealLoad::allDealByuid($user_id);
        $directsum = 0;
        if($directlist){
            foreach($directlist as $k=>$v){
                $deal = $v->deal; //关联查询
                if(!$deal){
                    break;
                }

                if($deal['deal_status']>=4){ //旧的是$v
                    $success_time = $deal['repay_start_time'];
                }else{
                    $success_time = $this->get_gmtime();
                }
                $success_date = $this->to_date($success_time,"Y-m-d 00:00:00");
                $success_time = $this->to_timespan($success_date);///满标当天0时时间戳


                $days_time = $success_time - $v['create_time'];
                if($days_time<=0){
                    $days_time = 0;
                }
                $days = ceil($days_time/86400);
                if($deal['loantype']==0){
                    $buxi = round($this->pl_it_formula_day($v['money'],$deal['rate']/365/100,$days),2);
                }else{
                    $buxi = round($this->av_it_formula_day($v['money'],$deal['rate']/365/100,$days),2);
                }

                if($deal['repay_time_type']==0){
                    if($deal['deal_status']!=5){
                        if($deal['deal_status']>=4){
                            $repay_time = intval(($this->get_gmtime()-$deal['repay_start_time'])/86400);
                        }else{
                            $repay_time = intval(($this->get_gmtime()-$v['create_time'])/86400);
                        }
                    }else{
                        $repay_time = intval(($deal['last_repay_time']-$v['create_time'])/86400);
                    }
                    if($deal['loantype']==0){
                        $directsum += $buxi+round($this->pl_it_formula_day($v['money'],$deal['rate']/365/100,$repay_time),2);

                    }else{
                        $directsum += $buxi+round($this->av_it_formula_day($v['money'],$deal['rate']/365/100,$repay_time),2);

                    }

                }else{
                    $directsum += $buxi+$v['money']*$deal['rate']/100/12*$deal['repay_time'];
                }
            }
        }
        $user_statics['directsum'] = $directsum;      //企业直投待收收益

        $transferlist = WwdDealLoad::allDealByuid($user_id,[2,4],1);

        $transfersum = 0;
        if($transferlist){
            $now = $this->get_gmtime();
            foreach($transferlist as $k=>$v){
                $deal = $v->deal;
                $deal_repay = $this->get_deal_load_list($deal);
                for($i=0;$i<$deal['repay_time'];$i++){
                    if($deal_repay[$i]['repay_day']>$now){
                        break;
                    }
                }
                $need_repay_times = $deal['repay_time'] - $i;
                $transfersum += $need_repay_times*($v['money']*$deal['rate']/100/12);
            }
        }
        $user_statics['transfersum'] = $transfersum;     //债权转让待收收益
        $user_statics['repay_interest'] = $directsum + $transfersum;////待收利息
        $user_statics['repay_all'] = $user_statics['repay_interest'] + $user_statics['repay_capital'];///////待收本息
        $sum_capitaling = WwdDealLoad::sumCapital($user_id,[1,2]);
        $user_statics['sum_capitaling'] = $sum_capitaling?$sum_capitaling:0;////////投标中金额
        $user_statics['sum_assets'] = $this->uinfo['money']+$this->uinfo['lock_money']+$user_statics['repay_all'];
        $this->viewParam['user_statics'] = $user_statics;
        ////充值总金额
        $pay_sum = WwdDealOrder::find()->where(['user_id'=>$user_id,'pay_status'=>2])->sum('deal_total_price');
        $this->viewParam['pay_sum'] = $pay_sum;

        /////提现金额
        $carry_sum = WwdUserCarry::find()->select('SUM(money) as money,SUM(fee) as fee,(SUM(money+fee)) as total')
            ->where(['user_id'=>$user_id,'status'=>1])->one();
        $this->viewParam['carry_sum'] = $carry_sum;

        /////总投资金额
        if($this->uinfo['is_company']==0){
            $invest_sum = WwdDealLoad::find()->where(['user_id'=>$user_id,'is_repay'=>0])->sum('money');
        }elseif($this->uinfo['is_company']==1){
            $invest_sum = WwdDeal::find()->where(['user_id'=>$user_id,'is_repay'=>0])->andWhere(['in','deal_status',[1,2,4,5]])->sum('borrow_amount');
        }elseif($this->uinfo['is_company']==2){
            $invest_sum = WwdDeal::find()->where(['agency_id'=>$user_id,'is_effect'=>1])->andWhere(['in','deal_status',[1,2,4,5]])->sum('borrow_amount');
        }
        if($this->uinfo['is_company']!=3){
            $this->viewParam['invest_sum'] = $invest_sum;

            $has_repay = $invest_sum - $sum_capital;
            $this->viewParam['has_repay'] = $has_repay;
        }

        return $this->render("earnings",$this->viewParam);
    }
    //交易记录
    public function actionInvest(){
        $this->menupflag = 1;
        $this->menuflag = 1;
        $request = Yii::$app->request->get();
        $type = isset($request['type'])?intval($request['type']):1;

        $this->viewParam["type"] = $type;

        if($type==1){
            return $this->getlist("index");
        }elseif($type==2){
            return $this->getrepay();
        }elseif($type==3){
            return $this->getrecharge();
        }elseif($type==4){
            return $this->getcarry();
        }
    }
    //充值
    public function actionIncharge(){
        $this->menupflag = 1;
        $this->menuflag = 2;

        $this->viewParam['pate_title'] = '用户充值';
        //输出支付方式
        $payment_list = WwdPayment::find()->where('is_effect = :is_effect
        and class_name != :class_name
        and class_name != :class_name2
        and online_pay = :online_pay',
            [':is_effect'=>1,
             ':class_name'=>'Voucher',
             ':class_name2'=>'tenpayc2c',
             ':online_pay'=>1
            ])->orderBy('sort desc')->all();
        $this->viewParam['payment_list'] = $payment_list;
        /*foreach($payment_list as $k=>$v)
        {
            if($v['class_name']=='Alipay')
            {
                $cfg = unserialize($v['config']);
                if($cfg['alipay_service']!=2)
                {
                    unset($payment_list[$k]);
                    continue;
                }
            }
            $directory = APP_ROOT_PATH."system/payment/";
            $file = $directory. $v['class_name']."_payment.php";
            if(file_exists($file)){
                require_once($file);
                $payment_class = $v['class_name']."_payment";
                $payment_object = new $payment_class();
                $payment_list[$k]['display_code'] = $payment_object->get_display_code();
            }else{
                unset($payment_list[$k]);
            }
        }
        $GLOBALS['tmpl']->assign("payment_list",$payment_list);*/

        //判断是否有线下支付
        /*$below_payment = $GLOBALS['db']->getRow("select * from ".DB_PREFIX."payment where is_effect = 1 and class_name = 'Otherpay'");
        if($below_payment){
            $directory = APP_ROOT_PATH."system/payment/";
            $file = $directory. $below_payment['class_name']."_payment.php";
            if(file_exists($file))
            {
                require_once($file);
                $payment_class = $below_payment['class_name']."_payment";

                $payment_object = new $payment_class();
                $below_payment['display_code'] = $payment_object->get_display_code();
            }

            $GLOBALS['tmpl']->assign("below_payment",$below_payment);
        }*/

        /*最新充值记录*/
        $user_id = $this->uinfo['id'];

        $payment_log = WwdDealOrder::find()->where(['user_id'=>$user_id,'pay_status'=>2])->orderBy('update_time DESC')->limit(5)->all();
        $this->viewParam['payment_log'] = $payment_log;
        $this->viewParam['seo_title'] = "充值-家财猫";
        $this->viewParam['seo_keywords'] = "充值";
        return $this->render('incharge',$this->viewParam);
    }
    //提现
    public function actionCarry(){
        $this->menupflag = 1;
        $this->menuflag = 3;
        $user_id = $this->uinfo['id'];
        $carry_list = WwdUserCarry::find()->where(['user_id'=>$user_id])->limit(5)->all();
        $this->viewParam['carry_list'] = $carry_list;
        $this->viewParam['seo_title'] = "提现-家财猫";
        $this->viewParam['seo_keywords'] = "提现";
        return $this->render("carry",$this->viewParam);
    }
    //融资申请
    public function actionApply(){
        $this->menupflag = 1;
        $this->menuflag = 4;
    }
    //个人信息
    public function actionProfile(){
        $this->menupflag = 2;
        $this->menuflag = 4;
        $template = "profile";
        if($this->uinfo['is_company'] == 1){
            $user_company = WwdUserCompany::findOne(['user_id'=>$this->uinfo['id']]);
            $identity = explode(",", $user_company['identity']);
            $credit_report_arr = explode(",", $user_company['credit_report']);
            $credit_report = array();
            foreach($credit_report_arr as $k=>$v){
                if($k>0 && $v!=""){
                    $credit_report["credit_".$k] = $v;
                }
            }
            $residence_arr = explode(",", $user_company['residence']);
            $residence = array();
            foreach($residence_arr as $k=>$v){
                if($k>0 && $v!=""){
                    $residence["residence_".$k] = $v;
                }
            }
            $lease_arr = explode(",", $user_company['lease']);
            $lease = array();
            foreach($lease_arr as $k=>$v){
                if($k>0 && $v!=""){
                    $lease["lease_".$k] = $v;
                }
            }
            $public_account_arr = explode(",", $user_company['public_account']);
            $public_account = array();
            foreach($public_account_arr as $k=>$v){
                if($k>0 && $v!=""){
                    $public_account["account_".$k] = $v;
                }
            }

           $this->viewParam["credit_report_main"] = $credit_report_arr[0];
           $this->viewParam["residence_main"] = $residence_arr[0];
           $this->viewParam["lease_main"] = $lease_arr[0];
           $this->viewParam["public_account_main"] = $public_account_arr[0];
           $this->viewParam["identity"] = $identity;
           $this->viewParam["credit_report"] = $credit_report;
           $this->viewParam["residence"] = $residence;
           $this->viewParam["lease"] = $lease;
           $this->viewParam["public_account"] = $public_account;
           $this->viewParam["user_company"] = $user_company;
           return $this->render("compprofile",$this->viewParam);
        }
        return $this->render("profile",$this->viewParam);
    }
    //认证信息
    public function actionCredit(){
        $this->menupflag = 2;
        $this->menuflag = 6;
        $this->viewParam['page_title'] = "认证中心";

        $mobile = $this->uinfo['mobile'];
        $mobile = substr($mobile,0,3)."****".substr($mobile,strlen($mobile)-4,4);
        if($this->uinfo['idcardpassed']==1){
            $idno = $this->uinfo['idno'];
            if(strlen($idno)==18){
                $born = substr($idno,6,4)."-".substr($idno,10,2)."-".substr($idno,12,2);
            }elseif(strlen($idno)==15){
                $born = "19".substr($idno,6,2)."-".substr($idno,8,2)."-".substr($idno,10,2);
            }else{
                $born = " - ";
            }
            $idno = substr($idno,0,1).str_repeat("*", strlen($idno)-2).substr($idno,strlen($idno)-1,1);
            $this->viewParam['idno'] = $idno;
            $this->viewParam['born'] = $born;
        }
        $this->viewParam['mobile'] = $mobile;
        $this->viewParam['seo_title'] = "认证中心-家财猫";
        $this->viewParam['seo_keywords'] = "认证中心";
        return $this->render('credit',$this->viewParam);
    }
    //安全信息
    public function actionSecret(){
        $this->menupflag = 2;
        $this->menuflag = 7;

        $mobile = $this->uinfo['mobile'];
        $mobile = substr($mobile,0,3)."****".substr($mobile,strlen($mobile)-4,4);
        $op = Yii::$app->session->get('pay_mobile_verify_0_ip');
        if($op['time']){
            $wait = $op['time'] + 60 - $this->get_gmtime();
        }else{
            $wait = 0;
        }
        $this->viewParam['wait'] = $wait;
        $this->viewParam['mobile'] = $mobile;
        $this->viewParam['seo_title'] = "安全中心-家财猫";
        $this->viewParam['seo_keywords'] = "安全中心";
        return $this->render("secret",$this->viewParam);
    }
    //消息
    public function actionMsg(){
        $this->menupflag = 3;
        $this->menuflag = 8;
        $getParam = Yii::$app->request->get();
        $mtype = isset($getParam['mtype'])?$getParam['mtype']:null;
        $this->viewParam['mtype'] = $mtype;
        if($mtype=="private"){
            $this->viewParam['pate_title'] = "私信";
            $this->viewParam['post_title'] = "私信";
        }else{
            $this->viewParam['pate_title'] = "通知";
            $this->viewParam['post_title'] = "通知";
        }
        $type = isset($getParam['type'])?$getParam['type']:1;
        $this->viewParam['type'] = $type;
        //分页
        if($mtype == "private"){
            $query = WwdMsgBox::find()->where([
                'is_delete'=>0,
                'system_msg_id'=>0,
                'is_notice'=>0,
            ])->andWhere(['or',
                ['and',
                    ['to_user_id'=>$this->uinfo['id']],
                    ['type'=>0],
                ],
                ['and',
                    ['from_user_id'=>$this->uinfo['id']],
                    ['type'=>1],
                ]
            ])
            ->select('group_key,count(group_key) as total')
            ->groupBy('group_key')
            ->orderBy('system_msg_id desc,max(create_time) desc,is_notice desc ');
        }else{
            $query = WwdMsgBox::find()->where([
                'is_delete'=>0,
                'system_msg_id'=>1,
                'is_notice'=>1,
            ])->andWhere(['or',
                ['and',
                    ['to_user_id'=>$this->uinfo['id']],
                    ['type'=>0],
                ],
                ['and',
                    ['from_user_id'=>$this->uinfo['id']],
                    ['type'=>1],
                ]
            ])
            ->orderBy('create_time DESC');
        }
        if($type==2){
            $query->andFilterWhere(['is_read'=>0]);
        }elseif($type==3){
            $query->andFilterWhere(['is_read'=>1]);
        }
        $countQuery = clone $query; //优化实例化对象
        $page = Yii::$app->params['PAGE_SIZE'];
        $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>$page]);
        $this->viewParam["pages"] = $pages;
        $list = $query->offset($pages->offset)
            ->limit($pages->limit)
            ->all();
        $this->viewParam['msg_list'] = $list;
        $this->viewParam['seo_title'] = "系统消息-家财猫";
        $this->viewParam['seo_keywords'] = "系统消息";
        return $this->render("msg",$this->viewParam);
    }
    //体验金
    public function actionExperience(){
        $this->menupflag = 5;
        $this->menuflag = 10;
        $user_id = $this->uinfo['id'];
		///体验金收益
        $duanwu_load = WwdDealDuanwuLoad::getDealDuanwuLoadByUid($user_id);

		$to_date = $this->to_date($this->get_gmtime(),"Y-m-d 00:00:00");
		$time = $this->to_timespan($to_date);///满标当天0时时间戳

		$tiyan_lixi = 0;

		foreach($duanwu_load as $k=>$v){
			$days_time = $time - $this->to_timespan($this->to_date($v['create_time'],"Y-m-d 00:00:00"));

			$days = intval($days_time/86400);

			if($days > $v['repay_time']){
				$days = $v['repay_time'];
			}
			if($v['loantype']==0){
				$lixi = round($this->pl_it_formula_day($v['money'],$v['rate']/365/100,$days),2);
			}else{
				$lixi = round($this->av_it_formula_day($v['money'],$v['rate']/365/100,$days),2);
			}
			$tiyan_lixi += $lixi;
		}
        $this->viewParam['tiyan_lixi'] = $tiyan_lixi;
        $this->viewParam['duanwu_load'] = $duanwu_load;
        $this->viewParam['seo_title'] = "我的家财猫-家财猫";
        $this->viewParam['seo_keywords'] = "我的家财猫";
        return $this->render("experience",$this->viewParam);
    }
    //邀请invite
    public function actionInvite(){
        $this->menupflag = 6;
        $this->menuflag = 11;

        $query = WwdUser::find()->where(['inv_uid'=>$this->uinfo['id']]);
        $countQuery = clone $query; //优化实例化对象
        $pages = new Pagination(['totalCount' => $countQuery->count(),'defaultPageSize'=>6]);
        $this->viewParam["pages"] = $pages;
        $list = $query->offset($pages->offset)
            ->limit($pages->limit)
            ->all();
        $this->viewParam['list'] = $list;
        return $this->render("invite",$this->viewParam);
    }
    //兑换积分事件
    public function actionExchangescore(){
        $user_id = $this->uinfo['id'];
        if($request = Yii::$app->request->post()){
            $id = intval($request['id']);
            $ajax = intval($request['isajax']);
            $exchangeconf = WwdExchangeConf::findOne(['id'=>$id]);
            if(!$exchangeconf){
                return $this->showAjaxMsg(0,"兑换失败",$ajax);
            }
            if($exchangeconf['type']!=1){
                return $this->showAjaxMsg(0,"话费兑换暂未开放",$ajax);
            }

            if($GLOBALS['user_info']['point']<$exchangeconf['price']){
                return $this->showAjaxMsg(0,"积分不足",$ajax);
            }
            $uinfoPoints = WwdUserPointLog::find()->where(['user_id'=>$user_id,'action_type'=>1])->sum('value');
            if(intval($uinfoPoints)<=-25000 && $this->uinfo['score_access']==0){
                return $this->showAjaxMsg(0,"您兑换的太多了，如有疑问，请联系客服。",$ajax);
            }

            $msg = "兑换 ".($exchangeconf['type']==1?"代金券 ":"话费 ").$exchangeconf['name'];
            $this->modify_account(array('point'=>-($exchangeconf['price']),'coupon'=>($exchangeconf['value'])),$GLOBALS['user_info']['id'],$msg);
            $this->pointLog($user_id,1,-($exchangeconf['price']),$msg);

            return $this->showAjaxMsg(1,"兑换成功",$ajax);
        }
        return $this->showAjaxMsg(0,"请求失败",0);
    }
}
