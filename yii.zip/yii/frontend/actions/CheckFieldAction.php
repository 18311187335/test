<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace frontend\actions;

use app\models\WwdUser;
use frontend\controllers\IndexController;
use kartik\base\Module;
use Yii;
use yii\base\Action;
use yii\web\Response;


class CheckFieldAction extends Action
{
    /**
     * Runs the action.
     */
    public function run()
    {
        $field_name = addslashes(trim($_REQUEST['field_name']));
        $field_data = addslashes(trim($_REQUEST['field_data']));
        $res = $this->checkUser($field_name,$field_data);
        $result = array("status"=>1,"info"=>'');
        if(!$res['status']){
            $error = $res['data'];
            $error_msg = $error['field_name']." ".$error['error'];

            $result['status'] = 0;
            $result['info'] = $error_msg;
        }
        Yii::$app->response->format = Response::FORMAT_JSON;
        return $result;
    }
    private function checkUser($fieldName,$fieldData){
		$fieldNames = [
			'user_name'=>'用户名',
			'email'=>'邮箱',
			'mobile'=>'手机'
		];
        	//开始数据验证
		$user_data[$fieldName] = $fieldData;

		$res = array('status'=>1,'info'=>'','data'=>''); //用于返回的数据
		if($fieldName && (WwdUser::find()->where([$fieldName=>$user_data[$fieldName],'mobilepassed'=>1])->count()) > 0)
		{
			$field_item['field_name'] = $fieldNames[$fieldName];
			$field_item['error']	=	"已存在";
			$res['status'] = 0;
			$res['data'] = $field_item;
			return $res;
		}

		if($fieldName && trim($user_data[$fieldName])=='')
		{
			$field_item['field_name'] = $fieldNames[$fieldName];
			$field_item['error']	=	'不能为空';
			$res['status'] = 0;
			$res['data'] = $field_item;
			return $res;
		}
		if(!$this->validField($fieldName,trim($user_data[$fieldName])))
		{
			$field_item['field_name'] = $fieldNames[$fieldName];
			$field_item['error']	=	"格式不正确";
			$res['status'] = 0;
			$res['data'] = $field_item;
			return $res;
		}
		$verify = new VerifyAction('verify',$this->controller);
		if(isset($user_data['verify']) && !$verify->validate($user_data['verify'],false))
		{
			$field_item['field_name'] = 'verify';
			$field_item['error']	=	"验证码错误";
			$res['status'] = 0;
			$res['data'] = $field_item;
			return $res;
		}
		return $res;
    }
	private function validField($type,$field){
		switch($type){
			case 'email':
				if (!preg_match("/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/", $field)) {
					return false;
				} else
					return true;
				break;
			case 'mobile':
				if (!empty($field) && !preg_match("/^\d{6,}$/", $field)) {
					return false;
				} else
					return true;
				break;
			case 'user_name':
				$preg2= "/^\d+$/i";
				if(preg_match($preg2,trim($field))) {
					return false;
				}
				break;
		}
		return true;
	}
}