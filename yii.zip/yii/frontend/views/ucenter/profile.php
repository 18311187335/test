<!--右栏目start-->
<?php
$uinfo = $this->params['uinfo'];
?>
<div class="AboutContentRight">

	<ul class="AboutContentRight_Title"><h2>个人信息修改</h2></ul>


	<ul class="bid_Resiger_Info">

		<form method="post" action="{url x="shop" r="uc_account#savework"}" name="modify">
		<li><span class="bid_Resiger_Info01">用户名</span><span><i><?php echo $uinfo->user_name;?></i></span></li>
		<li><span class="bid_Resiger_Info01">手机</span><span><i><?php echo $uinfo->mobile;?></i><a href="{url x="index" p="uc_credit"}" class="font_Color01">修改</a></span></li>
		<li>
			<span class="bid_Resiger_Info01">性别</span>
			<span class="bid_Resiger_Info13"><input type="radio" name="sex" <?php if($uinfo->sex == -1){echo 'checked="true"';} ?> value="-1" />保密</span>
			<span class="bid_Resiger_Info13"><input type="radio" name="sex" <?php if($uinfo->sex == 1){echo 'checked="true"';} ?> value="1" />男</span>
			<span class="bid_Resiger_Info13"><input type="radio" name="sex" <?php if($uinfo->sex == 0){echo 'checked="true"';} ?> value="0" />女</span>
		</li>
		<li>
			<span class="bid_Resiger_Info01">QQ</span>
			<span class="bid_Resiger_Info02"><input type="text" name="qq" value="<?php echo $uinfo->qq;?>" class="bid_Resiger_Text" /></span></li>
		<li>
			<span class="bid_Resiger_Info01">&nbsp;</span>
			<span><input type="submit" value="" name="commit" class="bid_Resiger_Submits bid_Resiger_Submits01"  /></span>
		</li>
		</form>
	</ul>
</div>
<!--右栏目end-->