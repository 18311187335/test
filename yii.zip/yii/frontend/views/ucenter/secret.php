<?php
$this->registerJsFile('js/global01.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$uinfo = $this->params['uinfo'];
?>
<!--右栏目start-->
<div class="AboutContentRight">
    <ul class="AboutContentRight_Title"><h2>登录密码修改</h2></ul>
    <ul class="aboutContentRight_Title_Other"><li><p>密码请不要太过简单，建议为字母、数字和符号的组合</p></li></ul>

    <ul class="Trading info03" id="update_Code">
        <a href="javascript:void(0)" class="traHover01">原始密码修改</a>
        <a href="javascript:void(0)">手机验证修改</a>
    </ul>

    <div id="update_Code_Reviews01">

        <ul class="bid_Resiger_Info">
            <form action="{url x="shop" r="uc_center#AuthenPass_Do"}" method="post">
            <li><span class="bid_Resiger_Info01">原始密码</span><span class="bid_Resiger_Info02"><input type="password" name="pass" value="" class="bid_Resiger_Text"  /></span></li>
            <li><span class="bid_Resiger_Info01">新密码</span><span class="bid_Resiger_Info02"><input type="password" name="pass1" value="" class="bid_Resiger_Text"  /></span></li>
            <li><span class="bid_Resiger_Info01">确认密码</span><span class="bid_Resiger_Info02"><input type="password" name="pass2" value="" class="bid_Resiger_Text"  /></span></li>
            <li>
                <span class="bid_Resiger_Info01"><input type="hidden" name="change_type" value="1" />&nbsp;</span>
                <span><input type="submit" name="passauthen" value="" class="bid_Resiger_Submits bid_Resiger_Submits01"  /></span>
            </li>
            </form>
        </ul>

        <ul class="bid_Resiger_Info" style="display:none;">

            <form action="{url x="shop" r="uc_center#AuthenPass_Do"}" method="post" id="change_form">
            <li><span class="bid_Resiger_Info01">手机号码</span><span><i><?php echo $mobile;?></i><a href="##" target="_blank">修改</a></span>
            <li>
                <span class="bid_Resiger_Info01">验证码</span>
                <span class="bid_Resiger_Info03"><input type="text" name="pay_verify_code" value="" id="pay_verify_code" class="bid_Resiger_Code" /></span>
                <span class="bid_Resiger_Info04"><input type="button" class="Buttom_num" value="" id="PhoneYz" onclick="sendmobile(this)"></span></li>
            <li><span class="bid_Resiger_Info01">新密码</span><span class="bid_Resiger_Info02"><input type="password" name="pass1" id="pass1" value="" class="bid_Resiger_Text"  /></span></li>
            <li><span class="bid_Resiger_Info01">确认密码</span><span class="bid_Resiger_Info02"><input type="password" name="pass2" id="pass2" value="" class="bid_Resiger_Text"  /></span></li>
            <li><span class="bid_Resiger_Info01"><input type="hidden" name="change_type" value="2" />&nbsp;</span>
                <span><input type="button" name="passauthen" value="" class="bid_Resiger_Submits bid_Resiger_Submits01" onclick="check_pay_pwd()" /></span>
            </li>
            </form>
        </ul>
    </div>
</div>
<!--右栏目end-->
<?php
$checkPayUrl = Yii::$app->urlManager->createUrl('ucenter/payChangeAjax');
$jsStr = <<<EOF
  var wait=60;
    function time(o) {
        if (wait == 0) {
            o.removeAttribute("disabled");
            $(o).attr("class","Buttom_num");
            o.value="";
            wait = 60;
        } else {
            o.setAttribute("disabled", true);
            $(o).attr("class","Buttom_num_disabled");
            o.value="重新发送(" + wait + ")";
            wait--;
            setTimeout(function() {
                    time(o)
                },
                1000)
        }
    }
    function sendmobile(o){
        get_pay_verify_code();
        time(o);
    }
    function check_pay_pwd(){
        if(!$("#pass1").val())
        {
            $("#pass1").focus();
            $.showErr("密码不能为空");
            return false;
        }
        if(!$.minLength($("#pass1").val(),6,true))
        {
            $.showErr("密码不能少于6个字符");
            return false;
        }
        if($("#pass1").val() != $("#pass2").val())
        {
            $.showErr("两次密码不一致");
            return false;
        }
        var ajaxurl = "$checkPayUrl";
        $.ajax({
            type: "POST",
            url: ajaxurl,
            data: "pay_verify_code="+$("#pay_verify_code").val()+"&pwd="+$("#pass1").val()+"&isajax=1",
            dataType: "json",
            success: function(obj){
                if(obj.status==0){
                    $.showErr(obj.info);
                    return false;
                }else{
                    $("#change_form").submit();
                }
            },
            error:function(ajaxobj)
            {
                return false;
            }
        });
    }
EOF;
$this->registerJs($jsStr);
if($wait>0) {
    $jsStr = <<<EOF
    wait = $wait;
    time(document.getElementById('PhoneYz'));
EOF;
    $this->registerJs($jsStr);
}
?>