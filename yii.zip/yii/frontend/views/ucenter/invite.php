<?php
use common\includes\CommonUtility;
use components\widgets\PageLink;
$uinfo = $this->params['uinfo'];
$webroot = Yii::$app->params['webroot'];
$invturl = Yii::$app->urlManager->createUrl("user/register")."?inv_uid=".$uinfo['id'];
?>
<script type="text/javascript" src="/js/jquery.zclip.js"></script>
<div class="span9 change_span1" style="position:absolute;">
    <div class="row-fluid bottom_line">
        <div class="span12 font-size_18">邀请好友</div>
    </div>
    <div class="row-fluid">
        <div class="span12 line-height_35"> 1，邀请好友注册家财猫</div>
    </div>
    <div class="row-fluid">
        <div class="span12 line-height_35">您的邀请链接：<a href="<?php echo $webroot.$invturl;?>" id="share_url"><?php echo $webroot.$invturl;?></a>
            <span class="copy" id="copy_button"> 复制</span><!-- <span class="share">分享</span> -->
        </div>
    </div>
    <div class="row-fluid">
        <div class="span12 line-height_35"> 2，好友注册家财猫时，请填写您的邀请码或手机号（如果您的好友通过邀请链接注册，邀请码会自动填写）</div>
    </div>
    <div class="row-fluid">
        <div class="span12 line-height_35"> 邀请码<span class="cord"><?php echo $uinfo['id']?></span> </div>
    </div>
    <div class="row-fluid line-height_35 margin_bottom_15">
        <div class="span12 ">3，好友在家财猫投资任意一笔，您即可获得800积分</div>
    </div>
    <div class="row-fluid bottom_line top_line">
        <div class="span12 line-height_50 font-size_18">邀请记录</div>
    </div>
    <div class="row-fluid bottom_line line-height_50">
        <div class="span2">用户账号</div>
        <div class="span2">姓名</div>
        <div class="span3">注册时间</div>
        <div class="span2">手机</div>
        <div class="span1">是否投资</div>
        <div class="span2">积分发放</div>
    </div>
    <?php foreach($list as $user){?>
    <div class="row-fluid bottom_line line-height_35">
        <div class="span2"><?php echo $user['user_name'];?>&nbsp;</div>
        <div class="span2"><?php echo CommonUtility::name_hide($user['real_name']);?>&nbsp;</div>
        <div class="span3"><?php echo CommonUtility::to_date($user['create_time']);?>&nbsp;</div>
        <div class="span2"><?php echo substr($user['mobile'],0,3)."****".substr($user['mobile'],7,4)?>&nbsp;</div>
        <div class="span1"><?php if($user->isLoad){?>是<?php }else{?>否<?php }?></div>
        <div class="span2"><?php if($user->isLoad){?>已发800<?php }else{?>未发<?php }?></div>
    </div>
    <?php }?>
    <div class="nextPage2">
        <?php echo PageLink::widget([
            'activePageCssClass'=>'current',
            'maxButtonCount'=>5,
            'firstPageLabel'=>'第一页',
            'prevPageLabel'=>'上一页',
            'nextPageLabel'=>'下一页',
            'lastPageLabel'=>'最后一页',
            'pagination' => $pages,
        ]);?>
    </div>

</div>
<?php
$jsStr = <<<EOF
        $('#copy_button').zclip({
            path:'/js/ZeroClipboard.swf',
            copy:document.getElementById('share_url').innerHTML
        });
EOF;
$this->registerJs($jsStr);
?>