<!--右栏目start-->
<?php
use common\includes\CommonUtility;
$uinfo = $this->params['uinfo'];
?>
<div class="AboutContentRight">
	<ul class="AboutContentRight_Title"><h2>交易记录</h2></ul>
	<ul class="Trading">
		<a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invest');?>" <?php if($type == 1) {?>class="traHover01"<?php }?>><?php if($uinfo['is_company'] == 0){?>投资记录<?php }elseif($uinfo['is_company'] == 1){?>融资记录<?php }elseif($uinfo['is_company'] == 2){?>担保记录<?php} else{?>所有交易记录<?php }?></a>
		<a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invest')."?type=2";?>" <?php if($type == 2) {?>class="traHover01"<?php }?>>还款记录</a>
		<a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invest')."?type=3";?>" <?php if($type == 3) {?>class="traHover01"<?php }?>>充值记录</a>
		<a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invest')."?type=4";?>" <?php if($type == 4) {?>class="traHover01"<?php }?>>提现记录</a>
	</ul>
	<!--列表start-->
	<div class="money_List">
		<ul class="AboutContentRight_Info02">
			<?php
				if($type == 1) {
					if ($uinfo['is_company'] == 0) {?>
					<li>
						<span class="If_05">项目名称</span>
						<span class="If_04">投资金额</span>
						<span class="If_06">收益率</span>
						<span class="If_04">投资到期日</span>
						<span class="If_04">状态</span>
						<span class="If_05">付息概要</span>
						<span class="If_06">累计收益</span>
					</li>
					<?php
					foreach ($list as $deal) {
						if($deal['deal']['deal_status']==4 || $deal['deal']['deal_status']==5){
							$last_month_time = $deal['deal']['repay_start_time'];
							$last_month_time = $last_month_time + 86400 * $deal['deal']['repay_time'];
						}
						?>
						<li class="About_Right_Info">
							<span class="If_05"><a href="<?php echo Yii::$app->urlManager->createUrl('deal')."?id=".$deal->deal['id'];?>" target="_blank" title="<?php echo $deal->deal['name'];?>"><?php echo mb_substr($deal->deal['name'],0,13);?></a>&nbsp;</span>
							<span class="If_04"><?php echo number_format($deal->money,2);?>&nbsp;</span>
							<span class="If_06"><?php echo $deal->deal['rate'];?>%&nbsp;</span>
							<span class="If_04"><?php if($deal->deal['deal_status'] == 4 || $deal->deal['deal_status'] == 5){ echo CommonUtility::to_date($last_month_time,'Y-m-d');}else{ echo "-";}?>&nbsp;</span>
							<span class="If_04"><?php if($deal->deal['deal_status'] == 1){?>借款进行中<?php }elseif($deal->deal['deal_status'] == 2){?>满标<?php }elseif ($deal->deal['deal_status'] == 4){?>还款中
							<?php }elseif ($deal->deal['deal_status'] == 5){?>已还清<?php }?>&nbsp;</span>
							<span class="If_05"><?php if($deal->deal['loantype'] == 0){?>等额本息<?php }elseif($deal->deal['loantype'] == 1){?>按月付息，到期还本<?php }elseif ($deal->deal['loantype'] == 2){?>到期还本息<?php }?>&nbsp;</span>
							<span class="If_06"><?php echo number_format($deal['more_list_money'],2)?>&nbsp;</span>
						</li>
					<?php }
				}else {
						if ($repay_list) {
							?>
							<h3>待还项目</h3>
							<li>
								<span class="If_05">项目名称</span>
								<span class="If_04">融资规模（元）</span>
								<span class="If_06">融资期限</span>
								<span class="If_04">下一还款日</span>
								<span class="If_04">保证金</span>
								<span class="If_05">还款总额</span>
								<span class="If_06">操作</span>
							</li>
							<?php
							foreach ($repay_list as $deal) {
								?>
								<li class="About_Right_Info">
						<span class="If_05"><a href="{url x=" index" r="deal" p="id=$deal.id"}" target="_blank" title="{$deal.name}">{function name="msubstr" v=$deal.name x="0" y="13"}</a>
							&nbsp;</span>
									<span
										class="If_04">{function name="number_format" v=$deal.borrow_amount}&nbsp;</span>
									<span class="If_06">{$deal.repay_time} {if $deal.repay_time_type eq 0}天{else}月{/if}&nbsp;</span>
								<span
									class="If_04">{function name="to_date" v=$deal.next_repay_time f="Y-m-d"}&nbsp;</span>
									<span class="If_04">{function name="number_format" v="$deal.fee" f=2}&nbsp;</span>
									<span class="If_05">{$deal.repay_total}&nbsp;</span>
						<span class="If_06"><a href="{url x=" index" v="uc_deal#quick_refund" p="id=$deal.id"}">详情</a>
							&nbsp;</span>
								</li>
							<?php }
							?>
							<h3>其它项目</h3>
						<?php } ?>
						<li>
							<span class="If_05">项目名称</span>
							<span class="If_04">融资规模（元）</span>
							<span class="If_06">融资期限</span>
							<span class="If_04">结束日期</span>
							<span class="If_04">保证金</span>
							<span class="If_05">项目状态</span>
							<span class="If_06">还款总额</span>
						</li>
						<?php
						foreach ($list as $deal) {
							?>
							{foreach from=$list item=deal key=key}
							<li class="About_Right_Info">
							<span class="If_05"><a href="{url x=" index" r="deal" p="id=$deal.id"}" target="_blank" title="{$deal.name}">{function name="msubstr" v=$deal.name x="0" y="13"}</a>
								&nbsp;</span>
								<span class="If_04">{function name="number_format" v=$deal.borrow_amount}&nbsp;</span>
							<span
								class="If_06">{$deal.repay_time} {if $deal.repay_time_type eq 0}天{else}月{/if}&nbsp;</span>
								<span class="If_04">{if $deal.deal_status eq 5}{function name="to_date" v=$deal.last_repay_time f="Y-m-d"}{else}-{/if}&nbsp;</span>
								<span class="If_04">{function name="number_format" v="$deal.fee" f=2}&nbsp;</span>
								<span class="If_05">{if $deal.deal_status eq 1}投标中{elseif $deal.deal_status eq 2}满标{elseif $deal.deal_status eq 5}已还清{/if}&nbsp;</span>
								<span class="If_06">{$deal.repay_total}&nbsp;</span>
							</li>
						<?php }
					}
				}elseif($type == 2){
				if ($uinfo['is_company'] == 0) {
					?>
					<li>
						<span class="If_05">项目名称</span>
						<span class="If_04">投资金额（元）</span>
						<span class="If_06">收益率</span>
						<span class="If_04">投资到期日</span>
						<span class="If_04">状态</span>
						<span class="If_05">付息概要</span>
						<span class="If_06">还款金额</span>
					</li>
					<?php
					foreach ($list as $deal) {
						if($deal['deal']['deal_status']==4 || $deal['deal']['deal_status']==5){
							$last_month_time = $deal['deal']['repay_start_time'];
							$last_month_time = $last_month_time + 86400 * $deal['deal']['repay_time'];
						}
						?>
						<li class="About_Right_Info">
							<span class="If_05"><a href="{url x=" index" r="deal" p="id=$deal.id"}" target="_blank" title="<?php echo $deal->deal['name'];?>"><?php echo mb_substr($deal->deal['name'],0,13);?></a>&nbsp;</span>
							<span class="If_04"><?php echo number_format($deal->dealLoad['money'],2);?>&nbsp;</span>
							<span class="If_06"><?php echo $deal->deal['rate'];?>%&nbsp;</span>
							<span class="If_04"><?php echo common\includes\CommonUtility::to_date($last_month_time,'Y-m-d');?>&nbsp;</span>
							<span class="If_04"><?php if($deal->deal['deal_status'] == 1){?>借款进行中<?php }elseif($deal->deal['deal_status'] == 2){?>满标<?php }elseif ($deal->deal['deal_status'] == 4){?>还款中
								<?php }elseif ($deal->deal['deal_status'] == 5){?>已还清<?php }?>&nbsp;</span>
							<span class="If_05"><?php if($deal->deal['loantype'] == 0){?>等额本息<?php }elseif($deal->deal['loantype'] == 1){?>按月付息，到期还本<?php }elseif ($deal->deal['loantype'] == 2){?>到期还本息<?php }?>&nbsp;</span>
							<span class="If_06"><?php if($deal->deal['deal_status'] == 4 || $deal->deal['deal_status'] == 5){echo number_format(($deal->repay_money+ $deal->impose_money),2);}else{echo "-";}?>&nbsp;</span>
						</li>
					<?php }
				} else {
					?>
					<li>
						<span class="If_05">项目名称</span>
						<span class="If_04">借款公司</span>
						<span class="If_06">借款金额</span>
						<span class="If_04">还款金额</span>
						<span class="If_04">还款日</span>
						<span class="If_05">实际还款日</span>
						<span class="If_06">项目状态</span>
					</li>
					<?php
					foreach ($list as $deal) {
						?>
						<li class="About_Right_Info">
							<span class="If_05"><a href="{url x=" index" r="deal" p="id=$deal.id"}" target="_blank" title="{$deal.name}">{function name="msubstr" v=$deal.name x="0" y="13"}</a>
								&nbsp;</span>
							<span class="If_04">{$deal.username}&nbsp;</span>
							<span class="If_06">{function name="number_format" v=$deal.borrow_amount}&nbsp;</span>
							<span class="If_04">{function name="number_format" v=$deal.repay_money f="2"}&nbsp;</span>
							<span class="If_04">{function name="to_date" v=$deal.repay_time f="Y-m-d"}&nbsp;</span>
							<span class="If_05">{function name="to_date" v=$deal.true_repay_time f="Y-m-d"}&nbsp;</span>
							<span class="If_06">{if $deal.deal_status eq 4}还款中{elseif $deal.deal_status eq 5}已还清{/if}&nbsp;</span>
						</li>
					<?php }
				}
			}elseif($type == 3){ ?>
				<li>
					<span class="If_05">订单生成时间</span>
					<span class="If_05">充值订单</span>
					<span class="If_05">充值金额</span>
					<span class="If_04">订单状态</span>
					<span class="If_04">详情</span>
				</li>
				<?php
				foreach ($list as $deal) {
					?>
					<li class="About_Right_Info">
						<span class="If_05"><?php echo common\includes\CommonUtility::to_date($deal->create_time,'Y-m-d');?></span>
						<span class="If_05"><?php echo $deal->order_sn;?></span>
						<span class="If_05"><?php echo number_format($deal->deal_total_price,2);?></span>
						<span class="If_04"><?php if($deal->pay_status == 2){?>支付成功<?php }else{ ?>未成功<?php }?></span>
						<span class="If_04"><?php if($deal->pay_status == 2){?>充值成功<?php }else{ ?>等待支付<?php }?></span>
					</li>
				<?php }
			}elseif($type == 4){?>
			<li>
				<span class="If_05">提现时间</span>
				<span class="If_05">提现金额</span>
				<span class="If_04">提现状态</span>
				<span class="If_05">详情</span>
				<span class="If_05">更新时间</span>
			</li>
			<?php
			foreach ($list as $deal) {
			?>
			<li class="About_Right_Info">
				<span class="If_05"><?php echo common\includes\CommonUtility::to_date($deal->create_time);?></span>
				<span class="If_05"><?php echo number_format($deal->money,2);?></span>
				<span class="If_04"><?php if($deal->status == 0){?>未处理<?php }elseif($deal->status == 1){ ?>提现成功<?php }elseif($deal->status == 2){?>提现失败<?php }?></span>
				<span class="If_05"><?php if($deal->status == 0){?>等待处理<?php }elseif($deal->status == 1){ ?>处理完毕<?php }else{ if($deal->msg){?>
					<a href="javascript:void(0)" onclick="javascript:$.weeboxs.open('<?php echo str_replace("\r\n","<\br>",$deal->msg);?>');">查看详情</a><?php }else{ ?>未注明原因<?php } }?>&nbsp;</span>
					<span class="If_05"><?php if ($deal->update_time){ echo common\includes\CommonUtility::to_date($deal->update_time);}else{echo "-";}?>&nbsp;</span>
			</li>
			<?php }
			}?>
		</ul>
		<div class="BidListPages BidListPages01">
			<?php echo \components\widgets\PageLink::widget([
				'activePageCssClass'=>'current',
				'maxButtonCount'=>5,
				'firstPageLabel'=>'第一页',
				'prevPageLabel'=>'上一页',
				'nextPageLabel'=>'下一页',
				'lastPageLabel'=>'最后一页',
				'pagination' => $pages,
			]);?>
		</div>
	</div>
	<!--列表end-->
</div>
<!--右栏目end-->