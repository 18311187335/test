<!--右栏目start-->
<?php
$uinfo = $this->params['uinfo'];
?>
<div class="AboutContentRight">

    <ul class="AboutContentRight_Title"><h2>实名认证</h2></ul>
    <ul class="aboutContentRight_Title_Other">
        <li>
            <?php
            if($uinfo->heepay_no == ""){
            ?>
            <p>您未绑定汇付宝且未通过实名认证，为了保障您的资金安全，请进行账号绑定！</p>
            <?php } elseif($uinfo->heepay_no != "" && $uinfo->idcardpassed == 0){?>
            <p>您已绑定汇付宝，但未通过实名认证，请联系客服！</p>
            <?php }else{?>
            <p>您已绑定汇付宝，并已通过实名认证！</p>
            <?php }?>
        </li>
    </ul>

    <ul class="bid_Resiger_Info bid_Resiger_Info_Content">
        <li><span class="bid_Resiger_Info01">用户名</span><span><i><?php echo $uinfo->user_name?></i></span></li>
        <li><span class="bid_Resiger_Info01">真实姓名</span><span><i><?php echo $uinfo->real_name?></i></span></li>
        <li><span class="bid_Resiger_Info01">身份证号码</span><span><i class="font_Color01"><?php echo isset($idno)?$idno:"";?></i></span></li>
        <li>
            <span class="bid_Resiger_Info01">&nbsp;</span>
	<span class="name_True_Submit">
        <?php  if($uinfo->heepay_no == ""){?>
			<a href="{url x="index" v="user#heepay_bind"}" title="">
				<img src="/images/jc_57.jpg" width="167" height="36" />
        </a>
        <?php } elseif($uinfo->heepay_no != "" && $uinfo->idcardpassed == 0){?>
			<a href="" title="">
                <img src="/images/jc_69.jpg" width="167" height="36" />
            </a>
        <?php }else{?>
			<img src="/images/jc_68.jpg" width="167" height="36" />
		<?php }?>
	</span>
        </li>
    </ul>


    <ul class="AboutContentRight_Title"><h2>手机认证</h2></ul>
    <ul class="aboutContentRight_Title_Other">
        <li>
            <p>您的手机号码已经通过认证！</p>
        </li>
    </ul>

    <ul class="bid_Resiger_Info bid_Resiger_Info_Content">
        <li><span class="bid_Resiger_Info01">手机号码</span><span><i><?php echo $mobile?></i></span></li>
        <li>
            <span class="bid_Resiger_Info01">&nbsp;</span>
	<span class="name_True_Submit">
		<a href="<?php Yii::$app->urlManager->createUrl('ucenter/mobileChange')?>" title="">
			<img src="/images/jc_change_mobile.jpg" width="167" height="36" />
        </a>
	</span>
        </li>
    </ul>
</div>

<!--右栏目end-->
















