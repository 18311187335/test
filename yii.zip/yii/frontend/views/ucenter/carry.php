<?php
$this->registerCssFile('/css/jquery.lightbox-0.5.css');
$this->registerCssFile('/css/weebox.css');
$this->registerJsFile('/js/jquery.lightbox-0.5.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/dealDetail.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/jquery.weebox.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/script.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/global01.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$uinfo = $this->params['uinfo'];
?>
<!--右栏目start-->
<div class="AboutContentRight">
	<ul class="AboutContentRight_Title"><h2>提现</h2></ul>

	<ul class="AboutContentRight_Info06">
		<form  method="post">
		<li>
			<span class="about_Right_Info03 about_Right_Info003">当前可提现金额：</span>
			<span class="about_Right_Info04"><i><?php echo number_format($uinfo->money,2);?></i>元</span>
		</li>
		<li>
			<span class="about_Right_Info03 about_Right_Info003">提现金额（元）</span>
			<span class="about_Right_Info05"><input type="text" name="amount" value="" onkeyup="incharge_money(this)" /></span>
			<span class="about_Right_Info08"><i id="incharge_money"></i></span>
		</li>
		<li class="about_Right_Info07"><span class="about_Right_Info03 about_Right_Info003">&nbsp;</span><span class="about_Right_Info06"><input type='submit' class="carry" onclick="return confirm('请注意资金只能提现到认证用户本人的银行卡中')" value="" /></span></li>
		</form>
	</ul>

	<ul class="AboutContentRight_Info07">
		<li><i>* 温馨提示：</i></li>
		<li>
			<p>1. 为了您的账户安全，请在提现前进行身份认证、手机绑定以及交易密码设置。</p>
			<p>2. 请注意您的银行卡提现限制，以免造成不便。</p>
			<p>3. 禁止洗钱、信用卡套现、虚假交易等行为，一经发现并确认，将终止该账户的使用。</p>
			<p>4. 如果充值金额没有及时到账，请联系客服，{function name="app_conf" value="SHOP_TEL"}。</p>
		</li>
	</ul>

	<ul class="AboutContentRight_Info08 border03">
		<li><p class="aR_01">订单编号</p><p class="aR_02">订单生成时间</p><p class="aR_03">金额（元）</p><p class="aR_04">订单状态</p></li>
		<?php
		foreach($carry_list as $carry){
			?>
			<li>
				<p class="aR_01"><?php echo $carry->agent_bill_no;?></p>
				<p class="aR_02"><?php echo common\includes\CommonUtility::to_date($carry->create_time);?></p>
				<p class="aR_03"><?php echo number_format($carry->money,2);?></p>
				<p class="aR_04"><?php if ($carry->status == 0){?>处理中<?php }elseif ($carry->status == 1){?>提现成功<?php }elseif($carry->status == 2){?>提现失败，请联系客服<?php }?></p>
			</li>
		<?php } ?>
	</ul>

	<div class="Info_Del Info_Del01"><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invest')."?type=4"?>" title="">查看更多提现记录 >></a></div>
</div>
<!--右栏目end-->
<?php
$jsStr = <<<EOF
	var wait=60;
	function time(o) {
		if (wait == 0) {
			o.removeAttribute("disabled");
			$(o).attr("class","Buttom_num");
			o.value="";
			wait = 60;
		} else {
			o.setAttribute("disabled", true);
			$(o).attr("class","Buttom_num_disabled");
			o.value="重新发送(" + wait + ")";
			wait--;
			setTimeout(function() {
					time(o)
				},
				1000)
		}
	}
	function sendmobile(o){
		get_pay_verify_code();
		time(o);
	}
	function showMyAsk(f) {
		document.getElementById('withdRaw_Reviews').style.visibility= f ? 'visible' : 'hidden';
		document.getElementById('bank_Select').onclick = function () {
			showMyAsk(!f);
		};
	}
	function c_cleanLi(idx) {
		var lis = document.getElementById('withdRaw_Reviews').getElementsByTagName('p');
		for (var i = 0;i < lis.length;i++) {
			lis[i].style.backgroundColor = i == idx ? '#fafafa' : '#ffffff'
		}
	}
	var lis =  document.getElementById('withdRaw_Reviews').getElementsByTagName('p');
	for (var i = 0;i < lis.length;i++) {
		lis[i].liIdx = i;
		lis[i].onclick = function () {
			document.getElementById('bank_Select').value = this.getAttribute('a_v1');
			document.getElementById('card_id').value = this.getAttribute('a_v2');
			document.getElementById('withdRaw_Reviews').style.visibility='hidden';
			document.getElementById('bank_Select').onclick = function () {
				showMyAsk(true);
			};
		}
		lis[i].onmouseover = function () {
			c_cleanLi(this.liIdx);
		}
	}

	function check_verify(){
		var verify = $.trim($("#pay_verify_code").val());
		$.ajax({
			url:APP_ROOT + "/index.php?ctl=uc_money&act=savecarry_ajax",
			data:"pay_verify_code="+verify,
			type:"POST",
			dataType:"json",
			success:function(result){
				if(result.status!=1){
					$.showErr(result.info);
					return false;
				}else{
					$("#Jcarry_From").submit();
				}
			}
		});
	}
EOF;
$this->registerJs($jsStr);
?>


































