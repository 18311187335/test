<!--右栏目start-->
<?php
$uinfo = $this->params['uinfo'];
?>
<div class="AboutContentRight">
<ul class="AboutContentRight_Title"><h2>可用积分</h2></ul>

<ul class="Score"><p><em><?php echo $uinfo['point'];?></em>分</p></ul>

<ul class="score_Line01"></ul>
<ul class="AboutContentRight_Title"><h2>积分商城</h2></ul>
<ul class="integral_Exchange clearfix" id="exchange_id">

<div>
<p class="integral_Exchange_Title"><img src="/images/jc_72.jpg" width="16" height="16" /><i>兑换代金券</i></p>
<p class="integral_Exchange_Info">
<span>兑换金额：</span>
	<?php foreach($product_list1 as $v){?>
		<em class='ditem' eid=<?php echo $v->id?> eprice=<?php echo $v->price?> etype="<?php echo $v->type?>" ><?php echo $v->name?><img src="/images/jc_37.png" width="11" height="11" /></em>
	<?php }?>
</p>
<p class="integral_Exchange_Info">所需积分：<i id="i_1">0</i>分</p>
</div>

<div>
<p class="integral_Exchange_Title"><img src="/images/jc_75.jpg" width="16" height="16" /><i>兑换话费 (暂未开放)</i></p>
<p class="integral_Exchange_Info">
<span>兑换金额：</span>
	<?php foreach($product_list2 as $v){?>
		<em class='ditem' eid=<?php echo $v->id?> eprice=<?php echo $v->price?> etype="<?php echo $v->type?>" ><?php echo $v->name?><img src="/images/jc_37.png" width="11" height="11" /></em>
	<?php }?>
</p>
<p class="integral_Exchange_Info">所需积分：<i id="i_2">0</i>分</p>
<p class="integral_Exchange_Info">手机号码：<?php echo $uinfo['mobile']?></p>
</div>
</ul>

<ul class="sub_exchange">
	<input type="hidden" id="product_id" value="0" autocomplated="off" />
	<p class="integral_Exchange_Submit"><input type="button" value="" id="exchangeAct" /></p>
</ul>


<ul class="AboutContentRight_Title">
	<h2>积分记录<a href="<?php echo Yii::$app->urlManager->createUrl('news').'?cate_id=19&id=247'?>" style="float:right;font: normal 15px/20px '微软雅黑';" target="_blank">查看积分规则＞</a></h2>
	
</ul>

<ul class="Transaction_records">
	<?php
	foreach($exchangeList as $v){
	?>
	<p>
		<span class="records01"><?php echo $v->msg;?></span>
		<span class="records02"><?php echo $v->value;?></span>
		<span class="records03"><?php echo $v->dateline;?></span>
	</p>
	<?php } ?>
<div class="BidListPages BidListPages01">
	<?php echo \components\widgets\PageLink::widget([
		'activePageCssClass'=>'current',
		'maxButtonCount'=>5,
		'firstPageLabel'=>'第一页',
		'prevPageLabel'=>'上一页',
		'nextPageLabel'=>'下一页',
		'lastPageLabel'=>'最后一页',
		'pagination' => $pages,
	]);?>
</div>
</ul>
</div>
<?php
$csrf = Yii::$app->request->csrfToken;
$exchangeUrl = Yii::$app->urlManager->createUrl('ucenter/exchangescore');
$jsStr = <<<EOF
	$('.ditem').click(function(){
	   id = $(this).attr('eid');
	   price = $(this).attr('eprice');
	   type = $(this).attr('etype');
		sel_exchange(this,id,price,type);
	})
	$('#exchangeAct').click(function(){
	    exchange();
	})
	function sel_exchange(obj,id,price,type){
		$("#exchange_id em").each(function(){
			$(this).removeClass("integral");
		})
		$(obj).addClass("integral");
		if(type==1){
			document.getElementById("i_1").innerHTML = price;
			document.getElementById("i_2").innerHTML = '0';
		}else{
			document.getElementById("i_1").innerHTML = '0';
			document.getElementById("i_2").innerHTML = price;
		}
		document.getElementById("product_id").value = id;
	}
	
	function exchange(){
		var id = parseInt(document.getElementById("product_id").value);
		if(confirm("确认兑换？")){
			$.ajax({

				url:"$exchangeUrl",

				data:"id="+id.toString()+"&isajax=1"+"&_csrf=$csrf",

				type:"POST",

				dataType:"json",

				success:function(result){
					if(result.status==1){
						$.showErr(result.info,function(){
							window.location.reload();
							});
						
					}else{
						$.showErr(result.info);
					}
				}

			});
		}return false;
	}
EOF;
$this->registerJs($jsStr);
?>
<!--右栏目end-->