<?php
$uinfo = $this->params['uinfo'];
$this->registerJsFile('js/highcharts.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
?>
<div class="AboutContentRight">
	<ul class="AboutContentRight_Title"><h2>资产统计</h2></ul>
	<ul class="AboutContentRight_Info05 clearfix">
		<?php if($uinfo->is_company == 0){?>
		<div class="AboutContentRight_Info05_Left AboutContentRight_Info05_Left_Con01">
			<li><p class="rT_09">可用余额 </p><p class="rT_10"><i><?php echo number_format($uinfo['money'],2);?></i>元</p></li>
			<li><p class="rT_09">待收利息</p><p class="rT_10"><i><?php echo number_format($user_statics['repay_interest'],2);?></i>元</p></li>
			<li><p class="rT_09">待收本金</p><p class="rT_10"><i><?php echo number_format($user_statics['repay_capital'],2);?></i>元</p></li>
			<li><p class="rT_09 tZ_01">冻结资金 </p><p class="rT_10"><i><?php echo number_format($uinfo['lock_money'],2);?></i>元</p></li>
			<li><p class="rT_09">资产总计</p><p class="rT_10"><i><?php echo number_format($user_statics['sum_assets'],2);?></i>元</p></li>
		</div>
		<?php }elseif($uinfo->is_company == 1){ ?>
		<div class="AboutContentRight_Info05_Left AboutContentRight_Info05_Left_Con01">
			<li><p class="rT_09">可提现余额 </p><p class="rT_10"><i><?php echo number_format($uinfo['money'],2);?></i>元</p></li>
			<li><p class="rT_09 tZ_01">冻结资金 </p><p class="rT_10"><i><?php echo number_format($uinfo['lock_money'],2);?></i>元</p></li>
			<li><p class="rT_09">资产总计</p><p class="rT_10"><i><?php echo number_format($user_statics['sum_assets'],2);?></i>元</p></li>
		</div>
		<?php }elseif($uinfo->is_company == 2){ ?>
		<div class="AboutContentRight_Info05_Left AboutContentRight_Info05_Left_Con01">
			<li><p class="rT_09">可提现余额 </p><p class="rT_10"><i><?php echo number_format($uinfo['money'],2);?></i>元</p></li>
			<li><p class="rT_09 tZ_01">冻结资金 </p><p class="rT_10"><i><?php echo number_format($uinfo['lock_money'],2);?></i>元</p></li>
			<li><p class="rT_09">资产总计</p><p class="rT_10"><i><?php echo number_format($user_statics['sum_assets'],2);?></i>元</p></li>
		</div>
		<?php }elseif($uinfo->is_company == 3){ ?>
		<div class="AboutContentRight_Info05_Left AboutContentRight_Info05_Left_Con01">
			<li><p class="rT_09">可提现余额 </p><p class="rT_10"><i><?php echo number_format($uinfo['money'],2);?></i>元</p></li>
			<li><p class="rT_09 tZ_01">冻结资金 </p><p class="rT_10"><i><?php echo number_format($uinfo['lock_money'],2);?></i>元</p></li>
			<li><p class="rT_09">资产总计</p><p class="rT_10"><i><?php echo number_format($user_statics['sum_assets'],2);?></i>元</p></li>
		</div>
		<?php }?>
		<div class="AboutContentRight_Info05_Left01"  id="ConAssetsList_Con02"></div>
	</ul>

	<ul class="Reviews04">
		<h2>资金流向</h2>
		<li><p class="flow_01">累计充值总额</p><p class="flow_02"><?php echo number_format($pay_sum,2);?></p><p class="flow_03">--</p></li>
		<li><p class="flow_01">累计提现总额</p><p class="flow_02"><?php echo number_format((isset($carry_sum['total'])?$carry_sum['total']:0),2);?></p><p class="flow_03">累积提现到账总额 <?php echo number_format((isset($carry_sum['money'])?$carry_sum['money']:0),2);?>    +     累计提现手续费<?php echo number_format($carry_sum['fee'],2);?></p></li>
		<?php
		if($uinfo['is_company'] == 0){
		?>
		<li>
			<p class="flow_01">累计投资总额</p>
			<p class="flow_02"><?php echo number_format($invest_sum,2);?></p>
			<p class="flow_03">
				正在投资总额<?php echo number_format($user_statics['repay_capital'],2);?>
				+    已结算投资总额<?php echo number_format($has_repay,2);?></p>
		</li>
		<?php }elseif($uinfo->is_company == 1){ ?>
		<li>
			<p class="flow_01">累计融资总额</p>
			<p class="flow_02"><?php echo number_format($invest_sum,2);?></p>
			<p class="flow_03">--</p>
		</li>
		<?php }elseif($uinfo->is_company == 2){ ?>
		<li>
			<p class="flow_01">累计担保佣金</p>
			<p class="flow_02"><?php echo number_format($invest_sum,2);?></p>
			<p class="flow_03">--</p>
		</li>
		<?php }?>
	</ul>


</div>
<!--右栏目end-->
<?php
if($uinfo->is_company == 0) {
	$jsonData ='data: [
					["可用余额",'.$uinfo['money'].'],
					["待收收益",'.$user_statics['repay_interest'].'],
					["待收本金",'.$user_statics['repay_capital'].'],
					["冻结资金",'.$uinfo['lock_money'].']
				],';
}else{
	$jsonData ='data: [
	              ["可提现余额",'.$uinfo['money'].'],
					["冻结资金",'.$uinfo['lock_money'].']
					["投标中金额",'.$user_statics['sum_capitaling'].'],
				],';
}
$jsStr = <<<EOF
		$('#ConAssetsList_Con02').highcharts({
			chart: {
				plotBackgroundColor: null,
				plotBorderWidth: null,
				plotShadow: false,
				width:245,
				height:245
			},
			title: {
				text: ''
			},
			tooltip: {
				pointFormat: '<b>{point.y}</b>'
			},
			plotOptions: {
				pie: {
					allowPointSelect: true,
					cursor: 'pointer',
					dataLabels: {
						enabled: false
					}
				}
			},
			series: [{
				innerSize:'60%',
				type: 'pie',
				name: 'Browser share',
				$jsonData
	       }]
	    });
EOF;
$this->registerJs($jsStr);
?>















