<!--第一频道start-->
<?php
use common\includes\CommonUtility;
$uinfo = $this->params['uinfo'];
?>
<div class="center_People">
    <!--左栏目start-->
    <div class="center_People_Left">
        <ul class="center_People_Img"><p>
            <img src="{function name="get_user_avatar" uid=$user_info.id type="middle"}" width="101" height="101" id="avatar" />
            <label href="javascript:void(0)" onclick="upd_file(this,'avatar_file',<?php echo $uinfo->id;?>)">
                <input type="file" name="avatar_file" id="avatar_file" />
            </label>
        </p></ul>
        <ul class="center_People_Info">
            <li>
                <p>
                    <b style="float:left;"><?php echo $uinfo->user_name?></b>
                    <i style="float:left;margin-left:20px;">您的用户ID：<?php echo $uinfo->id?></i>
                    <i>欢迎您！</i>
                </p>
            </li>
            <li style="clear:both;">
                <?php if($uinfo->heepay_no == ""){?>
                <p><a href="{url x="index" v="user#heepay_bind"}" class="not_bind"></a></p>
                <?php }else{?>
                <p><span class="is_bind"></span></p>
                <?php }?>
                <p><a href="{url x="index" v="zongzi"}" class="to_deal" ></a></p>
            </li>
        </ul>
    </div>
    <!--左栏目end-->
    <!--右栏目start-->
    <div class="center_People_Right">
        <li><p>体验金可用余额<i><?php echo number_format($uinfo->experience,2)?></i></p></li>
    </div>
    <!--右栏目end-->
</div>
<!--第一频道end-->
<!--第二频道start-->
<ul class="AboutContentRight_Tabs">
    <a href="javascript:void(0)" target="_self">
        体验金收益<br /><i><?php echo number_format($tiyan_lixi,2)?></i>
    </a>
</ul>
<div class="AboutContentRight_Tabs_Reviews">
    <!--1-->
    <div>
        <ul class="reviews_Tab border02" id="reviews_Tab">
            <h3>最新动态</h3>
            <a href="javascript:void(0)" title="" class="current">全部</a>
        </ul>
        <div class="reviews_Tab_Reviews" id="reviews_Tab_Reviews">
            <!--1start-->
            <ul>
                <?php if($uinfo->is_company == 0) { ?>
                    <li>
                        <p class="rT_01 tZ_02" style="width:315px !important;">项目名称</p>

                        <p class="rZ_01">年化收益</p>

                        <p class="rZ_01">投资金额</p>

                        <p class="rT_03 tZ_03">投资到期日</p>

                        <p class="rZ_01">投资收益</p>

                        <p class="rZ_01">还款状态</p>
                    </li>
                    <?php
                }else{
                    foreach($duanwu_load as $load){
                        $days_time = $time - CommonUtility::to_timespan(CommonUtility::to_date($v['create_time'],"Y-m-d 00:00:00"));

                        $days = intval($days_time/86400);

                        if($days > $v['repay_time']){
                            $days = $v['repay_time'];
                        }

                        $end_time = $this->to_date($v['create_time']+86400*$v['repay_time'],"Y-m-d");

                        if($v['loantype']==0){
                            $lixi = round(CommonUtility::pl_it_formula_day($v['money'],$v['rate']/365/100,$days),2);
                        }else{
                            $lixi = round(av_it_formula_day($v['money'],$v['rate']/365/100,$days),2);
                        }
                    ?>
                    <li>
                        <p class="rT_01 tZ_02" style="width:315px !important;"><a href="{url x="index" v="deal_duanwu" p="id=$load.id"}" target="_blank"><?php echo $load->dealDuanwu->name?></a></p>
                        <p class="rZ_01"><?php echo $load->dealDuanwu->rate;?>%</p>
                        <p class="rZ_01"><?php echo number_format($load->money,2);?></p>
                        <p class="rT_03 tZ_03"><?php echo $end_time;?></p>
                        <p class="rZ_01"><?php echo number_format($lixi,2);?></p>
                        <p class="rZ_01"><?php if ($load->is_repay == 1){?>已还款<?php }else{?>未还款<?php }?></p>
                    </li>
                    <?php }
                }?>
            </ul>
            <!--1end-->
        </div>
    </div>
    <!--1-->
</div>
<!--第二频道end-->
<script type="text/javascript" src="/js/ajaxupload.js"></script>
<?php
$jsStr = <<<EOF
    function upd_file(obj,file_id,uid)
    {
        $("input[name='"+file_id+"']").bind("change",function(){
            $(obj).hide();
            $(obj).parent().find(".fileuploading").removeClass("hide");
            $(obj).parent().find(".fileuploading").removeClass("show");
            $(obj).parent().find(".fileuploading").addClass("show");
            $.ajaxFileUpload
            (
                    {
                        url:'/index.php?ctl=avatar&act=upload&uid='+uid,
                        secureuri:false,
                        fileElementId:file_id,
                        dataType: 'json',
                        success: function (data, status)
                        {
                            $(obj).show();
                            $(obj).parent().find(".fileuploading").removeClass("hide");
                            $(obj).parent().find(".fileuploading").removeClass("show");
                            $(obj).parent().find(".fileuploading").addClass("hide");
                            if(data.status==1)
                            {
                                document.getElementById("avatar").src = data.middle_url+"?r="+Math.random();
                            }
                            else
                            {
                                $.showErr(data.msg);
                            }
                        },
                        error: function (data, status, e)
                        {
                            $.showErr(data.responseText);;
                            $(obj).show();
                            $(obj).parent().find(".fileuploading").removeClass("hide");
                            $(obj).parent().find(".fileuploading").removeClass("show");
                            $(obj).parent().find(".fileuploading").addClass("hide");
                        }
                    }
            );
            $("input[name='"+file_id+"']").unbind("change");
        });
    }
EOF;
$this->registerJs($jsStr);
?>
