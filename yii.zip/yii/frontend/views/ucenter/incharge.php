<!--右栏目start-->
<?php
$this->registerJsFile('js/global01.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$uinfo = $this->params['uinfo'];
?>
<div class="AboutContentRight">
    <ul class="AboutContentRight_Title"><h2>充值</h2></ul>
    <form name="incharge_form" id="incharge_form"  method="post" >
    <ul class="AboutContentRight_Info06">
        <li><span class="about_Right_Info03">当前可用余额：</span><span class="about_Right_Info04"><i><?php echo number_format($uinfo->money,2);?></i>元 + <i><?php echo number_format($uinfo->coupon,2);?></i> 元奖励</span></li>
        <li>
            <span class="about_Right_Info03">充值金额（元）</span>
            <span class="about_Right_Info05"><input type="text" id="money" name="money" value=""
                                                    onkeyup="incharge_money(this)"/></span>
            <span class="about_Right_Info08"><i id="incharge_money"></i></span>
        </li>
        <li class="about_Right_Info07">
            <span class="about_Right_Info03">&nbsp;</span>
            <span class="about_Right_Info06"><input type='button' id="incharge_done" autocomplete="off"
                                                    value=""/></span>
        </li>
    </ul>
    </form>
    <ul class="AboutContentRight_Info07">
        <li><i>* 温馨提示：</i></li>
        <li>
            <p>1. 为了您的账户安全，请在充值前进行身份认证、汇付宝绑定设置。</p>

            <p>2. 您的账户资金将由第三方平台托管。</p>

            <p>3. 请注意您的银行卡充值限制，以免造成不便。</p>

            <p>4. 禁止洗钱、信用卡套现、虚假交易等行为，一经发现并确认，将终止该账户的使用。</p>

            <p>5. 如果充值金额没有及时到账，请联系客服，{function name="app_conf" value="SHOP_TEL"}。</p>
        </li>
    </ul>
    <ul class="AboutContentRight_Info08 border03">
        <li><p class="aR_01">订单编号</p>
            <p class="aR_02">订单生成时间</p>
            <p class="aR_03">金额（元）</p>
            <p class="aR_04">订单状态</p></li>
        <?php
        foreach($payment_log as $payment){
        ?>
        <li>
            <p class="aR_01"><?php echo $payment->order_sn;?></p>
            <p class="aR_02"><?php echo common\includes\CommonUtility::to_date($payment->create_time);?></p>
            <p class="aR_03"><?php echo number_format($payment->deal_total_price,2);?></p>
            <p class="aR_04">支付成功</p>
        </li>
        <?php } ?>
    </ul>
    <div class="Info_Del Info_Del01"><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invest')."?type=3"?>" title="">查看更多交易记录 >></a></div>
</div>
<!--右栏目end-->
<?php
$jsStr = <<<EOF
    $("#incharge_done").click(function () {
        if (!($("input[name='money']").val() != '' && !isNaN($("input[name='money']").val()) && $("input[name='money']").val() > 0)) {
            $.showErr("请输入充值金额");
            return false;
        } else {
            document.getElementById("incharge_form").submit();
        }
    });
EOF;
$this->registerJs($jsStr); ?>
