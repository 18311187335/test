<!--第一频道start-->
<?php
$uinfo = $this->params['uinfo'];
?>
<div class="center_People">
    <!--左栏目start-->
    <div class="center_People_Left">
        <ul class="center_People_Img"><p>
                <img src="{function name=" get_user_avatar" uid=$user_info.id type="middle"}" width="101" height="101"
                id="avatar" />
                <label href="javascript:void(0)" onclick="upd_file(this,'avatar_file',{$user_info.id});">
                    <input type="file" name="avatar_file" id="avatar_file"/>
                </label>
            </p>
        </ul>
        <ul class="center_People_Info">
            <li>
                <p>
                    <b style="float:left;"><?php echo $uinfo['user_name']?></b>
                    <i style="float:left;margin-left:20px;">您的用户ID：<?php echo $uinfo['id']?></i>
                    <i>欢迎您！</i>
                </p>
            </li>
            <li style="clear:both;">
                <?php if(!$uinfo['heepay_no']){?>
                <p><a href="<?php echo Yii::$app->urlManager->createUrl('user/heepay_bind')?>" class="not_bind"></a></p>
                <?php }else{ ?>
                <p><span class="is_bind"></span></p>
                <?php }?>
                <p><a href="<?php echo Yii::$app->urlManager->createUrl('deals')?>" class="to_deal" ></a></p>
            </li>
        </ul>
    </div>
    <!--左栏目end-->
    <!--右栏目start-->
    <div class="center_People_Right">
        <li><p><i><?php echo number_format($uinfo['money'],2)?></i>元可用余额</p></li>
        <li><p><i><?php echo number_format($uinfo['coupon'],2)?></i>元网站抵用券</p></li>
        <li>
            <a href="{url x=" index" r="uc_money#incharge"}" title="">充值</a>
            <a href="{url x=" index" r="uc_money#carry"}" title="">提现</a>
        </li>
    </div>
    <!--右栏目end-->
</div>
<!--第一频道end-->
<!--第二频道start-->
<ul class="AboutContentRight_Tabs">
    <a href="javascript:void(0)" target="_self" class="TabHover">
        账户总资产<br/><i><?php echo number_format($all_money,2)?></i>
    </a>
    <a href="javascript:void(0)" target="_self">
        累计收益<br/><i><?php echo number_format($invest_money,2)?></i>
    </a>
    <a href="javascript:void(0)" target="_self">
        体验金收益<br/><i><?php echo number_format($tiyan_lixi,2)?></i>
    </a>
</ul>
<div class="AboutContentRight_Tabs_Reviews">
    <!--1-->
    <div>
        <?php if($uinfo['is_company'] == 0){?>
        <table width='100%' style='line-height:28px;font-size:14px;'>
            <tr>
                <td width='20%' align='center'>可用金额</td>
                <td align='center'>+</td>
                <td width='20%' align='center'>奖金账户</td>
                <td align='center'>+</td>
                <td width='20%' align='center'>待收本金</td>
                <td align='center'>+</td>
                <td width='20%' align='center'>待收利息</td>
                <td align='center'>+</td>
                <td width='20%' align='center'>提现冻结金额</td>
            </tr>
            <tr>
                <td align='center' style='color:#3e3e3e;'><?php echo number_format($uinfo['money'],2)?></td>
                <td align='center'></td>
                <td align='center' style='color:#3e3e3e;'><?php echo number_format($uinfo['coupon'],2)?></td>
                <td align='center'></td>
                <td align='center' style='color:#3e3e3e;'><?php echo number_format($total_invest,2)?></td>
                <td align='center'></td>
                <td align='center' style='color:#3e3e3e;'><?php echo number_format($total_lixi,2)?></td>
                <td align='center'></td>
                <td align='center' style='color:#3e3e3e;'><?php echo number_format($uinfo['lock_money'],2)?></td>
            </tr>
        </table>
        <?php }else{ ?>
        <table width='300px' style='line-height:28px;font-size:14px;'>
            <tr>
                <td width='40%' align='center'>可用金额</td>
                <td width='20%' align='center'>+</td>
                <td width='40%' align='center'>提现冻结金额</td>
            </tr>
            <tr>
                <td align='center' style='color:#3e3e3e;'>{function name="number_format" v="$user_info.money" f=2}</td>
                <td align='center'></td>
                <td align='center' style='color:#3e3e3e;'>{function name="number_format" v="$user_info.lock_money"
                    f=2}
                </td>
            </tr>
        </table>
        <?php } ?>
        <ul class="reviews_Tab border02" id="reviews_Tab">
            <?php if($uinfo['is_company'] == 0 ){?>
            <h3>最新动态</h3>
            <?php }elseif($uinfo['is_company'] == 1){?>
            <h3>融资动态</h3>
            <?php }elseif($uinfo['is_company'] == 2){?>
            <h3>担保动态</h3>
            <?php }?>
            <a href="javascript:void(0)" title="" class="current">全部</a>
            <a href="javascript:void(0)" title="">投标中</a>
            <a href="javascript:void(0)" title="">还款中</a>
            <a href="javascript:void(0)" title="">已还清</a>
        </ul>
        <div class="reviews_Tab_Reviews" id="reviews_Tab_Reviews">
            <!--1start-->
            <ul>
                <?php
                if($uinfo['is_company'] == 0){ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年化收益</p>
                        <p class="rZ_01">投资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">投资收益</p>
                    </li>
                    <?php
                    foreach($invest_list['investall_list'] as $il){
                        ?>
                    <li>
                        <p class="rT_01 tZ_02">
                            <a href="<?php echo Yii::$app->urlManager->createUrl('deal')."?id=".$il['dealinfo']['id'];?>" target="_blank"><?php echo $il['dealinfo']['name'];?></a>
                        </p>
                        <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>%</p>
                        <p class="rZ_01"><?php echo number_format($il['money'],0);?></p>
                        <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['end_time'];?></p>
                        <p class="rZ_01"><?php echo number_format($il['dealinfo']['income'],2);?></p>
                    </li>
                    <?php
                    }
                }else{ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年利率</p>
                        <p class="rZ_01">融资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">融资期限</p>
                    </li>
                    <?php
                    foreach($invest_list['investall_list'] as $il){
                        ?>
                    <li>
                        <p class="rT_01 tZ_02"><a href="{url x=" index" v="deal" p="id=$invest.id"}"
                            target="_blank"><?php echo $il['dealinfo']['name'];?>{$invest.name}</a>&nbsp;</p>
                        <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>{$invest.rate}%&nbsp;</p>
                        <p class="rZ_01"><?php echo number_format($il['dealinfo']['borrow_amount'],0);?>&nbsp;</p>
                        <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['last_repay_time'];?>&nbsp;</p>
                        <p class="rZ_01"><?php echo $il['dealinfo']['repay_time'].($il['dealinfo']['repay_time_type'] == 0 )?"天":"月";?> &nbsp;</p>
                    </li>
                <?php }
                }?>
                <a href="{url x=" index" v="uc_invest"}" >查看全部投资动态</a>
            </ul>
            <!--1end-->
            <!--1start-->
            <ul  class="disable">
                <?php
                if($uinfo['is_company'] == 0){ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年化收益</p>
                        <p class="rZ_01">投资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">投资收益</p>
                    </li>
                    <?php
                    foreach($invest_list['investing_list'] as $il){
                        ?>
                        <li>
                            <p class="rT_01 tZ_02">
                                <a href="<?php echo Yii::$app->urlManager->createUrl('deal')."?id=".$il['dealinfo']['id'];?>" target="_blank"><?php echo $il['dealinfo']['name'];?></a>
                            </p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>%</p>
                            <p class="rZ_01"><?php echo number_format($il['money'],0);?></p>
                            <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['end_time'];?></p>
                            <p class="rZ_01"><?php echo number_format($il['dealinfo']['income'],2);?></p>
                        </li>
                        <?php
                    }
                }else{ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年利率</p>
                        <p class="rZ_01">融资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">融资期限</p>
                    </li>
                    <?php
                    foreach($invest_list['investing_list'] as $il){
                        ?>
                        <li>
                            <p class="rT_01 tZ_02"><a href="{url x=" index" v="deal" p="id=$invest.id"}"
                                target="_blank"><?php echo $il['dealinfo']['name'];?>{$invest.name}</a>&nbsp;</p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>{$invest.rate}%&nbsp;</p>
                            <p class="rZ_01"><?php echo number_format($il['dealinfo']['borrow_amount'],0);?>&nbsp;</p>
                            <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['last_repay_time'];?>&nbsp;</p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['repay_time'].($il['dealinfo']['repay_time_type'] == 0 )?"天":"月";?> &nbsp;</p>
                        </li>
                    <?php }
                }?>
                <a href="{url x=" index" v="uc_invest"}" >查看全部投资动态</a>
            </ul>


            <ul  class="disable">
                <?php
                if($uinfo['is_company'] == 0){ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年化收益</p>
                        <p class="rZ_01">投资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">投资收益</p>
                    </li>
                    <?php
                    foreach($invest_list['investrepaying_list'] as $il){
                        ?>
                        <li>
                            <p class="rT_01 tZ_02">
                                <a href="<?php echo Yii::$app->urlManager->createUrl('deal')."?id=".$il['dealinfo']['id'];?>" target="_blank"><?php echo $il['dealinfo']['name'];?></a>
                            </p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>%</p>
                            <p class="rZ_01"><?php echo number_format($il['money'],0);?></p>
                            <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['end_time'];?></p>
                            <p class="rZ_01"><?php echo number_format($il['dealinfo']['income'],2);?></p>
                        </li>
                        <?php
                    }
                }else{ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年利率</p>
                        <p class="rZ_01">融资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">融资期限</p>
                    </li>
                    <?php
                    foreach($invest_list['investrepaying_list'] as $il){
                        ?>
                        <li>
                            <p class="rT_01 tZ_02"><a href="{url x=" index" v="deal" p="id=$invest.id"}"
                                target="_blank"><?php echo $il['dealinfo']['name'];?>{$invest.name}</a>&nbsp;</p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>{$invest.rate}%&nbsp;</p>
                            <p class="rZ_01"><?php echo number_format($il['dealinfo']['borrow_amount'],0);?>&nbsp;</p>
                            <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['last_repay_time'];?>&nbsp;</p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['repay_time'].($il['dealinfo']['repay_time_type'] == 0 )?"天":"月";?> &nbsp;</p>
                        </li>
                    <?php }
                }?>
                <a href="{url x=" index" v="uc_invest"}" >查看全部投资动态</a>
            </ul>
            <ul  class="disable">
                <?php
                if($uinfo['is_company'] == 0){ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年化收益</p>
                        <p class="rZ_01">投资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">投资收益</p>
                    </li>
                    <?php
                    foreach($invest_list['investrepayed_list'] as $il){
                        ?>
                        <li>
                            <p class="rT_01 tZ_02">
                                <a href="<?php echo Yii::$app->urlManager->createUrl('deal')."?id=".$il['dealinfo']['id'];?>" target="_blank"><?php echo $il['dealinfo']['name'];?></a>
                            </p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>%</p>
                            <p class="rZ_01"><?php echo number_format($il['money'],0);?></p>
                            <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['end_time'];?></p>
                            <p class="rZ_01"><?php echo number_format($il['dealinfo']['income'],2);?></p>
                        </li>
                        <?php
                    }
                }else{ ?>
                    <li>
                        <p class="rT_01 tZ_02">项目名称</p>
                        <p class="rZ_01">年利率</p>
                        <p class="rZ_01">融资金额</p>
                        <p class="rT_03 tZ_03">投资到期日</p>
                        <p class="rZ_01">融资期限</p>
                    </li>
                    <?php
                    foreach($invest_list['investrepayed_list'] as $il){
                        ?>
                        <li>
                            <p class="rT_01 tZ_02"><a href="{url x=" index" v="deal" p="id=$invest.id"}"
                                target="_blank"><?php echo $il['dealinfo']['name'];?>{$invest.name}</a>&nbsp;</p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['rate'];?>{$invest.rate}%&nbsp;</p>
                            <p class="rZ_01"><?php echo number_format($il['dealinfo']['borrow_amount'],0);?>&nbsp;</p>
                            <p class="rT_03 tZ_03"><?php echo $il['dealinfo']['last_repay_time'];?>&nbsp;</p>
                            <p class="rZ_01"><?php echo $il['dealinfo']['repay_time'].($il['dealinfo']['repay_time_type'] == 0 )?"天":"月";?> &nbsp;</p>
                        </li>
                    <?php }
                }?>
                <a href="{url x=" index" v="uc_invest"}" >查看全部投资动态</a>
            </ul>
            <!--1end-->
        </div>
    </div>
    <!--1-->
</div>
<!--第二频道end-->
<script type="text/javascript" src="/js/ajaxupload.js"></script>
<?php
$jsStr = <<<EOF
   $('.AboutContentRight_Tabs a').mouseover(function(){
		$(this).addClass("TabHover").siblings().removeClass();
		$(".AboutContentRight_Tabs_Reviews > div").eq($(".AboutContentRight_Tabs a").index(this)).show().siblings().hide();
	});
	$('#reviews_Tab a').mouseover(function(){
		$(this).addClass("current").siblings().removeClass();
		$("#reviews_Tab_Reviews > ul").eq($("#reviews_Tab a").index(this)).show().siblings().hide();
	    });
    function upd_file(obj, file_id, uid) {
        $("input[name='" + file_id + "']").bind("change", function () {
            $(obj).hide();
            $(obj).parent().find(".fileuploading").removeClass("hide");
            $(obj).parent().find(".fileuploading").removeClass("show");
            $(obj).parent().find(".fileuploading").addClass("show");
            $.ajaxFileUpload
            (
                {
                    url: APP_ROOT + '/index.php?ctl=avatar&act=upload&uid=' + uid,
                    secureuri: false,
                    fileElementId: file_id,
                    dataType: 'json',
                    success: function (data, status) {
                        $(obj).show();
                        $(obj).parent().find(".fileuploading").removeClass("hide");
                        $(obj).parent().find(".fileuploading").removeClass("show");
                        $(obj).parent().find(".fileuploading").addClass("hide");
                        if (data.status == 1) {
                            document.getElementById("avatar").src = data.middle_url + "?r=" + Math.random();
                        } else {
                            $.showErr(data.msg);
                        }
                    },
                    error: function (data, status, e) {
                        $.showErr(data.responseText);
                        $(obj).show();
                        $(obj).parent().find(".fileuploading").removeClass("hide");
                        $(obj).parent().find(".fileuploading").removeClass("show");
                        $(obj).parent().find(".fileuploading").addClass("hide");
                    }
                }
            );
            $("input[name='" + file_id + "']").unbind("change");
        });
    }
EOF;
$this->registerJs($jsStr);
?>