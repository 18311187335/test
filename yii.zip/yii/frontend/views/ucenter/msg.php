<!--右栏目start-->
<div class="AboutContentRight">

    <div class="project_Manage">

        <ul class="AboutContentRight_Title"><h2>消息盒子</h2></ul>
        <ul class="Trading info03">
            <a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/msg')?>" <?php if($type == 1){?>class="traHover01"<?php }?>>系统消息</a>
            <a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/msg')."?type=2"?>" <?php if($type == 2){?>class="traHover01"<?php }?>>未读消息</a>
            <a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/msg')."?type=3"?>" <?php if($type == 3){?>class="traHover01"<?php }?>>已读消息</a>
        </ul>

        <div class="reviews_Tab_Reviews">

            <!--1start-->
            <ul class="Info_Content02">
                <li>
                    <p class="Info_Content03 Info_Content04"><input type="checkbox" onclick="sel_all(this)"/></p>

                    <p class="Info_Content05">状态</p>

                    <p class="Info_Content06">标题</p>

                    <p class="Info_Content07">发送时间</p>
                </li>
                <?php
                 foreach($msg_list as $msg){?>
                <li>
                    <p class="Info_Content03 Info_Content04"><input type="checkbox" name="sel[]" value="{$msg.id}"/></p>

                    <p class="Info_Content05 img03"><i class="<?php if($msg['is_read'] == 0){?>img01<?php }else{?>img02<?php }?>"></i></p>

                    <p class="Info_Content06"><a href="{url x=" index" r="uc_msg#detail"
                        p="msgid=$msg.id"}"><?php echo mb_substr(strip_tags($msg['content']), 0, 40); ?></a>
                    </p>

                    <p class="Info_Content07"><?php echo common\includes\CommonUtility::to_date($msg['create_time'])?></p>
                </li>
                 <?php }?>
            </ul>
            <!--1end-->

            <div class="Info_Del Info_Del02"><a href="javascript:void(0)" onclick="del()">删除</a></div>
            <!--分页start-->
            <div class="BidListPages BidListPages01">
                <?php echo \components\widgets\PageLink::widget([
                    'activePageCssClass'=>'current',
                    'maxButtonCount'=>5,
                    'firstPageLabel'=>'第一页',
                    'prevPageLabel'=>'上一页',
                    'nextPageLabel'=>'下一页',
                    'lastPageLabel'=>'最后一页',
                    'pagination' => $pages,
                ]);?>
            </div>
            <!--分页end-->
        </div>
    </div>
</div>
<!--右栏目end-->
<?php
$delAjaxUrl = Yii::$app->urlManager->createUrl("ucenter/msg");
$jsStr = <<<EOF
    function sel_all(obj) {
        var list = document.getElementsByName("sel[]");
        if (obj.checked == true) {
            for (var i = 0; i < list.length; i++) {
                list[i].checked = true;
            }
        } else {
            for (var i = 0; i < list.length; i++) {
                list[i].checked = false;
            }
        }
    }
    function del() {
        if (!confirm("确定删除这些消息？")) {
            return false;
        }
        var list = document.getElementsByName("sel[]");
        var ids = "ids[]=0";
        for (var i = 0; i < list.length; i++) {
            if (list[i].checked == true) {
                ids += "&ids[]=" + list[i].value.toString();
            }
        }
        $.ajax({
            type: "POST",
            url: "$delAjaxUrl",
            data: ids + "&isajax=1",
            dataType: "json",
            success: function (obj) {
                if (obj.status == 0) {
                    $.showErr(obj.info);
                    return false;
                } else {
                    $.showSuccess(obj.info, function () {
                        window.location.reload();
                    });
                }
            },
            error: function (ajaxobj) {
                return false;
            }
        });
    }
EOF;
$this->registerJs($jsStr);
?>