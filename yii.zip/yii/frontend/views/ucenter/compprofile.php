<script type='text/javascript'  src='{$APP_ROOT}/admin/public/kindeditor/kindeditor.js'></script>
<script type="text/javascript">
	var VAR_MODULE = "m";
	var VAR_ACTION = "a";
	var ROOT = '{$APP_ROOT}/file.php';
	var ROOT_PATH = '{$APP_ROOT}';
	var can_use_quota = "{$can_use_quota}";
</script>
<!--����Ŀstart-->
<div class="AboutContentRight">
	<form action="{url x="shop" r="uc_account#savecompany"}" method="POST">
	<ul class="AboutContentRight_Title"><h2>��ҵ��Ϣ</h2></ul>

	<ul class="AboutContentRight_Info04" id="form_ul">
		<li>
			<p class="About_Right_Info01">��˾���ƣ�</p>
			{if $user_company.company_name}
			<p>
				<i>{$user_company.company_name}</i>
			</p>
			{else}
		<span class="About_Right_Info03">
			<input type="text" name="company_name" value="" class="bid_Resiger_Text" />
		</span>
			{/if}
		</li>
		<li>
			<p class="About_Right_Info01">ע���ʱ���</p>

			{if $user_company.capital}
			<p>
				<i>{$user_company.capital} ��</i>
			</p>
			{else}
		<span class="About_Right_Info04">
			<input type="text" name="capital" value="" class="bid_Resiger_Code" />
		</span><i>��</i>
			{/if}

		</li>

		<li>
			<p class="About_Right_Info01">�������У�</p>
			{if !$user_company.city}
			<div class="info">
				<div>
					<select id="s_province" name="s_province"></select>
				</div>
				<div style="float:right">
					<select id="s_city" name="s_city" ></select>
				</div>
			</div>
			{else}
			<p>
				<i>{$citys.province} ʡ��ֱϽ�У�&nbsp;&nbsp;&nbsp;{$citys.city} �У�����</i>
			</p>
			{/if}
			<script type="text/javascript">_init_area(0,0);</script>
		</li>

		<li>
			<p class="About_Right_Info01">Ӫҵ��Χ��</p>
	<span class="About_Right_Info05">
		<textarea class="About_Right_Info05_Text" name="cbusiness">{$user_company.cbusiness}</textarea>
	</span>
		</li>
		<li>
			<p class="About_Right_Info01">��ҵ������</p>
	<span class="About_Right_Info05">
		<textarea class="About_Right_Info05_Text" name="cbackground">{$user_company.cbackground}</textarea>
	</span>
		</li>
		<li>
			<p class="About_Right_Info01">Ӫҵִ�գ�</p>
			<p>{function name="show_ke_image" v="license_0" cn="$user_company.license"}</p>
		</li>
		<li>
			<p class="About_Right_Info01">�������ñ�����֤��</p>
			<p>{function name="show_ke_image" v="credit_0" cn="$credit_report_main" }&nbsp;&nbsp;&nbsp;
				<a href="javascript:void(0)" onclick="add_credit(this)">������ͼƬ</a></p>
		</li>

		{foreach from=$credit_report item=credit key=key}
		<li>
			<p class="About_Right_Info01">&nbsp;</p>
			<p>
				{function name="show_ke_image" v=$key cn="$credit" }
			</p>
		</li>
		{/foreach}

		<li>
			<p class="About_Right_Info01">�־�ס��֤���ļ���</p>
			<p>{function name="show_ke_image" v="residence_0" cn="$residence_main" }&nbsp;&nbsp;&nbsp;
				<a href="javascript:void(0)" onclick="add_residence(this)">������ͼƬ</a></p>
		</li>

		{foreach from=$residence item=residence key=key}
		<li>
			<p class="About_Right_Info01">&nbsp;</p>
			<p>
				{function name="show_ke_image" v=$key cn="$residence" }
			</p>
		</li>
		{/foreach}

		<li>
			<p class="About_Right_Info01">Ӫҵ�������޺�ͬ��</p>
			<p>{function name="show_ke_image" v="lease_0" cn="$lease_main" }&nbsp;&nbsp;&nbsp;
				<a href="javascript:void(0)" onclick="add_lease(this)">������ͼƬ</a></p>
		</li>

		{foreach from=$lease item=lease key=key}
		<li>
			<p class="About_Right_Info01">&nbsp;</p>
			<p>
				{function name="show_ke_image" v=$key cn="$lease" }
			</p>
		</li>
		{/foreach}

		<li>
			<p class="About_Right_Info01">��6����ҵ�Թ��˻���ϸ��</p>
			<p>{function name="show_ke_image" v="account_0" cn="$public_account_main" }&nbsp;&nbsp;&nbsp;
				<a href="javascript:void(0)" onclick="add_account(this)">������ͼƬ</a></p>
		</li>

		{foreach from=$public_account item=account key=key}
		<li>
			<p class="About_Right_Info01">&nbsp;</p>
			<p>
				{function name="show_ke_image" v=$key cn="$account" }
			</p>
		</li>
		{/foreach}

		<li>
			<p class="About_Right_Info01">&nbsp;</p>
			<p>
				<input type="submit" />
			</p>
		</li>
	</ul>

	</form>


	<form action="{url x="shop" r="uc_account#save_legal"}" method="POST">

	<ul class="AboutContentRight_Title border03"><h2>������Ϣ</h2></ul>
	<ul class="AboutContentRight_Info04">
		<li>
			<p class="About_Right_Info01">��ҵ���ˣ�</p>
			{if $user_company.legal}
			<p><i>{$user_company.legal}</i></p>
			{else}
		<span class="About_Right_Info04">
			<input type="text" name="legal" value="{$user_company.legal}" class="bid_Resiger_Code" />
			<?php $this->_var['edit'] = 1;?>
		</span>
			{/if}
		</li>
		<li>
			<p class="About_Right_Info01">��������֤��</p>
			{if $user_company.legal_idno}
			<p><i>{$user_company.legal_idno}</i></p>
			{else}
		<span class="About_Right_Info03">
			<input type="text" name="legal_idno" value="{$user_company.legal_idno}" class="bid_Resiger_Text" />
			<?php $this->_var['edit'] = 1;?>
		</span>
			{/if}
		</li>
		<li>
			<p class="About_Right_Info01">�����ֻ���</p>
			{if $user_company.legal_mobile}
			<p><i>{$user_company.legal_mobile}</i></p>
			{else}
			<span class="About_Right_Info03">
				<input type="text" name="legal_mobile" value="{$user_company.legal_mobile}" class="bid_Resiger_Text" />
				<?php $this->_var['edit'] = 1;?>
			</span>
			{/if}
		</li>
		<li>
			<p class="About_Right_Info01">��������֤���棺</p>
			<p>
				{if $user_company.legal_idno_photo1 eq ""}
				{function name="show_ke_image" v="legal_idno_photo1" cn="" }
				<?php $this->_var['edit'] = 1;?>
				{else}
				<img src="{$user_company.legal_idno_photo1}" width="450px" height="200px" />
				{/if}
			</p>
		</li>
		<li>
			<p class="About_Right_Info01">��������֤���棺</p>
			<p>
				{if $user_company.legal_idno_photo2 eq ""}
				{function name="show_ke_image" v="legal_idno_photo2" cn="" }
				<?php $this->_var['edit'] = 1;?>
				{else}
				<img src="{$user_company.legal_idno_photo2}" width="450px" height="200px" />
				{/if}
			</p>
		</li>
		{if $edit}
		<li>
			<p class="About_Right_Info01">&nbsp;</p>
			<p>
				<input type="submit" />
			</p>
		</li>
		{/if}
	</ul>



	<ul class="AboutContentRight_Info05 fl">
		<p>* ��ܰ��ʾ�����޸Ĺ�˾��Ϣ����ϵ�Ҳ�è�ͷ���{function name="app_conf" value="SHOP_TEL"}</p>
	</ul>

	</form>
</div>


<!--����Ŀend-->



<script type="text/javascript">

	function show_ke_image(id)
	{
		var image_path =APP_ROOT+"/admin/Tpl/default/Common/images/no_pic.gif";
		var is_show = "display:none;";
		return	"<div style='width:120px; height:40px; margin-left:10px; display:inline-block;  float:left;' class='none_border'><div style='font-size:0px;'><textarea id='"+id.toString()+"' name='"+id.toString()+"' style='width:125px; height:25px;' ></textarea><input type='text' id='focus_"+id.toString()+"' style='font-size:0px; border:0px; padding:0px; margin:0px; line-height:0px; width:0px; height:0px;' /></div></div><img src='"+image_path+"' $script  style='display:inline-block; float:left; cursor:pointer; margin-left:10px; border:#ccc solid 1px; width:35px; height:35px;' id='img_"+id.toString()+"' /><img src='"+APP_ROOT+"/admin/Tpl/default/Common/images/del.gif' style='"+is_show+" margin-left:10px; float:left; border:#ccc solid 1px; width:35px; height:35px; cursor:pointer;' id='img_del_"+id.toString()+"' onclick=\\\"delimg('"+id.toString()+"')\\\" title='ɾ��' />";

	}
</script>

<script type="text/javascript">


	/*�������ñ�����֤������*/
	var credit_idnum = {function name="count" v=$credit_report};
	function add_credit(obj){
		if(credit_idnum>=9){
			$.showErr("ͼƬ���ܳ���10��");return false;
		}
		var form = document.getElementById("form_ul");
		var li_arr = form.getElementsByTagName('li');
		for(var i=0;i<li_arr.length;i++){
			if(li_arr[i]==obj.parentElement){
				credit_idnum++;
				var newli = document.createElement("li");
				var eid = 'credit_'+credit_idnum.toString();KE.show({urlType:'domain', id:eid, items : ['upload_image'],skinType: 'tinymce',allowFileManager : false,resizeMode : 0,afterBlur:function(){this.sync();}});
				var li = show_ke_image(eid);
				newli.innerHTML = '<p class="About_Right_Info01">&nbsp;</p><p>'+li+'</p>';
				form.insertBefore(newli, obj.parentElement.nextSibling);
				KE.create(eid);
			}
		}
	}

	/*�־�ס��֤���ļ�������*/
	var residence_idnum = {function name="count" v=$residence};
	function add_residence(obj){
		if(residence_idnum>=9){
			$.showErr("ͼƬ���ܳ���10��");return false;
		}
		var form = document.getElementById("form_ul");
		var li_arr = form.getElementsByTagName('li');
		for(var i=0;i<li_arr.length;i++){
			if(li_arr[i]==obj.parentElement){
				residence_idnum++;
				var newli = document.createElement("li");
				var eid = 'residence_'+residence_idnum.toString();KE.show({urlType:'domain', id:eid, items : ['upload_image'],skinType: 'tinymce',allowFileManager : false,resizeMode : 0,afterBlur:function(){this.sync();}});
				var li = show_ke_image(eid);
				newli.innerHTML = '<p class="About_Right_Info01">&nbsp;</p><p>'+li+'</p>';

				form.insertBefore(newli, obj.parentElement.nextSibling);
				KE.create(eid);
			}
		}
	}

	/*Ӫҵ�������޺�ͬ�����Ʊ������*/
	var lease_idnum = {function name="count" v=$lease};
	function add_lease(obj){
		if(lease_idnum>=9){
			$.showErr("ͼƬ���ܳ���10��");return false;
		}
		var form = document.getElementById("form_ul");
		var li_arr = form.getElementsByTagName('li');
		for(var i=0;i<li_arr.length;i++){
			if(li_arr[i]==obj.parentElement){
				lease_idnum++;
				var newli = document.createElement("li");
				var eid = 'lease_'+lease_idnum.toString();KE.show({urlType:'domain', id:eid, items : ['upload_image'],skinType: 'tinymce',allowFileManager : false,resizeMode : 0,afterBlur:function(){this.sync();}});
				var li = show_ke_image(eid);
				newli.innerHTML = '<p class="About_Right_Info01">&nbsp;</p><p>'+li+'</p>';

				form.insertBefore(newli, obj.parentElement.nextSibling);
				KE.create(eid);
			}
		}
	}

	/*��6����ҵ�Թ��˻���ϸ������*/
	var account_idnum = {function name="count" v=$public_account};
	function add_account(obj){
		if(account_idnum>=9){
			$.showErr("ͼƬ���ܳ���10��");return false;
		}
		var form = document.getElementById("form_ul");
		var li_arr = form.getElementsByTagName('li');
		for(var i=0;i<li_arr.length;i++){
			if(li_arr[i]==obj.parentElement){
				account_idnum++;
				var newli = document.createElement("li");
				var eid = 'account_'+account_idnum.toString();KE.show({urlType:'domain', id:eid, items : ['upload_image'],skinType: 'tinymce',allowFileManager : false,resizeMode : 0,afterBlur:function(){this.sync();}});
				var li = show_ke_image(eid);
				newli.innerHTML = '<p class="About_Right_Info01">&nbsp;</p><p>'+li+'</p>';

				form.insertBefore(newli, obj.parentElement.nextSibling);
				KE.create(eid);
			}
		}
	}
</script>