<?php
/* @var $this yii\web\View */
$this->title = '家财猫-阳光透明的互联网P2C平台';
$this->registerMetaTag([
      'name' => 'description',
      'content' => '家财猫理财平台是面向广大投资用户的在线理财服务平台，通过互联网或移动互联网技术为投资用户提供理财产品信息及直接投资服务。'
]);
$this->registerMetaTag([
    'name' => 'keywords',
    'content' => '家财猫,P2P,P2C,网络借贷'
]);
$this->registerMetaTag([
    'name' => 'baidu-site-verification',
    'content' => 'tmz1G08Fa7'
]);
$this->registerCssFile('/css/moneyCat2.css');
$this->registerCssFile('/css/flexslider.min.css');
$this->registerJsFile('js/jquery.flexslider.min.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/global01.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
?>
<div class="on_Line_Box" id="BizQQWPA">
      <ul>
            <img src="/images/on_Line.png" width="60" height="200" alt="" />
      </ul>
</div>
<style>
      .on_Line_Box{ display:block; width:60px; height:200px; overflow:hidden; position:fixed; _position:absolute; right:0;  top:50%; z-index:10; cursor:pointer;}
      .on_Line_Box ul{ display:block; width:100%; height:auto; overflow:hidden;}
      .on_Line_Box ul img{ display:block;}
</style>
<!--主体开始-->
<div class="oi">
      <div class="first_head">
            <div class="in">
                  <div class="left">
                        <!-- main 块 -->
                        <div class="moduletable-banner">
                              <div class="flexslider">
                                    <ul class="slides">
                                          <li style="background:url(/images/jc_01.jpg) 50% 0px no-repeat;">

                                                <a href="{url x="index" v="active#xinliying"}?hmsr=web&hmmd=banner&hmpl=xly&hmci=2" target="_blank"></a>
                                          </li>
                                          <li style="background:url(/images/jc_02.jpg) 50% 0px no-repeat;">

                                                <a href="{url x="index" v="news#guliying"}" target="_blank"></a>
                                          </li>

                                          <li style="background:url(/images/jc_03.jpg) 50% 0px no-repeat;">

                                                <a href="{url x="index" v="user#deal_apply" p="type=3"}?hmsr=web&hmmd=banner&hmpl=pz&hmci=3" target="_blank"></a>
                                          </li>
                                    </ul>
                              </div>
                        </div>
                  </div>
                  <div class="right">
                        <?php
                        if(!Yii::$app->user->isGuest){
                        ?>
                        <i class="back"></i>
                        <p class=" margtop120 font18 padding_l12 colef" style="margin-left:30px;">欢迎回来，&nbsp;&nbsp;&nbsp;&nbsp;<?php $user = Yii::$app->user->getIdentity();
                              if($username = $user->user_name){echo $username;}else{echo $user->mobile;}?></p>

                        <p class="margtop40 font18 padding_l12 colf" style="margin-left:30px;">账户可用余额</p>

                        <p class="font18 margtop60 padding_l12 colf" style="margin-left:30px;"><?php echo number_format($user->money,2);?>元&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a
                                  class="colef font14" href="<?php echo Yii::$app->urlManager->createUrl('uc_money');?>#incharge">充值</a></p>

                        <p class="margtop50 myDecision">
                              <a class="font14 colf left" href="<?php echo Yii::$app->urlManager->createUrl('uc_center');?>#individual_center">查看资产</a>
                              <a class="font14 colf right" href="<?php echo Yii::$app->urlManager->createUrl('deals');?>">我要理财</a>
                        </p>
                        <?php }else{ ?>
                        <i class="back"></i>
                        <p class="yearin"> 家财猫年化收益率</p>
                        <p class="maxin">最高<i class="max">16%</i> </p>
                        <p class="yield"><i class="num">45</i>倍银行活期收益<i class="num num2">4</i>倍余额宝收益    </p>
                        <a href="<?php echo Yii::$app->urlManager->createUrl('user/register');?>" class="nowregistered">快速注册</a>
                        <a href="<?php echo Yii::$app->urlManager->createUrl('user/login');?>" class="nowlogin">登录</a>
                        <?php } ?>
                  </div>
            </div>
      </div>
      <div class="whyOus"><span class="in colef">为什么选择我们</span></div>
      <div class="three">
            <div class="left">
                  <p class="top"><span class="in">宝宝类 </span><i></i><img src="/img/leftimg.png"></p>
                  <ul>
                        <li>低风险</li>
                        <li>收益率4%~6%</li>
                        <li>随卖随取</li>
                        <li>一份起购</li>
                        <li>货币基金</li>
                  </ul>
            </div>
            <div class="center"><span class="in">家财猫</span>
                  <ul>
                        <li>项目安全透明</li>
                        <li>收益率高达7%~12%</li>
                        <li>7天~1年期多种选择</li>
                        <li>100元起投</li>
                        <li>第三方托管</li>
                  </ul>
            </div>
            <div class="right">
                  <p class="top"><span class="in">主流P2P </span><i></i><img src="/img/rightimg.png"></p>
                  <ul>
                        <li>风险非常大</li>
                        <li>收益率6%~18%</li>
                        <li> &ge;1年起</li>
                        <li>1万元起投</li>
                        <li>资金池</li>
                  </ul>
            </div>
      </div>
      <div class="recommend">
            <div class="left"><span class="jrtj"></span>

                  <h1 class="recohead"><?php echo $best_list->name;?></h1>

                  <div class="left2">
                        <p class="in">借款金额：<i class="number"><?php echo number_format($best_list->borrow_amount,0);?></i>元</p>

                        <p class="in">年化收益：<i class="number"><?php echo number_format($best_list->rate,0);?>%</i></p>

                        <p class="in">借款时间：<i class="number"><?php echo $best_list->repay_time;?></i>天</p>

                        <p class="in">还款方式：<?php if ($best_list->loantype == 0){?>等额本息<?php }elseif ($best_list->loantype == 1){?>按月付息<?php }elseif($best_list->loantype == 2){?>到期本息，一次性支付<?php }?></p>

                        <p class="in" id="enddate">筹标时间：
                        </p>

                        <p class="in">计息时间：投标当日计息</p>
                  </div>
                  <div class="right2">
                        <h1 class="j_d">筹集进度</h1>

                        <p class="process"><span class="bfb"><i class="jd2"><?php echo number_format($best_list->load_money/$best_list->borrow_amount*100,0);?></i>%</span><img src="/img/quan.png" class="in2">
                        </p>
                        <a href="<?php echo Yii::$app->urlManager->createUrl('deal')?>?id=<?php echo $best_list->id?>" class="jd3">立即投标</a></div>
                  </h1>
            </div>
            <div class="right">
                  <h1 class="first_head2">网站公告<a href="<?php echo Yii::$app->urlManager->createUrl("news")?>?cate_id=5" class="more">更多</a></h1>
                  <?php
                  foreach($notice_list as $v){
                        ?>
                      <a target="_blank" class="in" href="<?php echo Yii::$app->urlManager->createUrl("news")?>?id=<?php echo $v['id'];?>"><?php echo mb_substr($v['title'],0,15)?></a>
                  <?php
                  }
                  ?>
            </div>
      </div>
      <div class="bid2">
            <div class="left">
                  <div class="left2">
                        <a href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=1" target="" class="investmentList">
                        <p class="list_1"></p>

                        <p class="list_2">信利盈 </p>

                        <p class="list_3"><i class="left3">预期年化收益</i><i class="right3">7%~10%</i></p>

                        <p class="list_4">
                              <span class="left4"><i class="tou">投</i><i class="yuan">100元</i> 起 </span>
                              <span class="center4"><i class="yuan">30-540</i>天</span>
                              <span class="right4"><i class="yuan">信托质押</i></span>
                        </p>
                        <i href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=1" class="rightnowbid">立即投资</i>

                        </a>
                  </div>
                  <div class="right2">
                        <a href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=4" target="" class="investmentList t_r">
                        <p class="list_1 "></p>

                        <p class="list_2">股利盈 </p>

                        <p class="list_3"><i class="left3">预期年化收益</i><i class="right3">8%~12%</i></p>

                        <p class="list_4">
                              <span class="left4"><i class="tou">投</i><i class="yuan">100元</i>起 </span>
                              <span class="center4"><i class="yuan">30-540</i>天</span>
                              <span class="right4"><i class="yuan">股票质押</i></span>
                        </p>
                        <i href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=4" class="rightnowbid">立即投资</i>
                        </a>
                  </div>
            </div>
            <div class="right">
                  <h1 class="first_head2">媒体报道<a href="<?php echo Yii::$app->urlManager->createUrl("news")?>?cate_id=53" class="more">更多</a></h1>
                  <?php
                  foreach($media_list as $m){
                        ?>
                        <p class="mediaReports">
                              <a href="<?php echo Yii::$app->urlManager->createUrl("news")?>?cate_id=53&id=<?php echo $m['id'];?>" class="left2" target="_blank"><img src="<?php echo $m['thumb'];?>"></a>
                              <a href="<?php echo Yii::$app->urlManager->createUrl("news")?>?cate_id=53&id=<?php echo $m['id'];?>" class="right2" target="_blank"><i><?php echo mb_substr($m['title'],0,10);?></i></a>
                        </p>
                  <?php }
                  ?>
            </div>
      </div>
      <div class="bid2">
            <div class="left">
                  <div class="left2">
                        <a href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=2" target="" class="investmentList l_b">
                        <p class="list_1  "></p>

                        <p class="list_2">私人定制 </p>

                        <p class="list_3"><i class="left3">预期年化收益</i><i class="right3">8%~12%</i></p>

                        <p class="list_4">
                              <span class="left4"><i class="tou">投</i><i class="yuan">30万元</i>起 </span>
                              <span class="center4"><i class="yuan">期限订制</i></span>
                              <span class="right4"><i class="yuan">额度订制</i></span>
                        </p>
                        <i href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=2" class="rightnowbid">立即投资</i>
                        </a>
                  </div>
                  <div class="right2">
                        <a href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=5" target="" class="investmentList r_b">
                        <p class="list_1  "></p>

                        <p class="list_2">资利盈 </p>

                        <p class="list_3"><i class="left3">预期年化收益</i><i class="right3">6%~9%</i></p>

                        <p class="list_4">
                              <span class="left4"><i class="tou">投</i><i class="yuan">100元</i>起 </span>
                              <span class="center4"><i class="yuan">30-540天</i></span>
                              <span class="right4"><i class="yuan">资产管理</i></span>
                        </p>
                        <i href="<?php echo Yii::$app->urlManager->createUrl('deals') ?>?deal_type=5" class="rightnowbid">立即投资</i>
                        </a>
                  </div>
            </div>
            <div class="right">
                  <h1 class="first_head2 f_h2"><span id="ranking1" class="addcss">历史排行</span><span id="ranking2">30天排行</span>
                  </h1>
                  <ul class="week">
                        <?php
                        $i = 1;
                        foreach($rank_history as $rank){
                              $i++;
                              ?>
                              <li class="ranking_<?php echo $i?>">
                                    <span class="rank_l"><?php echo mb_substr($rank['mobile'],0,3)."******".mb_substr($rank['mobile'],9);?></span>
                                    <span class="rank_r"><i><?php echo $rank['total'];?></i>元</span>
                              </li>
                        <?php }
                        ?>
                  </ul>
                  <ul class="month">
                        <?php
                        $i = 1;
                        foreach($rank_30 as $rank){
                              $i++;
                              ?>
                              <li class="ranking_<?php echo $i?>">
                                    <span class="rank_l"><?php echo mb_substr($rank['mobile'],0,3)."******".mb_substr($rank['mobile'],9);?></span>
                                    <span class="rank_r"><i><?php echo $rank['total'];?></i>元</span>
                              </li>
                        <?php }
                        ?>
                  </ul>
            </div>
      </div>
      <div class="investmentStep"><span class="in">投资步骤</span></div>
      <div class="investmentStep2">
            <p class="step1"><span class="steptop">注册</span><span class="stepbottom">注册成为会员</span></p>

            <p class="step2"><span class="steptop">认证</span><span class="stepbottom">进行实名认证</span></p>

            <p class="step3"><span class="steptop">充值</span><span class="stepbottom">提前为账户注入资金</span></p>

            <p class="step4"><span class="steptop">收益</span><span class="stepbottom">成交后享受更高收益</span></p>

            <p class="step5"><span class="steptop">到账</span><span class="stepbottom">到期后本金收益自动到账</span></p>

      </div>
</div>
<div class="cooperativeMechanism">
      <h1 class="cooper"> 合作机构</h1>
      <a href="javascript:void(0)" class="hz1"> <img src="/img/huifubao.png"></a>
      <a href="javascript:void(0)" class="hz2"> <img src="/img/zyxt.png"></a>
      <a href="javascript:void(0)" class="hz3"> <img src="/img/gmxt.png"></a>
      <a href="javascript:void(0)" class="hz4"> <img src="/img/hswl.png"></a>
      <a href="javascript:void(0)" class="hz5"> <img src="/img/msxt.png"></a>
      <a href="javascript:void(0)" class="hz6"> <img src="/img/shoujizhushou.png"></a>
</div>
<!--主体结束-->
<?php
$jsScript = <<<EOF
      $(window).load(function () {
            $('.flexslider').flexslider();
      });
      $(function () {
            var jd0 = $(".jd2").html();
            jd0 = jd0.replace(/^\s*/g, "");
            var jd = parseInt(jd0); //完成进度
            if (jd == 0) {
                  $(".in2").css("left", "-8px");
            } else if (jd > 0 && jd < 10) {
                  $(".in2").css("left", "-151px");
            } else if (jd >= 10) {
                  jd = Math.floor(jd / 10);
                  var f = 8 + jd * 143;
                  $(".in2").css("position", "absolute");
                  $(".in2").css("left", "-" + f + "px");
            }
            $(".f_h2 span").click(function () {           //单击显示本周排行或者本月排行
                  $(this).addClass("addcss");
                  $(this).siblings().removeClass("addcss");
                  var f = $(this).attr("id");
                  if (f == "ranking1") {
                        $(".week").show();
                        $(".month").hide();
                  } else {
                        $(".week").hide();
                        $(".month").show();
                  }
            });
            $('.flexslider').hover(function () {
                  $('.flex-direction-nav li a.prev').css('display', 'block');
                  $('.flex-direction-nav li a.next').css('display', 'block');
            }, function () {
                  $('.flex-direction-nav li a.prev').css('display', 'none');
                  $('.flex-direction-nav li a.next').css('display', 'none');
            });

      });
      $(function() {
            var objtime = $("#enddate");
            var enddate = ${best_list['enddate']};
      var Bf=setInterval(function() {
            var day = parseInt(enddate / 86400, 10);
            var hour = parseInt((enddate - 86400 * day) / 3600, 10);
            var minute = parseInt((enddate - 86400 * day - hour * 3600) / 60, 10);
            var second = parseInt(enddate - 86400 * day - hour * 3600 - minute * 60, 10);
            var datetime = '';
            datetime += '筹标时间：';
            datetime += "<i class='number'>"+day+"</i>天";
            datetime +="<i class='number'>" +hour+'</i>时';
            datetime +="<i class='number'>" + minute+ '</i>分';
            datetime +="<i class='number'>" + second+'</i>秒';
            enddate--;
            if(enddate<=0){
                  objtime.html("筹标时间：筹标已结束");
                  clearInterval(Bf);
            }else{
                  objtime.html(datetime);
            }
      },1000);
      })
      function img_Open()
      {
            var img_show=document.getElementById('code_Img');
            if(img_show.style.display=="none")
            {
                  img_show.style.display="block";
            }else{
                  img_show.style.display="none";
            }
      }

      function img_Open2()
      {
            var img_show=document.getElementById('code_Img2');
            if(img_show.style.display=="none")
            {
                  img_show.style.display="block";
            }else{
                  img_show.style.display="none";
            }
      }
EOF;
$this->registerJs($jsScript);
?>