<div class="AboutContentLeft">
    <?php
    foreach($cateList as $cl){
        if($cl['subCate']){
            ?>
        <div class="vtitle"><a  href="javascript:void(0)" target="_self" class="v<?php if($cateId == $pid || $cateId == $cl->id || $pid == $cl->id){?> v02<?php }else{?> v01<?php }?>"><?php echo $cl->title?></a></div>
        <div class="vcon"  <?php if($pid != $cl->id && $cateId != $pid && $cateId != $cl->id  ){?>style="display: none;"<?php }?>>
            <ul class="vconlist clearfix">
                <?php foreach($cl['subCate'] as $sc){?>
                    <li><a href="<?php echo Yii::$app->urlManager->createUrl("news")?>?cate_id=<?php echo $sc->id;?>"
                        title="<?php echo $sc->title;?>" <?php if ($cateId == $sc->id){?>class="hover"<?php } ?>><?php echo $sc->title;?></a></li>
                <?php }?>
            </ul>
        </div>
        <?php }else{
         ?>
            <div class="vtitle"><a  href="<?php echo Yii::$app->urlManager->createUrl("news")?>?cate_id=<?php echo $cl->id?>"
                                    target="_self" class="v<?php if($cateId == $pid || $cateId == $cl->id){?> v02<?php }else{?> v01<?php }?>"><?php echo $cl->title?></a></div>
            <div class="vcon" style="display: none;"><ul class="vconlist clearfix"></ul></div>
        <?php }
    }?>
</div>
<?php
$jsScript = <<<EOF
$(function(){
	var tabs_i=0
	$('.vtitle').click(function(){
		var _self = $(this);
		var j = $('.vtitle').index(_self);
		tabs_i = j;
		$('.vtitle a').each(function(e){
			if(e==tabs_i){
				$('a',_self).removeClass('v01').addClass('v02');
			}else{
				$(this).removeClass('v02').addClass('v01');
			}
		});
		$('.vcon').slideUp().eq(tabs_i).slideDown();
	});
})
EOF;
$this->registerJs($jsScript);

?>