<?php
/* @var $this yii\web\View */
$this->title = '家财猫-阳光透明的互联网P2C平台';
$this->registerMetaTag([
    'name' => 'description',
    'content' => '家财猫理财平台是面向广大投资用户的在线理财服务平台，通过互联网或移动互联网技术为投资用户提供理财产品信息及直接投资服务。'
]);
$this->registerMetaTag([
    'name' => 'keywords',
    'content' => '家财猫,P2P,P2C,网络借贷'
]);
$this->registerMetaTag([
    'name' => 'baidu-site-verification',
    'content' => 'tmz1G08Fa7'
]);
$this->registerCssFile('/css/common.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
$this->registerCssFile('/css/style.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
?>
<!--小导航start-->
<div class="NewsListAreaAvd">
    <ul class="NewsListArea_Nav01">
        <p><a href="/" target="_self" title="">首页</a>
            <?php
            foreach($pcate as $pc){
                ?>
                <span>></span><a href="<?php  echo Yii::$app->urlManager->createUrl("news")?>?cate_id=<?php echo $pc->id?>" title=""><?php echo $pc->title?></a>
            <?php }
            ?>
        </p>
    </ul>
</div>
<!--小导航end-->
<!--内容start-->
<div class="asset_Size">
    <div class="asset_Size_Avds">
        <!--左边start-->
        <?php
          echo $this->render('left',['cateList'=>$cateList,'cateId'=>$cateId,'pid'=>$pid]);
        ?>
        <!--左边start-->
        <!--右栏目start-->
        <div class="AboutContentRight">
            <ul class="about_Us">
                <?php if($id){?>
                <li class="border02 Media"><h2><?php echo $article_list->title;?></h2></li>
                <li class="about_Content border02">
                    <p><?php echo $article_list->content;?></p>
                </li>
                <li class="Media03 border02"><a href="<?php echo Yii::$app->urlManager->createUrl('news')?>?cate_id=<?php  echo $article_list->cate_id;?>">返回列表 ></a></li>
                <?php
                }else{
                if($totalCount == 1){
                    $article = $article_list[0];
                      ?>
                        <li class="border02 Media"><h2><?php echo $article->title;?></h2></li>
                        <li class="about_Content border02">
                            <p><?php echo $article->content;?></p>
                        </li>
                    <?php }else{
                     foreach($article_list as $article){
                    ?>
                    <li>
                        <a href="<?php echo Yii::$app->urlManager->createUrl('news').'?cate_id='.$article->cate_id.'&id='.$article->id;?>"
                         title="<?php echo $article->title;?>" class="a"><?php echo $article->title;?></a>
                        <span class="span"><?php echo date("Y-m-d",$article->create_time);?></span>
                    </li>
                <?php
                       }
                    }
                } ?>
            </ul>
            <ul class="BidListPages02">
                <?php
                if(!$id || $totalCount == 1){
                    echo \components\widgets\PageLink::widget([
                        'activePageCssClass'=>'current',
                        'maxButtonCount'=>5,
                        //'firstPageLabel'=>'第一页',
                        'prevPageLabel'=>'上一页',
                        'nextPageLabel'=>'下一页',
                        //'lastPageLabel'=>'最后一页',
                        'pagination' => $pages,
                    ]);
                }
                ?>
            </ul>
        </div>
        <!--右栏目end-->
    </div>

</div>

<!--内容start-->
