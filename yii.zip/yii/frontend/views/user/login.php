<?php
use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

$this->title = '登录-家财猫';
$this->registerMetaTag([
    'name' => 'pinggu-site-verification',
    'content' => '1d2d7b0b69280ded0c529a204c3af2a9'
]);
$this->registerCssFile('/css/common.css');
$this->registerCssFile('/css/index_new.css');
?>
<!--登录start-->
<div class="bid_Login clearfix">
    <form method="post"  name="page_login_form" id="page_login_form">
        <input type="hidden" name="<?= Yii::$app->request->csrfParam; ?>" value="<?= Yii::$app->request->csrfToken; ?>" />
        <ul class="bid_Login_Left fl">
            <img src="/images/jc_39.jpg" width="571" height="312" />
        </ul>
        <ul class="bid_Login_Right fr">
            <li class="bid_Login01"><input type="text" name="LoginForm[username]" placeholder="请输入用户名/手机号码" id="login-email-address"  /></li>
            <li class="bid_Login02"><input type="password" id="login-password" name="LoginForm[password]" placeholder="请输入密码" /></li>
            <li class="bid_Login03 clearfix"><p><input type="checkbox" id="autologin" name="LoginForm[rememberMe]" value="1" />下次自动登录</p><a href="/user/resetPassword">忘记密码</a></li>
            <li class="bid_Login04">
                <input type="submit"  id="user-login-submit" name="commit" value="" class="login_submit" />
                <input type="hidden" name="ajax" value="1">
                <input type="hidden" name="preurl" value="{$preurl}" />
            <li class="bid_Login03 bid_Login05 clearfix"><p>没有家财猫账户？</p><a href="/user/register">立即免费注册</a></li>
        </ul>
    </form>
</div>
<!--登录end-->
