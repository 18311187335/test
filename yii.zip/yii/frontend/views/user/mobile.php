<!--当前位置start-->
<div class="NewsListAreaAvd">
    <ul class="NewsListArea_Nav01"><p><a href="<?php echo Yii::$app->urlManager->createUrl('/')?>" title="">首页</a><span>></span>注册</p></ul>
</div>
<!--当前位置end-->
<!--注册内容start-->
<div class="bid_Resiger">
    <ul class="bid_Resiger_Title">
        <li id="bid_Resiger06">
            <p><i>1.</i>注册信息</p>
            <p class="bid_Resiger_Title01"><i>2.</i>完善信息</p>
            <p><i>3.</i>注册完成</p>
        </li>
    </ul>
    <ul class="bid_Resiger_Info">
        <form id="form1" action="<?php echo Yii::$app->urlManager->createUrl('user/domobile')?>" method="post">
        <li><span class="bid_Resiger_Info01">手机号码</span><span><i><?php echo $mobile;?></i></span></li>
        <li>
            <span class="bid_Resiger_Info01">验证码</span>
            <span class="bid_Resiger_Info03 bid_Resiger_Info003"><input type="text" name="validatecode" value="" id="validateCode"  class="bid_Resiger_Code bid_Resiger_Code01" /></span>
            <span class="bid_Resiger_Info04 bid_Resiger_Info004"><input type="button" name="" value="" id="Buttom_num" class="Buttom_num"  /></span>
        </li>
        <li class="bid_Resiger01">
		<span class="bid_Resiger_Info01">
			<input type="hidden" id="J_Vphone" name="mobile" value="<?php echo $mobile?>" />
			<input type="hidden" id="user_name" name="user_name" value="<?php echo $user_name;?>" />
			<input type="hidden" id="user_pwd" name="user_pwd" value="<?php echo $user_pwd;?>" />
			<input type="hidden" name="preurl" value="<?php echo $preurl;?>" />
		</span>
            <span><input type="button" name="conmit" value="" class="bid_Resiger_Submits" id="checkMobile" onclick="return check_mobile()" /></span></li>
        </form>
    </ul>
</div>
<!--注册内容end-->

<div class="conLine02"></div>
<?php
$validataUrl = Yii::$app->urlManager->createUrl('user/domobile')."?isajax=1";
$jsStr =<<<EOF
    var wait=60;
    function time(o) {
        if (wait == 0) {
            o.removeAttribute("disabled");
            $(o).attr("class","Buttom_num");
            o.value="";
            wait = 60;
        } else {
            o.setAttribute("disabled", true);
            $(o).attr("class","Buttom_num_disabled");
            o.value="重新发送(" + wait + ")";
            wait--;
            setTimeout(function() {
                    time(o)
                },
                1000)
        }
    }
    function sendmobile(o,obj){
        if($.trim($(obj).val())==""){
            $.showErr(LANG.VERIFY_MOBILE_EMPTY);
            return false;
        }
        if(!$.checkMobilePhone($(obj).val())){
            $.showErr(LANG.FILL_CORRECT_MOBILE_PHONE);
            return false;
        }
        get_verify_code(obj);
        time(o);
    }

    function check_mobile(){
        validatecode = $.trim($("#validateCode").val());
        if(validatecode==""){
            $.showErr("验证码错误!");
            return false;
        }
        var mobile = $.trim($("#J_Vphone").val());
        var ajaxurl = "$validataUrl";
        $.ajax({
            type: "POST",
            url: ajaxurl,
            data: "validatecode="+validatecode.toString()+"&mobile="+mobile.toString(),
            dataType: "json",
            success: function(obj){
                if(obj.status==-1){
                    if(obj.info){
                        $.showErr(obj.info);
                    }else{
                        $("#validateCode").focus();
                        $.showErr("验证码失败!");
                    }
                    return false;
                }$('#form1').submit();
            },
            error:function(ajaxobj)
            {
                return false;
            }
        });
    }
    $("#Buttom_num").click(function(){
        sendmobile(this,"#J_Vphone")';
    })
    $("#checkMobile").click(function(){
        check_mobile();
    })
EOF;
$this->registerJs($jsStr);
?>