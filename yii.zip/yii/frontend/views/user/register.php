<?php
$this->registerCssFile('/css/common.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
$this->registerCssFile('/css/style.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
$this->registerJsFile('/js/script.js',['depends'=>[\frontend\assets\AppAsset::className(),\yii\web\YiiAsset::className()]]);
?>
<!--当前位置start-->
<div class="NewsListAreaAvd">
    <ul class="NewsListArea_Nav01"><p><a href="{url x="index"}" title=>首页</a><span>></span>注册</p></ul>
</div>
<!--当前位置end-->
<!--注册内容start-->
<div class="bid_Resiger">
    <ul class="bid_Resiger_Title bid_Resiger_Title001">
        <li id="bid_Resiger07">
            <p class="bid_Resiger_Title01"><i>1.</i>注册信息</p>
            <p><i>2.</i>完善信息</p>
            <p><i>3.</i>注册完成</p>
        </li>
        <div class="product_Investment_Tab bid_Resiger_Title002 clearfix" id="product_Investment_Tab02">
            <a href="javascript:void(0)" title="" id="Bid01" class="current">投资方注册</a>
        </div>
    </ul>
    <div class="product_Investment_Reviews" id="product_Investment_Reviews02">
        <ul class="bid_Resiger_Info">
            <form action="<?php echo Yii::$app->urlManager->createUrl('user/doregister')?>" method="post" id="signup-user-form">
            <li>
                <span class="bid_Resiger_Info01">用户名</span>
                <span class="bid_Resiger_Info02"><input type="text" id="signup-username" name="user_name"  class="bid_Resiger_Text" /></span>
                <p class="f-input-tip Input01" id="signup-username_tip"></p>

                <p class="hint Input02">&nbsp;4-15个字符，一个汉字为2个字符</p>
            </li>
            <li>
                <span class="bid_Resiger_Info01">手机</span>
                <span class="bid_Resiger_Info02"><input type="text" id="settings-mobile" name="mobile"  class="bid_Resiger_Text" /></span>

                <p class="f-input-tip Input03" id="settings-mobile_tip"></p>

                <p class="hint Input04">&nbsp;接收验证码保护账户安全</p>
            </li>
            <li>
                <span class="bid_Resiger_Info01">密码</span>
                <span class="bid_Resiger_Info02"><input type="password" id="signup-password" name="user_pwd"  class="bid_Resiger_Text"/></span>
                <p class="f-input-tip Input05" id="signup-password_tip"></p>

                <p class="hint Input06">&nbsp;最少 6 个字符</p>
            </li>
            <li>
                <span class="bid_Resiger_Info01">确认密码</span>
                <span class="bid_Resiger_Info02"><input type="password" id="signup-password-confirm" name="user_pwd_confirm"  class="bid_Resiger_Text"  /></span>

                <p class="f-input-tip Input07" id="signup-password-confirm_tip"></p>

                <p class="hint Input08">&nbsp;请再次填写密码</p>
            </li>
            <li>
                <span class="bid_Resiger_Info01">邀请码</span>
                <span class="bid_Resiger_Info02"><input type="text" name="inv_uid" "{$inv_uid}" class="bid_Resiger_Code" /></span>


                <p class="hint Input10">&nbsp;填写邀请人手机号或邀请码，可不填</p>
            </li>
            <li>
                <span class="bid_Resiger_Info01">验证码</span>
                <span class="bid_Resiger_Info03"><input type="text" id="signup-verify" name="verify"  class="bid_Resiger_Code" /></span>
                <span class="bid_Resiger_Info04"><img src="<?php echo Yii::$app->urlManager->createUrl('index/verify')?>?random=<?php echo time();?>" onclick="this.src='<?php echo Yii::$app->urlManager->createUrl('index/verify')?>?random='+Math.random()" title="看不清楚？换一张" /></span>

                <p class="f-input-tip Input09" id="signup-verify_tip"></p>

                <p class="hint Input10">&nbsp;请填写验证码</p>
            </li>

            <li><span class="bid_Resiger_Info01"></span><p><input type="checkbox" name=""  id="check_box01" autocomplete="off"  />我已阅读并同意《<a href="<?php echo Yii::$app->urlManager->createUrl('news').'?cate_id=9&id=93';?>" target="_blank">家财猫服务条款</a>》</p></li>
            <li><span class="bid_Resiger_Info01"></span><span><input type="submit" id="signup-submit" value=""   class="bid_Resiger_Submits_disabled" disabled="true" /></span></li>
            <li><span class="bid_Resiger_Info01"></span><span>已有账户？<a href="<?php echo Yii::$app->urlManager->createUrl("user/login")?>">立即登录</a></span></li>
            </form>
        </ul>


    </div>

</div>
<!--注册内容end-->
<div class="conLine02"></div>
<?php
$checkFieldUrl = Yii::$app->urlManager->createUrl('index/ajaxCheckField');
$jsStr = <<<EOF
$("#signup-username").blur(function(){
 	$(".Input01").css("display","block");
 	$(".Input02").css("display","none");
});

$("#settings-mobile").blur(function(){
 	$(".Input03").css("display","block");
 	$(".Input04").css("display","none");
});

$("#signup-password").blur(function(){
 	$(".Input05").css("display","block");
 	$(".Input06").css("display","none");
});

$("#signup-password-confirm").blur(function(){
 	$(".Input07").css("display","block");
 	$(".Input08").css("display","none");
});

$("#signup-verify").blur(function(){
 	$(".Input09").css("display","block");
 	$(".Input10").css("display","none");
});


$(document).ready(function(){

	$("#signup-submit").click(function(){
		if($.trim($("#settings-mobile").val()).length == 0)
		{
			$("#settings-mobile").focus();
			$.showErr("手机号码不能为空");

			return false;
		}

		if(!$.checkMobilePhone($("#settings-mobile").val()))
		{
			$("#settings-mobile").focus();
			$.checkMobilePhone("手机号码格式错误");
			return false;
		}

		if(!$.minLength($("#signup-username").val(),4,true))
		{
			$("#signup-username").focus();
			$.showErr("帐号格式错误");
			return false;
		}

		if(!$.maxLength($("#signup-username").val(),16,true))
		{
			$("#signup-username").focus();
			$.showErr("帐号格式错误");
			return false;
		}

		if(!$.minLength($("#signup-password").val(),6,false))
		{
			$("#signup-password").focus();
			$.showErr("密码格式错误");
			return false;
		}

		if($("#signup-password-confirm").val() != $("#signup-password").val())
		{
			$("#signup-password-confirm").focus();
			$.showErr("密码确认失败");
			return false;
		}

		if(!$.maxLength($("#signup-username").val(),16,true))
		{
			$("#signup-username").focus();
			$.showErr("帐号格式错误");
			return false;
		}


								});


	//开始绑定
	$("#signup-mobile").bind("blur",function(){
		if($.trim($("#signup-mobile").val()).length == 0)
		{
			formError($("#signup-mobile_tip").parent()," 手机号码不能为空");
			return false;
		}

		if(!$.checkEmail($("#signup-mobile").val()))
		{
			formError($("#signup-mobile_tip")," 手机号码格式错误");
			return false;
		}

		//var ajaxurl = "$checkFieldUrl";
		var ajaxurl = "$checkFieldUrl";
		var query = new Object();
		query.field_name = "mobile";
		query._csrf= yii.getCsrfToken();
		query.field_data = $.trim($(this).val());
		$.ajax({
			url: ajaxurl,
			data:query,
			type: "POST",
			dataType: "json",
			success: function(data){
				if(data.status==1)
				{
					formSuccess($("#signup-mobile_tip"),"&nbsp;可以使用");
					return false;
				}
				else
				{
					formError($("#signup-mobile_tip"),"&nbsp;"+data.info);
					return false;
				}
			}
		});
	}); //手机验证



	$("#signup-username").bind("blur",function(){
		if(!$.minLength($("#signup-username").val(),4,true))
		{
			formError($("#signup-username_tip"),"&nbsp;帐号格式错误");
			return false;
		}

		if(!$.maxLength($("#signup-username").val(),16,true))
		{
			formError($("#signup-username_tip"),"&nbsp;帐号格式错误");
			return false;
		}

		var ajaxurl = "$checkFieldUrl";
		var query = new Object();
		query.field_name = "user_name";
		query._csrf= yii.getCsrfToken();
		query.field_data = $.trim($(this).val());
		$.ajax({
			url: ajaxurl,
			data:query,
			type: "POST",
			dataType: "json",
			success: function(data){
				if(data.status==1)
				{
					formSuccess($("#signup-username_tip"),"&nbsp;可以使用");
					return false;
				}
				else
				{
					formError($("#signup-username_tip"),"&nbsp;"+data.info);
					return false;
				}
			}
		});
	}); //用户名验证


	$("#signup-password").bind("blur",function(){
		if(!$.minLength($("#signup-password").val(),6,false))
		{
			formError($("#signup-password_tip"),"&nbsp;密码格式错误");
			return false;
		}
		formSuccess($("#signup-password_tip"),"&nbsp;可以使用");
	}); //密码验证

	$("#signup-password-confirm").bind("blur",function(){
		if($("#signup-password-confirm").val() != $("#signup-password").val())
		{
			formError($("#signup-password-confirm_tip"),"&nbsp;密码确认失败");
			return false;
		}
		formSuccess($("#signup-password-confirm_tip"),"&nbsp;验证正确");
	}); //确认密码验证

	$("#settings-mobile").bind("blur",function(){
		if(!$.checkMobilePhone($("#settings-mobile").val()))
		{
			formError($("#settings-mobile_tip"),"&nbsp;手机号码格式错误");
			return false;
		}

					if($.trim($("#settings-mobile").val()).length == 0)
			{
				formError($("#settings-mobile_tip"),"&nbsp;手机号码不能为空");
				return false;
			}

		var ajaxurl = "$checkFieldUrl";
		var query = new Object();
		query.field_name = "mobile";
		query._csrf= yii.getCsrfToken();
		query.field_data = $.trim($(this).val());
		$.ajax({
			url: ajaxurl,
			data:query,
			type: "POST",
			dataType: "json",
			success: function(data){
				if(data.status==1)
				{
					if(query.field_data!='')
					formSuccess($("#settings-mobile_tip"),"&nbsp;可以使用");
					else
					formSuccess($("#settings-mobile_tip"),"");
					return false;
				}
				else
				{
					formError($("#settings-mobile_tip"),"&nbsp;"+data.info);
					return false;
				}
			}
		});
	}); //手机验证

	$("#signup-verify").bind("blur",function(){
		if($.trim($("#signup-verify").val()).length == 0)
		{
			formError($("#signup-verify_tip"),"&nbsp;验证码错误");
			return false;
		}


		var ajaxurl = "$checkFieldUrl";
		var query = new Object();
		query.field_name = "verify";
		query._csrf= yii.getCsrfToken();
		query.field_data = $.trim($(this).val());
		$.ajax({
			url: ajaxurl,
			data:query,
			type: "POST",
			dataType: "json",
			success: function(data){
				if(data.status==1)
				{
					if(query.field_data!='')
					formSuccess($("#signup-verify_tip"),"&nbsp;验证成功");
					else
					formSuccess($("#signup-verify_tip"),"");
					return false;
				}
				else
				{
					formError($("#signup-verify_tip"),"&nbsp;"+data.info);
					return false;
				}
			}
		});
	}); //验证码验证



					});



function check_box(){
	if(document.getElementById('check_box01').checked){
		document.getElementById('signup-submit').disabled=false;
		$("#signup-submit").removeClass("bid_Resiger_Submits_disabled").addClass("bid_Resiger_Submits");
	}else{
		document.getElementById('signup-submit').disabled=true;
		$("#signup-submit").removeClass("bid_Resiger_Submits").addClass("bid_Resiger_Submits_disabled");
	}
}

                $("#check_box01").click(function(){
                    check_box();
                })
EOF;
$this->registerJs($jsStr);
?>
</div>