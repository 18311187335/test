<!--当前位置start-->
<div class="NewsListAreaAvd">
    <ul class="NewsListArea_Nav01"><p><a href="<?php echo Yii::$app->urlManager->createUrl('index')?>" title="">首页</a><span>></span>注册</p></ul>
</div>
<!--当前位置end-->
<!--注册内容start-->
<div class="bid_Resiger">
    <ul class="bid_Resiger_Title">
        <li id="bid_Resiger05">
            <p><i>1.</i>注册信息</p>
            <p><i>2.</i>完善信息</p>
            <p class="bid_Resiger_Title01"><i>3.</i>注册完成</p>
        </li>
    </ul>
    <ul class="bid_Resiger_Info bid_Resiger_Info06">
        <div>
            <p><img src="/images/jc_36.jpg" width="54" height="54" /></p>
            <p class="bid_Resiger_Info07">恭喜您，注册成功！</p>
            <p>* <i>特别提示：</i>汇付宝是家财猫的第三方支付及资金托管平台，交易全程家财猫承诺不接触用户资金。在汇付宝平台上进行充值，提现，支付等操作，能够保护您的资金安全！</p>
            <p><a href="<?php echo Yii::$app->urlManager->createUrl('user/heepaybind')?>">立即绑定汇付宝 >></a></p>
        </div>
    </ul>
</div>
<!--注册内容end-->
<div class="conLine02"></div>