<?php
use yii\helpers\Html;
use frontend\assets\AppAsset;
use kartik\growl\Growl;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
$cssStr = '*{box-sizing: content-box; } p,h4, .h4, h5, .h5, h6, .h6{margin:0;}';
$this->registerCss($cssStr);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php
foreach(Yii::$app->session->getAllFlashes() as $message){
    echo Growl::widget(['type' => (!empty($message['type'])) ? $message['type'] : 'danger',
    'title' => (!empty($message['title'])) ? Html::encode($message['title']) : 'Title Not Set!',
    'icon' => (!empty($message['icon'])) ? $message['icon'] : 'fa fa-info',
    'body' => (!empty($message['message'])) ? Html::encode($message['message']) : 'Message Not Set!',
    'showSeparator' => true,
    'delay' => 1,
        'pluginOptions' => [
            'showProgressbar' => true,
            'placement' => [
                'from' => $message['positonY']?$message['positonY']:'top',
                'align' => $message['positonX']?$message['positonX']:'right',
            ]
        ]
    ]);
} ?>
    <?php $this->beginBody() ?>
    <div class="on_Line_Box" id="BizQQWPA">
        <ul>
            <img src="/images/on_Line.png" width="60" height="200" alt="" />
        </ul>
    </div>
    <style>
        .on_Line_Box{ display:block; width:60px; height:200px; overflow:hidden; position:fixed; _position:absolute; right:0;  top:50%; z-index:10; cursor:pointer;}
        .on_Line_Box ul{ display:block; width:100%; height:auto; overflow:hidden;}
        .on_Line_Box ul img{ display:block;}
    </style>
    <!--头部start-->
    <div class="Jindex_HeaderBox">
        <ul class="Jindex_HeaderBox_Avds">
            <div class="Jindex_HeaderBox_Left">
                <span>关注我们</span>
                <p><a href="javascript:void(0)" title="" onmouseover="show_qqchat(true)" onmouseout="show_qqchat(false)"><img src="/images/2015020501.png" width="15" height="15" alt="" /></a></p>
                <p><a href="http://weibo.com/wanwandai" target="_blank"><img src="/images/2015020502.png" width="17" height="15" alt="" /></a></p>
                <p><a href="javascript:void(0)" title=""  onclick="show_wechat()"><img src="/images/2015020503.png" width="18" height="15" alt="" /></a></p>
            </div>
            <!--QQstart-->
            <div id="WechatInfo" style="display:none;">
                <i>官方QQ群</i>
                <p>255506863</p>
            </div>
            <!--QQend-->
            <!--微信start-->
            <div id="Wechat" style="display:none;">
                <ul>
                    <li class="Wechat_Top"><h5>关注家财猫官方微信</h5><img src="/images/js_29.png" onclick="show_wechat()" width="11" height="11" alt="" /></li>
                    <li class="Wechat_Info clearfix">
                        <div class="Wechat_Info_Left"><img src="/images/u29.jpg" width="130" height="130" alt=""/></div>
                        <div class="Wechat_Info_Right">
                            <p class="Wechat01">打开微信</p>
                            <p class="Wechat02">点击底部“发现”</p>
                            <p class="Wechat03">点击扫一扫，扫描左侧二维码</p>
                        </div>
                    </li>
                </ul>
            </div>
            <!--微信end-->

            <div class="Jindex_HeaderBox_Right">
                <ul class="Jindex_01">
                    <p class="Jcm_01">客服电话：400-876-9396</p>
                    <span><img src="/images/2014020501.jpg" width="1" height="15" alt="" /></span>
                </ul>
                <?php if(Yii::$app->user->isGuest){?>
                <ul class="Jindex_01 Jindex_02">
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl('user/login');?>" title="">登录</a></p>
                    <span><img src="/images/2014020501.jpg" width="1" height="15" alt="" /></span>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl('user/register');?>" title="">注册</a></p>
                </ul>
                <?php }else{?>
                <ul class="Jindex_01 Jindex_02">
                    <p>欢迎登录,<a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/index');?>">
                            <?php $user = Yii::$app->user->getIdentity();if($username = $user->user_name){echo $username;}else{echo $user->mobile;}?></a></p>
                    <span><img src="/images/2014020501.jpg" width="1" height="15" alt="" /></span>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl('user/loginout');?>">退出</a></p>
                </ul>
                <?php }?>
            </div>
        </ul>
    </div>
    <div class="Jindex_Menus">
        <div>
            <ul class="Jindex_Menus_Left">
                <a href="/" title=""><img src="/images/logo.png"/></a>
                <h1>家财猫-钱景</h1>
            </ul>
            <ul class="Jindex_Menus_Right">
                <?php
                $navs = $this->params['navDatas'];
                $controllerID = Yii::$app->controller->id;
                foreach($navs as $u){
                    $current = "";
                    $url = "/".$u->url;
                    if(!$u->url && $controllerID == "index"){
                        $current = 'class="current"';
                    }elseif(strpos($url,"/".$controllerID,0) === 0){
                        $current = 'class="current"';
                    }
                    ?>
                    <li><a href="<?php echo $url;?>" <?php echo $current?> ><?php echo $u->name;?></a></li>
                <?php }
                ?>
            </ul>
        </div>
    </div>
    <div class="J_Line01"></div>
    <!--头部end-->

        <?= $content ?>

    <!--底部start-->
    <!--微信start-->
    <div id="Wechat_Info" style="display:none;">
        <ul>
            <li class="Wechat_Top"><h5>关注家财猫官方微信</h5><img src="/images/js_29.png" onclick="show_wechat2()" width="11" height="11" alt="" /></li>

            <li class="Wechat_Info clearfix">
                <div class="Wechat_Info_Left"><img src="/images/u29.jpg" width="130" height="130" alt=""/></div>
                <div class="Wechat_Info_Right">
                    <p class="Wechat01">打开微信</p>
                    <p class="Wechat02">点击底部“发现”</p>
                    <p class="Wechat03">点击扫一扫，扫描左侧二维码</p>
                </div>
            </li>
        </ul>
    </div>
    <!--微信end-->

    <div class="Jindex_Footer">
        <div class="Jindex_Footer_Avds">

            <ul class="Jindex_Footer_Top clearfix">
                <li class="Jindex_04">
                    <p class="Jcm_03"><img src="/images/2015020506.png" width="205" height="64" alt="" /></p>
                    <h5>关注我们</h5>
                    <p class="Jcm_04">

                        <i><a href="javascript:void(0)" title="" class="Wx_01" onclick="show_wechat2()"></a></i>
                        <i><a href="http://weibo.com/wanwandai" target="_blank" title="" class="Wx_02"></a></i>
                        <i style="position:relative;">
                            <!--QQstart-->
                            <span id="WechatInfo02" style="z-index:1;display:none;">
                            <i>官方QQ群</i>
                            <b>255506863</b>
                            </span>
                            <!--QQend-->
                            <a href="javascript:void(0)" title="" class="Wx_03" onmouseover="show_qqchat2(true)" onmouseout="show_qqchat2(false)"></a></i>
                    </p>
                    <p class="Jcm_05">咨询热线：周一至周五  9：00-21：00</p>
                    <p class="Jcm_06">400-876-9396</p>
                </li>
                <li class="Jindex_05">
                    <h5>公司信息</h5>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=28";?>">网站简介</a></p>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=34";?>">招贤纳士</a></p>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=38";?>">管理团队</a></p>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=29";?>">联系方式</a></p>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=8";?>">安全保障</a></p>
                </li>
                <li class="Jindex_05">
                    <h5>相关政策</h5>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=35";?>">使用协议</a></p>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=31";?>">免责条款</a></p>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=3";?>">隐私保护</a></p>
                    <p><a href="<?php echo Yii::$app->urlManager->createUrl("news")."?cate_id=42";?>">积分说明</a></p>
                </li>

                <li class="Jindex_05">
                    <h5>手机应用</h5>
                    <span class="Jcm_07">家财猫基金</span>
<span class="Jcm_08">
<a href="https://itunes.apple.com/cn/app/jia-cai-mao-ji-jin/id865194049" target="_blank" title=""><img src="/images/2015020513.png" width="17" height="20" alt="" /><i>iOS</i></a>
<a href="javascript:void(0)" title="" style="position:relative;" onclick="img_Open2()"><img src="/images/2015020514.png" width="17" height="20" alt="" /><i>Android</i>
    <img src="/images/20150504001.png" width="402" height="181" alt="" id="code_Img2" style=" display:none; position:absolute; left:-322px; top:-100px;" />
</a>
</span>

                    <span class="Jcm_07">钱景家财猫</span>
<span class="Jcm_08">
<a href="https://itunes.apple.com/us/app/jia-cai-mao/id976054912?l=zh&ls=1&mt=8" title="" target="_blank"><img src="/images/2015020513.png" width="17" height="20" alt="" /><i>iOS</i></a>
<a href="javascript:void(0)" title="" style="position:relative;" onclick="img_Open()"><img src="/images/2015020514.png" width="17" height="20" alt="" /><i>Android</i>
    <img src="/images/2015031301.png" width="402" height="181" alt="" id="code_Img" style=" display:none; position:absolute; left:-322px; top:-100px;" />
</a>
</span>

                </li>
            </ul>

            <ul class="Jindex_Footer_Bottom">

                <li class="Jindex_06">
                    <span>友情链接：</span>
                    <p><a href="http://www.p2pchina.com/" target="_blank">网贷中国</a></p>
                    <p><a href="http://www.p2pchina.com/" target="_blank">网贷天眼</a></p>
                    <p><a href="http://www.dyxtw.com/" target="_blank">第一信托网</a></p>
                    <p><a href="http://www.niuji.net/" target="_blank">牛基网</a></p>
                    <p><a href="https://www.heepay.com/" target="_blank">汇付宝</a></p>
                    <p><a href="http://www.qianjing.com" target="_blank">钱景网</a></p>
                    <p><a href="http://www.wangdaitiandi.com/" target="_blank">网贷天地</a></p>
                    <p><a href="http://www.wdzx.com/" target="_blank">网贷中心</a></p>
                    <p><a href="http://www.wangdaizhijia.com/" target="_blank">网贷之家</a></p>
                </li>

                <li class="Jindex_07">
                    <p class="Jcm_09">
                        <i>Copyright © 2005-2015 www.jiacaimao.com Inc. All rights reserved</i>
                        <i>北京万万贷网络科技有限公司 版权所有 [京ICP备14031490号-3]</i>
                    </p>
                    <script type="text/javascript">var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F407cce1083d17b38646536b73b316ca5' type='text/javascript'%3E%3C/script%3E"));</script>
                    <p class="Jcm_10">
                        <span><a href="https://trustsealinfo.verisign.com/splash?form_file=fdf/splash.fdf&dn=www.jiacaimao.com&lang=zh_cn" target="_blank"><img src="/images/2015020510.png" width="82" height="33" alt="" /></a></span>
                        <span><a href="http://webscan.360.cn/index/checkwebsite/url/jiacaimao.com" target="_blank"><img src="/images/2015020511.png" width="82" height="33" alt="" /></a></span>
                    </p>
                </li>

            </ul>
        </div>
    </div>
    <!--底部end-->
    <script>

        function img_Open()
        {
            var img_show=document.getElementById('code_Img');
            if(img_show.style.display=="none")
            {
                img_show.style.display="block";
            }else{
                img_show.style.display="none";
            }
        }

        function img_Open2()
        {
            var img_show=document.getElementById('code_Img2');
            if(img_show.style.display=="none")
            {
                img_show.style.display="block";
            }else{
                img_show.style.display="none";
            }
        }
    </script>

    <script  type="text/javascript">
        var _sogou_sa_q = _sogou_sa_q || [];
        _sogou_sa_q.push(['_sid', '286882-295170']);
        (function() {
            var _sogou_sa_protocol = (("https:" == document.location.protocol) ? "https://" : "http://");
            var _sogou_sa_src=_sogou_sa_protocol+"hermes.sogou.com/sa.js%3Fsid%3D286882-295170";
            document.write(unescape("%3Cscript src='" + _sogou_sa_src + "' type='text/javascript'%3E%3C/script%3E"));
        })();
    </script>

    <?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>


