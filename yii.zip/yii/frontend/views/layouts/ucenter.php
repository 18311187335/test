<?php
$this->beginContent('@app/views/layouts/default.php');
$this->registerCssFile('/css/common.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
$this->registerCssFile('/css/style.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
$this->registerCssFile('/css/jquery.lightbox-0.5.css');
$this->registerCssFile('/css/weebox.css');
$this->registerJsFile('/js/jquery.lightbox-0.5.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/jquery.weebox.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/script.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$isCompany = $this->params['uinfo']['is_company'];
?>
<!--当前位置start-->
<div class="NewsListAreaAvd">
    <ul class="NewsListArea_Nav01"><p><a href="/" title="">首页</a><span>></span>个人中心</p></ul>
</div>
<!--当前位置end-->
<!--内容页start-->
<div class="asset_Size">
    <div class="asset_Size_Avds">
        <!--关于我们导航start-->
        <div class="AboutContentLeft">
            <!--左栏目start-->
            <div class="vtitle">
                <a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/index')?>" target="_self" class="v<?php echo ($this->params['menupflag'] == 0 )?' v02':' v01'?>">我的家财猫</a>
            </div>
            <div class="vcon" style="display: none;">
                <ul class="vconlist clearfix"></ul>
            </div>
            <div class="vtitle">
                <a href="javascript:void(0)" target="_self" class="v<?php echo ($this->params['menupflag'] == 4 )?' v02':''?>">我的积分</a>
            </div>
                <div class="vcon" <?php echo ($this->params['menupflag'] != 4 )?' style="display: none;"':''?>>
                    <ul class="vconlist clearfix">
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/score')?>" <?php echo ($this->params['menuflag'] == 9 )?' class="hover" ':''?>>兑换积分</a></li>
                    </ul>
                </div>
            <div class="vtitle"><a href="javascript:void(0)" target="_self" class="v<?php echo ($this->params['menupflag'] == 1 )?' v02':''?>">资金管理</a></div>
                <div class="vcon" <?php echo ($this->params['menupflag'] != 1 )?' style="display: none;"':''?>>
                    <ul class="vconlist clearfix">
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/earnings')?>" <?php echo ($this->params['menuflag'] == 0 )?' class="hover" ':''?>>资金统计</a></li>
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invest')?>" <?php echo ($this->params['menuflag'] == 1 )?' class="hover" ':''?>>交易记录</a></li>
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/incharge')?>" <?php echo ($this->params['menuflag'] == 2 )?' class="hover" ':''?> >充值</a></li>
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/carry')?>" <?php echo ($this->params['menuflag'] == 3 )?' class="hover" ':''?> >提现</a></li>
                        <?php if ($isCompany == 1){?>
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/apply')?>" <?php echo ($this->params['menuflag'] == 4 )?' class="hover" ':''?>>融资申请</a></li>
                        <?php }?>
                    </ul>
                </div>
            <div class="vtitle"><a href="javascript:void(0)" target="_self" class="v<?php echo ($this->params['menupflag'] == 2 )?' v02':''?>">账户管理</a></div>
                <div class="vcon" <?php echo ($this->params['menupflag'] != 2 )?' style="display: none;"':''?>>
                    <ul class="vconlist clearfix">
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/profile')?>" <?php echo ($this->params['menuflag'] == 4 )?' class="hover" ':''?> >个人信息</a></li>
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/credit')?>" <?php echo ($this->params['menuflag'] == 6 )?' class="hover" ':''?> >认证中心</a></li>
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/secret')?>"  <?php echo ($this->params['menuflag'] == 7 )?' class="hover" ':''?>>安全中心</a></li>
                    </ul>
                </div>
            <div class="vtitle"><a href="javascript:void(0)" target="_self" class="v<?php echo ($this->params['menupflag'] == 3 )?' v02':''?>">消息管理</a></div>
                <div class="vcon" <?php echo ($this->params['menupflag'] != 3 )?' style="display: none;"':''?>>
                    <ul class="vconlist clearfix">
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/msg')?>"  <?php echo ($this->params['menuflag'] == 8 )?' class="hover" ':''?>>系统消息</a></li>
                    </ul>
                </div>
            <?php
            if( $isCompany == 0){
            ?>
            <div class="vtitle"><a href="javascript:void(0)" target="_self" class="v<?php echo ($this->params['menupflag'] == 5 )?' v02':''?>">体验金账户</a></div>
                <div class="vcon"  <?php echo ($this->params['menupflag'] != 5 )?' style="display: none;"':''?>>
                <ul class="vconlist clearfix">
                    <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/experience')?>" <?php echo ($this->params['menuflag'] == 10 )?' class="hover" ':''?>>体验金账户</a></li>
                </ul>
                </div>
            <?php
            }
            ?>
            <div class="vtitle"><a href="javascript:void(0)" target="_self" class="v<?php echo ($this->params['menupflag'] == 6 )?' v02':''?>">邀请好友</a></div>
                <div class="vcon" <?php echo ($this->params['menupflag'] != 6 )?' style="display: none;"':''?>>
                    <ul class="vconlist clearfix">
                        <li><a href="<?php echo Yii::$app->urlManager->createUrl('ucenter/invite')?>" {<?php echo ($this->params['menuflag'] == 11 )?' class="hover" ':''?>>邀请好友</a></li>
                    </ul>
                </div>

        <!--左栏目end-->


        </div>
        <!--关于我们导航end-->
        <!--右栏目start-->
        <div class="AboutContentRight">
            <?= $content ?>
        </div>
        <!--右栏目end-->
    </div>
</div>
<!--内容页end-->
<div class="ConLine01 bk_Ground"></div>
<?php
$jsStr = <<<EOF
    $(document).ready(function(){
        $(".Pesinfo04").click(function(){
            $(".ConPesonInfo_List04").show();
        });
        //菜单隐藏展开
        var tabs_i = 0;
        $('.vtitle').click(function () {
            var _self = $(this);
            var j = $('.vtitle ').index(_self);
            tabs_i = j;
            $('.vcon ').slideUp().eq(tabs_i).slideDown();
        });
    });
    //select下拉列表
    $(document).ready(function() {
        $(".ConSaleTparS01").click(function(event) {
            event.stopPropagation();
            $(this).find(".ConSaleTparS_02").toggle();
            $(this).parent().siblings().find(".ConSaleTparS_02").hide();
        });
        $(document).click(function(event) {
            var eo = $(event.target);
            if ($(".ConSaleTparS01").is(":visible") && eo.attr("class") != "option" &&
                !eo.parent(".ConSaleTparS_02").length) $('.ConSaleTparS_02').hide();
        });
        /*赋值给文本框*/
        $(".ConSaleTparS_02 span").click(function() {
            var value = $(this).text();
            $(this).parent(".ConSaleTparS_02").siblings(".ConsaleTparS_01").val(value);
        })
    })
EOF;
$this->registerJs($jsStr);
    ?>
<?php $this->endContent();?>