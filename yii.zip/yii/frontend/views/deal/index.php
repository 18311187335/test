<?php
/* @var $this yii\web\View */
$progress_point = ($dealInfo->load_money/$dealInfo->borrow_amount)*100;
$need_money = $dealInfo->borrow_amount - $dealInfo->load_money;
$this->title = $dealInfo->name.'-家财猫';
$this->registerMetaTag([
    'name' => 'pinggu-site-verification',
    'content' => '1d2d7b0b69280ded0c529a204c3af2a9'
]);
$this->registerCssFile('/css/common.css');
$this->registerCssFile('/css/style.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
$this->registerCssFile('/css/jquery.lightbox-0.5.css');
$this->registerCssFile('/css/weebox.css');
$this->registerJsFile('/js/jquery.lightbox-0.5.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/dealDetail.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/jquery.weebox.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
$this->registerJsFile('js/script.js',['depends'=>[\frontend\assets\AppAsset::className()]]);
?>
<!--当前位置start-->
<div class="NewsListAreaAvd">
    <ul class="NewsListArea_Nav01"><p><a href="/" title="">首页</a><span>></span><a href="<?php echo Yii::$app->urlManager->createUrl('deals');?>" title="">理财列表</a><span>></span>项目详情</p></ul>
</div>
<!--当前位置end-->
<!--详情start-->
<div class="product_Detial">
    <ul>
        <li class="product_Detial01">
            <h1 class="clearfix">
                <?php if ($dealInfo->min_loan_money == $dealInfo->borrow_amount){?>
                <i><?php echo $dealInfo->name;?></i>
                <i class="product_Detial01_Img"><img src="/images/jc_27.png" width="12" height="12"
                                                     onmouseover="img_Over05()" onmouseout="img_Over06()"/>
                    <p id="product_Detial_Order01_Info01" style="display:none;">
                        单一投资者将资金出借给有良好实体经营、且有借款需求的企业，获得10-15%年化收益。</p></i>
                <?php }else {
                    echo $dealInfo->name;
                }
                ?>
            </h1>
        </li>
        <li class="Bid_Now_Info02 clearfix">
            <p><?php echo number_format($dealInfo->borrow_amount,0);?><i>借款总额</i></p><span></span>
            <p style="position:relative;"><?php echo $dealInfo->repay_time;?><i>
                    <?php echo ($dealInfo->repay_time_type == 0)?"天":"个月";?><br/>借款期限</i>
                <img src="/images/jc_05.jpg" width="12" height="12" onmouseover="img_Over07()"
                     onmouseout="img_Over08()" style="position:absolute; right:-15px; top:38px;"/>
                <b id="product_Detial_Order02_Info" style="display:none;">满标后开始计算借款期限天数</b>
            </p><span></span>

            <p><i>预期</i><em><?php echo number_format($dealInfo->rate,2)?>%</em><i>年利率</i></p>
        </li>
        <li class="product_Detial02 clearfix">
            <p>还款方式：<i>
               <?php
               $loadTypeStatus = "";
               if ($dealInfo->loantype  == 0){
                   $loadTypeStatus =  "等额本息";
               }elseif($dealInfo->loantype  == 1){
                   $loadTypeStatus =  "按月付息";
               }elseif($dealInfo->loantype  == 2){
                   $loadTypeStatus =  "到期本息，一次性支付";
               } echo $loadTypeStatus;
               ?></i></p>

            <p>融资人：<i><?php echo $dealInfo->username; ?></i></p>
            <p>筹标期限：<i id="enddate"></i></p>
        </li>
        <?php if ($contract_show){?>
        <li class="product_Detial02 clearfix">
            <a href="<?php echo Yii::$app->urlManager->createUrl('deal')."?id=".$dealInfo->id;?>#contract" target="_blank" class="contract">查看电子合同</a>
        </li>
        <?php }?>
    </ul>
    <div class="product_Detial_Order">
        <ul>
            <form action="<?php echo Yii::$app->urlManager->createUrl('deal/bid');?>" method="post">
                <input type="hidden" name="<?= Yii::$app->request->csrfParam; ?>" value="<?= Yii::$app->request->csrfToken; ?>" />
            <li><b>还需金额： <?php echo $need_money;?></b></li>
            <?php if ($dealInfo->min_loan_money == $dealInfo->borrow_amount){ ?>
            <input type="hidden" id="loadmoney" name="loadmoney" value="<?php $dealInfo->min_loan_money ?>"/>
            <script>
                $(document).ready(function () {
                    income(document.getElementById("loadmoney"), {$dealInfo->rate
                }, {$dealInfo->repay_time
                },
                {
                    $dealInfo->need_money_number
                }
                ,
                {
                    $dealInfo->repay_time_type
                }
                )
                ;
                })
            </script>
            <?php }else { ?>
            <li>
                <input type="text" id="loadmoney" name="loadmoney" class="money_Investment" value="输入您的投资金额"
                       <?php echo ($progress_point == 100)?'disabled="disabled"':'';?> autocomplete="off" onfocus="if (value=='输入您的投资金额'){value =''}" onblur="if (value ==''){value='输入您的投资金额'}"
                onkeyup="income(this,<?php echo $dealInfo->rate;?>,<?php echo $dealInfo->repay_time;?>,<?php echo $need_money;?>,<?php echo $dealInfo->repay_time_type;?>)"
                />
            </li>
            <?php } ?>
            <li class="product_Detial_Order01">
                <p>还款完成后收益：<i id="income">0</i>元</p>
                <?php if(Yii::$app->user->isGuest){?>
                <p>账户可用余额：<i>*****</i>元<span><img src="/images/jc_05.jpg" width="12" height="12"
                                                  onmouseover="img_Over03()" onmouseout="img_Over04()"/></span></p>
                <?php }else{ ?>
                <p>账户可用余额：<i><?php echo number_format($uinfo->money,2);?></i>元
                    + <i><?php echo number_format($uinfo->coupon,2);?></i>元</p>
                <?php } ?>
                <div id="product_Detial_Order01_Info" style="display:none;">登陆后可显示账户可用余额</div>
            </li>
            <li class="product_Detial_Order01_Info02"><p>注*
                    <?php if ($dealInfo->min_loan_money !=0){
                    echo "投资起点".$dealInfo->min_loan_money."元，";}?>
                    <?php if ($dealInfo->max_loan_money !=0){
                        echo "每标最高投资".$dealInfo->max_loan_money."元，";}?>增量基数<?php if ($dealInfo->min_loan_money == 0){echo 1;}else{ echo $dealInfo->min_loan_money; }?>元</p></li>
            <li class="product_Detial_Order01_Info03"><p>投资立即计息</p></li>
            <li>
                <input type="submit" name="commit" value=""
                       class="deal_submit<?php echo ($progress_point == 100)?'_disabled':''?>" <?php echo ($progress_point == 100)?'disabled':''?> onclick="return check_money(<?php  echo $dealInfo->min_loan_money;?>,<?php  echo $dealInfo->max_loan_money;?>)" />
                <input type="hidden" name="id" value="<?php echo $dealInfo->id;?>"/>
                <input type="hidden" id="user_money" value="<?php if(!Yii::$app->user->isGuest){ echo $uinfo->money;}else{echo 0;}?>" />
                <input type="hidden" id="user_coupon" value="<?php if(!Yii::$app->user->isGuest){ echo $uinfo->coupon;}else{echo 0;}?>"/>
            </li>
            </form>
        </ul>
    </div>
</div>
<!--详情end-->
<!--内容start-->
<div class="product_Detial_Content">
    <div class="product_Detial_Content_Avds">
        <ul class="product_Investment_Select">
            <li class="product_Investment_Tab fl">
                <a href="#top_detail" title="">项目详情</a>
                <a href="#top_company_detail" title="">融资人详情</a>
                <?php if ($dealInfo->agency_id){?><a href="#top_agency_detail" title="">担保信息</a><?php }?>
                <?php if ($mortgage){?><a href="#top_file" title="">相关文件</a><?php }?>
                <a href="#top_bid_log" title="">投资记录</a>
            </li>
            <li class="product_Detial_Content_Right fr"><a href="/public/contract/contract_examplejcm.pdf"
                                                           target="_blank">借款协议（范本）</a></li>
        </ul>
        <div class="product_Detial_Content_Reviews">
            <div class="product_Detial_Reviews">
                <!--项目详情start-->
                <ul id="top_detail">
                    <h2>项目详情</h2>
                    <li>
                        <span><i>还款方式：</i><?php echo $loadTypeStatus;?></span>
                    </li>
                    <li class="product_Detial_Info01">
                        <span><i>项目区域：</i>北京</span>
                        <span><i>融资总额：</i><?php echo number_format($dealInfo->borrow_amount,2);?>元</span>
                    </li>
                    <li class="product_Detial_Info01">
                        <span><i>预期年化收益：</i><?php echo $dealInfo->rate?>%</span>
                    </li>
                    <li class="product_Detial_Info02">
                        <i>项目描述：</i>
                        <p><?php echo $dealInfo->description ;?></p>
                    </li>
                    <li class="product_Detial_Info02">
                        <i>质押物详情：</i>
                        <p><?php echo str_replace("\n","<br/>",$dealInfo->pledge_detail) ;?></p>
                    </li>
                </ul>
                <!--项目详情end-->
                <!--公司详情start-->
                <ul id="top_company_detail">
                    <h2>融资人详情</h2>

                    <div class="product_Detial_Login">
                        <?php if(!Yii::$app->user->isGuest){?>
                        <li>
                            <span><i>融资人：</i><?php echo $dealInfo->username?></span>
                        </li>
                        <li class="product_Detial_Info02">
                            <i>经营范围：</i>

                            <p><?php echo $dealCompanyInfo->cbusiness; ?></p>
                        </li>
                        <li class="product_Detial_Info02">
                            <i>企业背景：</i>
                            <p><?php echo $dealCompanyInfo->cbackground; ?></p>
                            <p>
                                <?php
                                foreach ($dealCompanyExtInfo as $image) {
                                 ?>
                                    <img src="<?php echo $image; ?>" width="202" height="130"/>
                                <?php }
                                ?>
                            </p>
                        </li>
                        <?php }else {?>
                        <span><a href="<?php echo Yii::$app->urlManager->createUrl('user/login')?>">登录</a>后可查看融资机构详情</span>
                        <?php }?>
                    </div>
                </ul>
                <!--公司详情end-->
                <?php if ($dealInfo->agency_id){?>
                <!--担保信息start-->
                <ul id="top_agency_detail">
                    <h2>担保信息</h2>
                    <div class="product_Detial_Login">
                        <?php if(!Yii::$app->user->isGuest){?>
                        <li>
                            <span><i>担保机构：</i><a href="##" title="" style="color:#017ddd;"><?php echo $agency->user_name;?></a></span>
                        </li>
                        <li class="product_Detial_Info02">
                            <i>担保情况：</i>
                            <p><?php echo $angencyInfoRes->situation;?></p>
                        </li>
                        <li class="product_Detial_Info02">
                            <i>风险控制：</i>
                            <p><?php echo $angencyInfoRes->control;?></p>
                        </li>
                        <li class="product_Detial_Info02">
                            <i>担保意见：</i>
                            <p>
                                经过担保公司对借款企业及法定代表人的深入调查了解，企业在国内知名度较高，履约能力较强，同时借款企业自成立以来，企业经营稳中有升，业务范围不断扩大，收入逐年增加，还款来源有保障，并有稳定的客户群体，账款回款及时，故担保公司同意为本次融资项目提供担保。</p>
                            <p>
                                <?php
                                foreach ($agencyImages as $image) {
                                    ?>
                                    <img src="<?php echo $image; ?>" width="202" height="130"/>
                                <?php }
                                ?>
                            </p>
                        </li>
                        <?php }else{ ?>
                        <span><a href="<?php echo Yii::$app->urlManager->createUrl('user/login')?>">登录</a>后可查看担保机构详情</span>
                        <?php } ?>
                    </div>
                </ul>
                <!--担保信息end-->
                <?php } ?>
                <?php if ($mortgage){?>
                <!--相关文件start-->
                <ul id="top_file">
                    <h2>相关文件</h2>
                    <p>
                        <?php foreach ($mortgage as $image){?>
                        <a href="<?php echo $image?>" target="_blank"><img src="<?php echo $image?>" width="202" height="130"/></a>
                        <?php }?>
                    </p>
                </ul>
                <!--相关文件end-->
                <?php }?>
                <!--投资记录start-->
                <ul id="top_bid_log">
                    <h2>投资记录</h2>
                    <li class="product_Detial_Info03 clearfix">
                        <p>加入人次<i><?php echo count($dealLoadList);?>人</i></p>
                        <p>投标总额<i><?php echo number_format($dealInfo->load_money,0);?>元</i></p>
                    </li>
                    <li class="product_Detial_Info04">
                        <p><span class="pD_01">序号</span><span class="pD_02">投资人</span><span
                                class="pD_03">投资金额</span><span class="pD_04">投资时间</span></p>

                        <div id="lists">
                            <?php
                            foreach($dealLoadList as $key =>$load){
                                ?>
                                <p>
                                    <span class="pD_01"><?php echo $key + 1; ?></span>
                                    <span class="pD_02">
                                        <?php
                                        if($load->user_name){
                                            echo mb_substr($load->user_name,1,1)."***";
                                        }else{
                                            echo "匿名";
                                            //echo mb_substr($load->mobile,1,4)."****".mb_substr($load->mobile,-4,4);
                                        } ?></span>
                                    <span class="pD_03">￥<?php echo number_format($load->money,0);?></span>
                                    <span class="pD_04"><?php echo date("Y-m-d H:i:s",$load->create_time);?></span>
                                </p>
                            <?php } ?>
                        </div>
                        <div class="BidListPages" id="pages">
                        </div>
                    </li>
                </ul>
                <!--投资记录end-->
            </div>
        </div>
    </div>
    <div class="conLine01"></div>
</div>
<!--内容end-->
<div class="ConLine01 bk_Ground"></div>
<?php
$jsScript = <<<EOF
    $(function () {
        $('#top_file a').lightBox();
        obj = $("#lists p");
        j = obj.length;
        if (j != 0) {
            PagesLen = Math.ceil(j / listNum);
            upPage(0, "pages");
        }

        var objtime = $("#enddate");
        var enddate = $enddate;
        var Bf = setInterval(function () {
            var day = parseInt(enddate / 86400, 10);
            var hour = parseInt((enddate - 86400 * day) / 3600, 10);
            var minute = parseInt((enddate - 86400 * day - hour * 3600) / 60, 10);
            var second = parseInt(enddate - 86400 * day - hour * 3600 - minute * 60, 10);
            var datetime = '';
            datetime += "" + day + " 天 ";
            datetime += "" + hour + ' 时 ';
            datetime += "" + minute + ' 分 ';
            datetime += "" + second + ' 秒 ';
            enddate--;
            if (enddate <= 0) {
                objtime.html("筹标时间：筹标已结束");
                clearInterval(Bf);
            } else {
                objtime.html(datetime);
            }
        }, 1000);
    });
EOF;
$this->registerJs($jsScript);
?>