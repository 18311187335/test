<?php
/* @var $this yii\web\View */

use components\widgets\PageLink;

$this->title = '理财列表-家财猫';
$this->registerMetaTag([
    'name' => 'pinggu-site-verification',
    'content' => '1d2d7b0b69280ded0c529a204c3af2a9'
]);
$this->registerCssFile('/css/common.css');
$this->registerCssFile('/css/style.css',['depends'=>[\yii\bootstrap\BootstrapAsset::className()]]);
?>
<!--当前位置start-->
<div class="NewsListAreaAvd">
    <ul class="NewsListArea_Nav01"><p><a href="{url x=" shop" }" title="">首页</a><span>></span>理财列表</p></ul>
</div>
<!--当前位置end-->
<!--筛选条件start-->
<div class="product_Select_Case">
    <h2>筛选投资项目</h2>
    <ul class="clearfix">
        <span>项目类别：</span>
        <li class="Case01"><a href="<?php echo $dealTypeFilterUrl."&dealtype=0";?>" <?php if($dealtype == 0){echo 'class="current"';}?> >不限</a></li>
        <?php foreach($dealTypes as $dt){ ?>
        <li><a href="<?php echo $dealTypeFilterUrl."&dealtype=".$dt->id;?>"
            title="<?php echo $dt->name;?>" <?php if ($dealtype ==  $dt->id){ echo 'class="current"'; }?>><?php echo $dt->name;?></a></li>
        <?php }?>
    </ul>
    <ul class="clearfix">
        <span>项目状态：</span>
        <li class="Case01"><a href="<?php echo $dealStatsFilterUrl."&dealstate=0";?>" title="" <?php if(0 == $dealstate){echo 'class="current"';} ?>>不限</a></li>
        <?php foreach($dealStats as $sk=>$ds){ ?>
        <li><a href="<?php echo $dealStatsFilterUrl."&dealstate=".$sk;?>"
            title="" <?php if($sk == $dealstate){echo 'class="current"';}?>><?php echo $ds;?></a></li>
        <?php }?>
    </ul>
    <ul class="clearfix">
        <span>项目期限：</span>
        <li class="Case01"><a href="<?php echo $dealLimitsFilterUrl."&deallimit=0";?>" title="" <?php if(0 == $deallimit){echo 'class="current"';} ?>>不限</a></li>
        <?php foreach($dealLimits as $sl=>$dl){ ?>
            <li><a href="<?php echo $dealLimitsFilterUrl."&deallimit=".$sl;?>"
                   title="" <?php if($sl == $deallimit){echo 'class="current"';}?>><?php echo $dl;?></a></li>
        <?php }?>
    </ul>
    <ul class="clearfix">
        <span>项目收益：</span>
        <li class="Case01"><a href="<?php echo $profitRatiosFilterUrl."&profitratio=0";?>" title="" <?php if(0 == $profitratio){echo 'class="current"';} ?>>不限</a></li>
        <?php foreach($profitRatios as $pk=>$pl){ ?>
            <li><a href="<?php echo $profitRatiosFilterUrl."&profitratio=".$pk;?>"
                   title="" <?php if($pk == $profitratio){echo 'class="current"';}?>><?php echo $pl;?></a></li>
        <?php }?>
    </ul>
</div>
<!--筛选条件end-->
<!--投资项目start-->
<div class="product_Investment">
    <ul class="product_Investment_Con">
        <div class="product_Investment_Reviews" id="product_Investment_Reviews01">
            <div id="product_Investment_Reviews001">
                <ul class="product_Investment_Con_Title">
                    <p class="prduct01">项目名称</p>
                    <p class="prduct02">借款期限</p>
                    <p class="prduct02">借款总额</p>
                    <p class="prduct03">年化收益</p>
                    <p class="prduct04">借款进度</p>
                    <p class="prduct05">操作</p>
                </ul>
                <?php foreach($dealList as $dls){?>
                <ul>
                    <p class="prduct01">
                        <i><img src="/images/jc_38.jpg" width="20" height="20"/></i>
                        <a href="<?php echo Yii::$app->urlManager->createUrl('deal');?>?id=<?php echo $dls->id;?>" target="_blank"><?php echo $dls->name;?></a>
                    </p>

                    <p class="prduct02"><i><?php echo $dls->repay_time;?></i><?php if ($dls->repay_time_type == 0){ echo "天";}else{echo "个月";}?></p>

                    <p class="prduct02"><i><?php echo number_format($dls->borrow_amount,2) ?></i></p>

                    <p class="prduct03"><i><?php echo number_format($dls->rate,2)?>%</i></p>

                    <p class="prduct04"><span style="background-position:<?php echo intval($dls->ratio)*(-54)?>px 0px"><?php echo number_format($dls->ratio,0)?><i>%</i></span>
                    </p>
                    <?php
                        $statusClass = "canbid";
                        if($dls->deal_status == 1){
                            $statusClass = "canbid";
                        }elseif($dls->deal_status == 2){
                            $statusClass = "notbid";
                        }elseif($dls->deal_status == 4){
                            $statusClass = "repaying";
                        }elseif($dls->deal_status == 5){
                            $statusClass = "repayed";
                        }
                    ?>
                    <p class="prduct05"><a href="<?php echo Yii::$app->urlManager->createUrl('deal');?>?id=<?php echo $dls->id;?>" class="<?php echo $statusClass;?>" target="_blank"></a></p>
                </ul>
                <?php }?>
                <div class="BidListPages">
                    <?php echo PageLink::widget([
                        'activePageCssClass'=>'current',
                        'maxButtonCount'=>5,
                        'firstPageLabel'=>'第一页',
                        'prevPageLabel'=>'上一页',
                        'nextPageLabel'=>'下一页',
                        'lastPageLabel'=>'最后一页',
                    'pagination' => $pages,
                    ]);?>
                </div>
            </div>
        </div>
    </ul>
    <div class="conLine02"></div>
</div>
<!--投资项目end-->