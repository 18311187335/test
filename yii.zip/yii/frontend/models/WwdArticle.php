<?php

namespace app\models;

use Yii;
use yii\db\Query;

/**
 * This is the model class for table "{{%article}}".
 *
 * @property integer $id
 * @property string $title
 * @property string $thumb
 * @property string $content
 * @property integer $cate_id
 * @property integer $create_time
 * @property integer $update_time
 * @property integer $add_admin_id
 * @property integer $is_effect
 * @property string $rel_url
 * @property integer $update_admin_id
 * @property integer $is_delete
 * @property integer $click_count
 * @property integer $sort
 * @property string $seo_title
 * @property string $seo_keyword
 * @property string $seo_description
 * @property string $uname
 * @property string $sub_title
 * @property string $brief
 */
class WwdArticle extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%article}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'thumb', 'content', 'cate_id', 'create_time', 'update_time', 'add_admin_id', 'is_effect', 'rel_url', 'update_admin_id', 'is_delete', 'click_count', 'sort', 'seo_title', 'seo_keyword', 'seo_description', 'uname', 'sub_title', 'brief'], 'required'],
            [['content', 'seo_title', 'seo_keyword', 'seo_description', 'brief'], 'string'],
            [['cate_id', 'create_time', 'update_time', 'add_admin_id', 'is_effect', 'update_admin_id', 'is_delete', 'click_count', 'sort'], 'integer'],
            [['title', 'thumb', 'rel_url', 'uname', 'sub_title'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'thumb' => 'Thumb',
            'content' => 'Content',
            'cate_id' => 'Cate ID',
            'create_time' => 'Create Time',
            'update_time' => 'Update Time',
            'add_admin_id' => 'Add Admin ID',
            'is_effect' => 'Is Effect',
            'rel_url' => 'Rel Url',
            'update_admin_id' => 'Update Admin ID',
            'is_delete' => 'Is Delete',
            'click_count' => 'Click Count',
            'sort' => 'Sort',
            'seo_title' => 'Seo Title',
            'seo_keyword' => 'Seo Keyword',
            'seo_description' => 'Seo Description',
            'uname' => 'Uname',
            'sub_title' => 'Sub Title',
            'brief' => 'Brief',
        ];
    }
    //获取通告 type_id=2
    public static function getNotification($limit=0){
        $articListRes = (new Query())->from(self::tableName().' a')->select('a.*')
            ->leftJoin(WwdArticleCate::tableName().' ac', '`ac`.`id` = `a`.`cate_id`')
            ->where(['ac.type_id'=>2,'ac.is_effect'=>1,'ac.is_delete'=>0, 'a.is_effect'=>1,'a.is_delete'=>0])
            ->limit($limit)
            ->orderBy('a.create_time desc')
            ->all();
        return $articListRes;
    }
}
