<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%deal_msg_list}}".
 *
 * @property integer $id
 * @property string $dest
 * @property integer $send_type
 * @property string $content
 * @property integer $send_time
 * @property integer $is_send
 * @property integer $create_time
 * @property integer $user_id
 * @property string $result
 * @property integer $is_success
 * @property integer $is_html
 * @property string $title
 * @property integer $is_youhui
 * @property integer $youhui_id
 */
class WwdDealMsgList extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%deal_msg_list}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['dest', 'send_type', 'content', 'send_time', 'is_send', 'create_time', 'user_id', 'result', 'is_success', 'is_html', 'title', 'is_youhui', 'youhui_id'], 'required'],
            [['send_type', 'send_time', 'is_send', 'create_time', 'user_id', 'is_success', 'is_html', 'is_youhui', 'youhui_id'], 'integer'],
            [['content', 'result', 'title'], 'string'],
            [['dest'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'dest' => 'Dest',
            'send_type' => 'Send Type',
            'content' => 'Content',
            'send_time' => 'Send Time',
            'is_send' => 'Is Send',
            'create_time' => 'Create Time',
            'user_id' => 'User ID',
            'result' => 'Result',
            'is_success' => 'Is Success',
            'is_html' => 'Is Html',
            'title' => 'Title',
            'is_youhui' => 'Is Youhui',
            'youhui_id' => 'Youhui ID',
        ];
    }
}
