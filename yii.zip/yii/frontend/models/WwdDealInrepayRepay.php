<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%deal_inrepay_repay}}".
 *
 * @property integer $id
 * @property integer $deal_id
 * @property integer $user_id
 * @property double $repay_money
 * @property double $manage_money
 * @property double $impose
 * @property integer $repay_time
 * @property integer $true_repay_time
 */
class WwdDealInrepayRepay extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%deal_inrepay_repay}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['deal_id', 'user_id', 'repay_money', 'manage_money', 'impose', 'repay_time', 'true_repay_time'], 'required'],
            [['deal_id', 'user_id', 'repay_time', 'true_repay_time'], 'integer'],
            [['repay_money', 'manage_money', 'impose'], 'number']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'deal_id' => 'Deal ID',
            'user_id' => 'User ID',
            'repay_money' => 'Repay Money',
            'manage_money' => 'Manage Money',
            'impose' => 'Impose',
            'repay_time' => 'Repay Time',
            'true_repay_time' => 'True Repay Time',
        ];
    }
}
