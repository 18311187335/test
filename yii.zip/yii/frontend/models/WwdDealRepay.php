<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%deal_repay}}".
 *
 * @property integer $id
 * @property integer $deal_id
 * @property integer $user_id
 * @property double $repay_money
 * @property double $manage_money
 * @property double $impose_money
 * @property integer $repay_time
 * @property integer $true_repay_time
 * @property integer $status
 */
class WwdDealRepay extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%deal_repay}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['deal_id', 'user_id', 'repay_money', 'manage_money', 'impose_money', 'repay_time', 'true_repay_time', 'status'], 'required'],
            [['deal_id', 'user_id', 'repay_time', 'true_repay_time', 'status'], 'integer'],
            [['repay_money', 'manage_money', 'impose_money'], 'number']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'deal_id' => 'Deal ID',
            'user_id' => 'User ID',
            'repay_money' => 'Repay Money',
            'manage_money' => 'Manage Money',
            'impose_money' => 'Impose Money',
            'repay_time' => 'Repay Time',
            'true_repay_time' => 'True Repay Time',
            'status' => 'Status',
        ];
    }
    //关联查询
    public function getDeal(){
        return $this->hasOne(WwdDeal::className(),['id'=>'deal_id']); //字段名为引用表的字段 这里的andwhare 和oncondition 区别在于一个是on条件，一个是where的and条件
    }
}
