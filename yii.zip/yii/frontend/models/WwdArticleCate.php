<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%article_cate}}".
 *
 * @property integer $id
 * @property string $title
 * @property string $brief
 * @property integer $pid
 * @property integer $is_effect
 * @property integer $is_delete
 * @property integer $type_id   0 普通文章 1 帮助文章 2 公告文章  3系统文章
 * @property integer $sort
 */
class WwdArticleCate extends \yii\db\ActiveRecord
{
    public $subCate;  //业务属性
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%article_cate}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'brief', 'pid', 'is_effect', 'is_delete', 'type_id', 'sort'], 'required'],
            [['pid', 'is_effect', 'is_delete', 'type_id', 'sort'], 'integer'],
            [['title', 'brief'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'brief' => 'Brief',
            'pid' => 'Pid',
            'is_effect' => 'Is Effect',
            'is_delete' => 'Is Delete',
            'type_id' => 'Type ID',
            'sort' => 'Sort',
        ];
    }
}
