<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%change_log}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property integer $type_id
 * @property double $money_change
 * @property double $money_left
 * @property integer $create_time
 * @property string $detail
 */
class WwdChangeLog extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%change_log}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'type_id', 'money_change', 'money_left', 'create_time', 'detail'], 'required'],
            [['user_id', 'type_id', 'create_time'], 'integer'],
            [['money_change', 'money_left'], 'number'],
            [['detail'], 'string', 'max' => 1000]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'type_id' => 'Type ID',
            'money_change' => 'Money Change',
            'money_left' => 'Money Left',
            'create_time' => 'Create Time',
            'detail' => 'Detail',
        ];
    }
}
