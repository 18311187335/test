<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%user_log}}".
 *
 * @property integer $id
 * @property string $log_info
 * @property integer $log_time
 * @property integer $log_admin_id
 * @property integer $log_user_id
 * @property double $money
 * @property integer $score
 * @property integer $point
 * @property double $quota
 * @property double $lock_money
 * @property integer $user_id
 */
class WwdUserLog extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%user_log}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['log_info', 'log_time', 'log_admin_id', 'log_user_id', 'money', 'score', 'point', 'quota', 'lock_money', 'user_id'], 'required'],
            [['log_info'], 'string'],
            [['log_time', 'log_admin_id', 'log_user_id', 'score', 'point', 'user_id'], 'integer'],
            [['money', 'quota', 'lock_money'], 'number']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'log_info' => 'Log Info',
            'log_time' => 'Log Time',
            'log_admin_id' => 'Log Admin ID',
            'log_user_id' => 'Log User ID',
            'money' => 'Money',
            'score' => 'Score',
            'point' => 'Point',
            'quota' => 'Quota',
            'lock_money' => 'Lock Money',
            'user_id' => 'User ID',
        ];
    }
}
