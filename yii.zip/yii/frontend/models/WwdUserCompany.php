<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%user_company}}".
 *
 * @property integer $id
 * @property string $cbackground
 * @property string $cbusiness
 * @property integer $user_id
 * @property string $company_name
 * @property string $license
 * @property string $identity
 * @property string $credit_report
 * @property string $residence
 * @property string $lease
 * @property string $public_account
 */
class WwdUserCompany extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%user_company}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['cbackground', 'cbusiness', 'user_id', 'company_name', 'license', 'identity', 'credit_report', 'residence', 'lease', 'public_account'], 'required'],
            [['cbackground', 'cbusiness'], 'string'],
            [['user_id'], 'integer'],
            [['company_name', 'license', 'identity'], 'string', 'max' => 255],
            [['credit_report', 'residence', 'lease', 'public_account'], 'string', 'max' => 5000]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'cbackground' => 'Cbackground',
            'cbusiness' => 'Cbusiness',
            'user_id' => 'User ID',
            'company_name' => 'Company Name',
            'license' => 'License',
            'identity' => 'Identity',
            'credit_report' => 'Credit Report',
            'residence' => 'Residence',
            'lease' => 'Lease',
            'public_account' => 'Public Account',
        ];
    }
}
