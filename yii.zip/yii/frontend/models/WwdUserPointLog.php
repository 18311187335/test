<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%user_point_log}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property integer $action_type
 * @property integer $value
 * @property string $msg
 * @property integer $dateline
 */
class WwdUserPointLog extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%user_point_log}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'action_type', 'value', 'msg', 'dateline'], 'required'],
            [['user_id', 'action_type', 'value', 'dateline'], 'integer'],
            [['msg'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'action_type' => 'Action Type',
            'value' => 'Value',
            'msg' => 'Msg',
            'dateline' => 'Dateline',
        ];
    }
}
