<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%nav}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $url
 * @property integer $blank
 * @property integer $sort
 * @property integer $is_effect
 * @property string $u_module
 * @property string $u_action
 * @property integer $u_id
 * @property string $u_param
 * @property integer $is_shop
 * @property string $app_index
 * @property integer $pid
 */
class WwdNav extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%nav}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'url', 'blank', 'sort', 'is_effect', 'u_module', 'u_action', 'u_id', 'u_param', 'is_shop', 'app_index', 'pid'], 'required'],
            [['blank', 'sort', 'is_effect', 'u_id', 'is_shop', 'pid'], 'integer'],
            [['name', 'url', 'u_module', 'u_action', 'u_param', 'app_index'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'url' => 'Url',
            'blank' => 'Blank',
            'sort' => 'Sort',
            'is_effect' => 'Is Effect',
            'u_module' => 'U Module',
            'u_action' => 'U Action',
            'u_id' => 'U ID',
            'u_param' => 'U Param',
            'is_shop' => 'Is Shop',
            'app_index' => 'App Index',
            'pid' => 'Pid',
        ];
    }
}
