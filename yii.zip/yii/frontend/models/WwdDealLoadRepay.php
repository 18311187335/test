<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%deal_load_repay}}".
 *
 * @property integer $id
 * @property integer $deal_id
 * @property integer $load_id
 * @property integer $user_id
 * @property double $self_money
 * @property double $repay_money
 * @property double $manage_money
 * @property double $impose_money
 * @property integer $repay_time
 * @property integer $true_repay_time
 * @property integer $status
 * @property integer $is_site_repay
 * @property integer $l_key
 * @property integer $u_key
 */
class WwdDealLoadRepay extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%deal_load_repay}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['deal_id', 'load_id', 'user_id', 'self_money', 'repay_money', 'manage_money', 'impose_money', 'repay_time', 'true_repay_time', 'status', 'is_site_repay'], 'required'],
            [['deal_id', 'load_id', 'user_id', 'repay_time', 'true_repay_time', 'status', 'is_site_repay', 'l_key', 'u_key'], 'integer'],
            [['self_money', 'repay_money', 'manage_money', 'impose_money'], 'number']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'deal_id' => 'Deal ID',
            'load_id' => 'Load ID',
            'user_id' => 'User ID',
            'self_money' => 'Self Money',
            'repay_money' => 'Repay Money',
            'manage_money' => 'Manage Money',
            'impose_money' => 'Impose Money',
            'repay_time' => 'Repay Time',
            'true_repay_time' => 'True Repay Time',
            'status' => 'Status',
            'is_site_repay' => 'Is Site Repay',
            'l_key' => 'L Key',
            'u_key' => 'U Key',
        ];
    }
    //关联查询
    public function getDeal(){
        return $this->hasOne(WwdDeal::className(),['id'=>'deal_id']); //字段名为引用表的字段 这里的andwhare 和oncondition 区别在于一个是on条件，一个是where的and条件
    }
    //关联查询
    public function getDealLoad(){
        return $this->hasOne(WwdDealLoad::className(),['id'=>'load_id']); //字段名为引用表的字段 这里的andwhare 和oncondition 区别在于一个是on条件，一个是where的and条件
    }
    //关联查询获取关联标信息
    public function getInvestDealsByStatus(){
        return $this->hasOne(WwdDeal::className(),['id'=>'deal_id'])->andWhere(['in',WwdDeal::tableName().'.deal_status',[2,4]]); //字段名为引用表的字段 这里的andwhare 和oncondition 区别在于一个是on条件，一个是where的and条件
    }
    //获取待收本金时处理
    public static function getWaitCapital($uid){
        $money  = 0;
        $dealStatus = [2,4];
        $dealInfo = [];
        $loadRepayRes = self::find()->where(['user_id'=>$uid])->all();
        foreach($loadRepayRes as $lr){
            $dealId = $lr['deal_id'];
            if(!isset($dealInfo[$dealId])){
                $dealInfo[$dealId] = WwdDeal::findOne(['id'=>$dealId]);
            }
            $dealinfo = $dealInfo[$dealId];
            if(in_array($dealinfo['deal_status'],$dealStatus)){
                $money += $lr['self_money'];
            }
        }
        return $money;
    }
    //获取还款项目
    public static function getRepayItem($uid,$did,$repaytime,$lkey,$ukey){
        return self::find()->where(['user_id'=>$uid, 'deal_id'=>$did,'repay_time'=>$repaytime,'l_key'=>$lkey, 'u_key'=>$ukey])
            ->one();
    }
    //获取收益
    public static function  getInvestArr($uid){
        return  self::find()->select('SUM(self_money) as self_money ,SUM('.self::tableName().'.repay_money) as repay_money,SUM(impose_money) as impose_money')->joinWith('investDealsByStatus')->where([self::tableName().'.user_id'=>$uid])->all();
    }
}
