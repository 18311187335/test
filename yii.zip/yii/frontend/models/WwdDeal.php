<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%deal}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $sub_name
 * @property string $username
 * @property string $cate_id
 * @property integer $agency_id
 * @property integer $user_id
 * @property string $description
 * @property string $pledge_detail
 * @property integer $is_effect
 * @property integer $is_delete
 * @property integer $sort
 * @property integer $type_id
 * @property integer $icon_type
 * @property string $icon
 * @property string $seo_title
 * @property string $seo_keyword
 * @property string $seo_description
 * @property integer $is_hot
 * @property integer $is_new
 * @property integer $is_best
 * @property double $borrow_amount
 * @property double $min_loan_money
 * @property double $max_loan_money
 * @property integer $repay_time
 * @property double $rate
 * @property integer $day
 * @property integer $create_time
 * @property integer $update_time
 * @property string $name_match
 * @property string $name_match_row
 * @property string $deal_cate_match
 * @property string $deal_cate_match_row
 * @property string $tag_match
 * @property string $tag_match_row
 * @property string $type_match
 * @property string $type_match_row
 * @property integer $is_recommend
 * @property integer $buy_count
 * @property double $load_money
 * @property double $repay_money
 * @property integer $start_time
 * @property integer $success_time
 * @property integer $repay_start_time
 * @property integer $last_repay_time
 * @property integer $next_repay_time
 * @property integer $bad_time
 * @property integer $deal_status
 * @property integer $enddate
 * @property integer $voffice
 * @property integer $vposition
 * @property string $services_fee
 * @property integer $publish_wait
 * @property integer $is_send_bad_msg
 * @property string $bad_msg
 * @property integer $send_half_msg_time
 * @property integer $send_three_msg_time
 * @property integer $is_send_half_msg
 * @property integer $is_has_loans
 * @property integer $loantype
 * @property integer $warrant
 * @property string $titlecolor
 * @property integer $is_send_contract
 * @property integer $repay_time_type
 * @property integer $is_delivery
 * @property string $mortgage
 */
class WwdDeal extends \yii\db\ActiveRecord
{
    public $ratio; // 投标比率
    public $tr;     // 月日期限条件
    public $end_time; //结束日期 ucenter用
    public $income;   //投资收益 ucenter用
    public $url;   //投资收益 ucenter用
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%deal}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'sub_name', 'username', 'agency_id', 'user_id', 'description', 'pledge_detail', 'is_effect', 'is_delete', 'sort', 'type_id', 'icon_type', 'icon', 'seo_title', 'seo_keyword', 'seo_description', 'is_hot', 'is_new', 'is_best', 'borrow_amount', 'repay_time', 'rate', 'day', 'create_time', 'update_time', 'name_match', 'name_match_row', 'deal_cate_match', 'deal_cate_match_row', 'tag_match', 'tag_match_row', 'type_match', 'type_match_row', 'is_recommend', 'buy_count', 'load_money', 'repay_money', 'start_time', 'success_time', 'repay_start_time', 'last_repay_time', 'next_repay_time', 'bad_time', 'deal_status', 'enddate', 'voffice', 'vposition', 'services_fee', 'publish_wait', 'is_send_bad_msg', 'bad_msg', 'send_half_msg_time', 'send_three_msg_time', 'is_has_loans', 'loantype', 'warrant', 'titlecolor', 'is_send_contract', 'is_delivery'], 'required'],
            [['name', 'description', 'pledge_detail', 'seo_title', 'seo_keyword', 'seo_description', 'name_match', 'name_match_row', 'deal_cate_match', 'deal_cate_match_row', 'tag_match', 'tag_match_row', 'type_match', 'type_match_row', 'bad_msg'], 'string'],
            [['agency_id', 'user_id', 'is_effect', 'is_delete', 'sort', 'type_id', 'icon_type', 'is_hot', 'is_new', 'is_best', 'repay_time', 'day', 'create_time', 'update_time', 'is_recommend', 'buy_count', 'start_time', 'success_time', 'repay_start_time', 'last_repay_time', 'next_repay_time', 'bad_time', 'deal_status', 'enddate', 'voffice', 'vposition', 'publish_wait', 'is_send_bad_msg', 'send_half_msg_time', 'send_three_msg_time', 'is_send_half_msg', 'is_has_loans', 'loantype', 'warrant', 'is_send_contract', 'repay_time_type', 'is_delivery'], 'integer'],
            [['borrow_amount', 'min_loan_money', 'max_loan_money', 'rate', 'load_money', 'repay_money'], 'number'],
            [['sub_name', 'username', 'icon'], 'string', 'max' => 255],
            [['cate_id'], 'string', 'max' => 50],
            [['services_fee', 'titlecolor'], 'string', 'max' => 20],
            [['mortgage'], 'string', 'max' => 5000]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'sub_name' => 'Sub Name',
            'username' => 'Username',
            'cate_id' => 'Cate ID',
            'agency_id' => 'Agency ID',
            'user_id' => 'User ID',
            'description' => 'Description',
            'pledge_detail' => 'Pledge Detail',
            'is_effect' => 'Is Effect',
            'is_delete' => 'Is Delete',
            'sort' => 'Sort',
            'type_id' => 'Type ID',
            'icon_type' => 'Icon Type',
            'icon' => 'Icon',
            'seo_title' => 'Seo Title',
            'seo_keyword' => 'Seo Keyword',
            'seo_description' => 'Seo Description',
            'is_hot' => 'Is Hot',
            'is_new' => 'Is New',
            'is_best' => 'Is Best',
            'borrow_amount' => 'Borrow Amount',
            'min_loan_money' => 'Min Loan Money',
            'max_loan_money' => 'Max Loan Money',
            'repay_time' => 'Repay Time',
            'rate' => 'Rate',
            'day' => 'Day',
            'create_time' => 'Create Time',
            'update_time' => 'Update Time',
            'name_match' => 'Name Match',
            'name_match_row' => 'Name Match Row',
            'deal_cate_match' => 'Deal Cate Match',
            'deal_cate_match_row' => 'Deal Cate Match Row',
            'tag_match' => 'Tag Match',
            'tag_match_row' => 'Tag Match Row',
            'type_match' => 'Type Match',
            'type_match_row' => 'Type Match Row',
            'is_recommend' => 'Is Recommend',
            'buy_count' => 'Buy Count',
            'load_money' => 'Load Money',
            'repay_money' => 'Repay Money',
            'start_time' => 'Start Time',
            'success_time' => 'Success Time',
            'repay_start_time' => 'Repay Start Time',
            'last_repay_time' => 'Last Repay Time',
            'next_repay_time' => 'Next Repay Time',
            'bad_time' => 'Bad Time',
            'deal_status' => 'Deal Status',
            'enddate' => 'Enddate',
            'voffice' => 'Voffice',
            'vposition' => 'Vposition',
            'services_fee' => 'Services Fee',
            'publish_wait' => 'Publish Wait',
            'is_send_bad_msg' => 'Is Send Bad Msg',
            'bad_msg' => 'Bad Msg',
            'send_half_msg_time' => 'Send Half Msg Time',
            'send_three_msg_time' => 'Send Three Msg Time',
            'is_send_half_msg' => 'Is Send Half Msg',
            'is_has_loans' => 'Is Has Loans',
            'loantype' => 'Loantype',
            'warrant' => 'Warrant',
            'titlecolor' => 'Titlecolor',
            'is_send_contract' => 'Is Send Contract',
            'repay_time_type' => 'Repay Time Type',
            'is_delivery' => 'Is Delivery',
            'mortgage' => 'Mortgage',
        ];
    }
    //获取标列表
    public static function getDealList($status,$orderby,$limit){
        return self::find()->where(['is_recommend'=>1, 'publish_wait'=>0])
            ->andWhere(['in','deal_status',$status])
            ->limit($limit)
            ->orderBy($orderby)
            ->all();
    }
}
