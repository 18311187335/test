<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "wwd_msg_box".
 *
 * @property integer $id
 * @property string $title
 * @property string $content
 * @property integer $from_user_id
 * @property integer $to_user_id
 * @property integer $create_time
 * @property integer $is_read
 * @property integer $is_delete
 * @property integer $system_msg_id
 * @property integer $type
 * @property string $group_key
 * @property integer $is_notice
 */
class WwdMsgBox extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'wwd_msg_box';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'content', 'from_user_id', 'to_user_id', 'create_time', 'is_read', 'is_delete', 'system_msg_id', 'type', 'group_key', 'is_notice'], 'required'],
            [['content'], 'string'],
            [['from_user_id', 'to_user_id', 'create_time', 'is_read', 'is_delete', 'system_msg_id', 'type', 'is_notice'], 'integer'],
            [['title'], 'string', 'max' => 255],
            [['group_key'], 'string', 'max' => 200]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'content' => 'Content',
            'from_user_id' => 'From User ID',
            'to_user_id' => 'To User ID',
            'create_time' => 'Create Time',
            'is_read' => 'Is Read',
            'is_delete' => 'Is Delete',
            'system_msg_id' => 'System Msg ID',
            'type' => 'Type',
            'group_key' => 'Group Key',
            'is_notice' => 'Is Notice',
        ];
    }
}
