<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%payment}}".
 *
 * @property integer $id
 * @property string $class_name
 * @property integer $is_effect
 * @property integer $online_pay
 * @property double $fee_amount
 * @property string $name
 * @property string $description
 * @property double $total_amount
 * @property string $config
 * @property string $logo
 * @property integer $sort
 * @property integer $fee_type
 */
class WwdPayment extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%payment}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['class_name', 'is_effect', 'online_pay', 'fee_amount', 'name', 'description', 'total_amount', 'config', 'logo', 'sort', 'fee_type'], 'required'],
            [['is_effect', 'online_pay', 'sort', 'fee_type'], 'integer'],
            [['fee_amount', 'total_amount'], 'number'],
            [['description', 'config'], 'string'],
            [['class_name', 'name', 'logo'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'class_name' => 'Class Name',
            'is_effect' => 'Is Effect',
            'online_pay' => 'Online Pay',
            'fee_amount' => 'Fee Amount',
            'name' => 'Name',
            'description' => 'Description',
            'total_amount' => 'Total Amount',
            'config' => 'Config',
            'logo' => 'Logo',
            'sort' => 'Sort',
            'fee_type' => 'Fee Type',
        ];
    }
}
