<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%user_agency}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property integer $capital
 * @property string $legal
 * @property integer $city
 * @property string $overview
 * @property string $control
 * @property string $situation
 * @property string $license
 * @property string $permit
 * @property string $taxation
 * @property string $organization
 */
class WwdUserAgency extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%user_agency}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'capital', 'legal', 'city', 'overview', 'control', 'situation', 'license', 'permit', 'taxation', 'organization'], 'required'],
            [['user_id', 'capital', 'city'], 'integer'],
            [['overview', 'control', 'situation'], 'string'],
            [['legal', 'license', 'permit', 'taxation', 'organization'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'capital' => 'Capital',
            'legal' => 'Legal',
            'city' => 'City',
            'overview' => 'Overview',
            'control' => 'Control',
            'situation' => 'Situation',
            'license' => 'License',
            'permit' => 'Permit',
            'taxation' => 'Taxation',
            'organization' => 'Organization',
        ];
    }
}
