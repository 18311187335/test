<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%deal_loan_type}}".
 *
 * @property integer $id
 * @property string $name
 * @property string $brief
 * @property integer $pid
 * @property integer $is_delete
 * @property integer $is_effect
 * @property integer $sort
 * @property string $uname
 * @property string $icon
 */
class WwdDealLoanType extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%deal_loan_type}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'brief', 'pid', 'is_delete', 'is_effect', 'sort', 'uname'], 'required'],
            [['brief'], 'string'],
            [['pid', 'is_delete', 'is_effect', 'sort'], 'integer'],
            [['name', 'uname', 'icon'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'brief' => 'Brief',
            'pid' => 'Pid',
            'is_delete' => 'Is Delete',
            'is_effect' => 'Is Effect',
            'sort' => 'Sort',
            'uname' => 'Uname',
            'icon' => 'Icon',
        ];
    }
}
