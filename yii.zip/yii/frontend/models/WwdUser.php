<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%user}}".
 *
 * @property integer $id
 * @property string $user_name
 * @property string $user_pwd
 * @property string $pay_pwd
 * @property string $heepay_no
 * @property integer $create_time
 * @property integer $update_time
 * @property string $login_ip
 * @property integer $group_id
 * @property integer $is_effect
 * @property integer $is_delete
 * @property string $email
 * @property string $idno
 * @property integer $idcardpassed
 * @property integer $idcardpassed_time
 * @property string $real_name
 * @property string $mobile
 * @property integer $mobilepassed
 * @property integer $score
 * @property double $money
 * @property double $quota
 * @property double $lock_money
 * @property string $verify
 * @property string $code
 * @property integer $pid
 * @property integer $login_time
 * @property integer $referral_count
 * @property string $password_verify
 * @property integer $pwd_verify_create_time
 * @property integer $integrate_id
 * @property integer $sina_id
 * @property integer $renren_id
 * @property integer $kaixin_id
 * @property integer $sohu_id
 * @property string $bind_verify
 * @property integer $verify_create_time
 * @property string $pay_verify
 * @property integer $pay_verify_create_time
 * @property string $tencent_id
 * @property string $referer
 * @property integer $login_pay_time
 * @property integer $focus_count
 * @property integer $focused_count
 * @property integer $n_province_id
 * @property integer $n_city_id
 * @property integer $province_id
 * @property integer $city_id
 * @property integer $sex
 * @property integer $step
 * @property integer $byear
 * @property integer $bmonth
 * @property integer $bday
 * @property string $graduation
 * @property integer $graduatedyear
 * @property string $university
 * @property string $edu_validcode
 * @property integer $has_send_video
 * @property string $marriage
 * @property integer $haschild
 * @property integer $hashouse
 * @property integer $houseloan
 * @property integer $hascar
 * @property integer $carloan
 * @property string $car_brand
 * @property integer $car_year
 * @property string $car_number
 * @property string $address
 * @property string $phone
 * @property string $postcode
 * @property integer $locate_time
 * @property double $xpoint
 * @property double $ypoint
 * @property integer $topic_count
 * @property integer $fav_count
 * @property integer $faved_count
 * @property integer $insite_count
 * @property integer $outsite_count
 * @property integer $level_id
 * @property integer $point
 * @property string $sina_app_key
 * @property string $sina_app_secret
 * @property integer $is_syn_sina
 * @property string $tencent_app_key
 * @property string $tencent_app_secret
 * @property integer $is_syn_tencent
 * @property string $t_access_token
 * @property string $t_openkey
 * @property string $t_openid
 * @property string $sina_token
 * @property integer $is_borrow_out
 * @property integer $is_borrow_int
 * @property integer $creditpassed
 * @property integer $creditpassed_time
 * @property integer $workpassed
 * @property integer $workpassed_time
 * @property integer $incomepassed
 * @property integer $incomepassed_time
 * @property integer $housepassed
 * @property integer $housepassed_time
 * @property integer $carpassed
 * @property integer $carpassed_time
 * @property integer $marrypassed
 * @property integer $marrypassed_time
 * @property integer $edupassed
 * @property integer $edupassed_time
 * @property integer $skillpassed
 * @property integer $skillpassed_time
 * @property integer $videopassed
 * @property integer $videopassed_time
 * @property integer $mobiletruepassed
 * @property integer $mobiletruepassed_time
 * @property integer $residencepassed
 * @property integer $residencepassed_time
 * @property string $alipay_id
 * @property string $qq_id
 * @property string $info_down
 * @property string $taobao_id
 * @property string $qq
 * @property integer $is_company
 * @property string $company_num
 * @property integer $inv_uid
 * @property double $coupon
 * @property integer $active_num1
 * @property integer $active_num2
 * @property string $weixin_id
 * @property integer $score_access
 * @property string $token
 * @property double $experience
 */
class WwdUser extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%user}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_name', 'user_pwd', 'heepay_no', 'create_time', 'update_time', 'login_ip', 'group_id', 'is_effect', 'is_delete', 'email', 'idno', 'idcardpassed', 'idcardpassed_time', 'real_name', 'mobile', 'mobilepassed', 'score', 'money', 'lock_money', 'verify', 'code', 'pid', 'login_time', 'referral_count', 'password_verify', 'pwd_verify_create_time', 'integrate_id', 'sina_id', 'renren_id', 'kaixin_id', 'sohu_id', 'bind_verify', 'verify_create_time', 'pay_verify', 'pay_verify_create_time', 'tencent_id', 'referer', 'login_pay_time', 'focus_count', 'focused_count', 'n_province_id', 'n_city_id', 'province_id', 'city_id', 'step', 'byear', 'bmonth', 'bday', 'graduation', 'graduatedyear', 'university', 'edu_validcode', 'has_send_video', 'marriage', 'haschild', 'hashouse', 'houseloan', 'hascar', 'carloan', 'car_brand', 'car_year', 'car_number', 'address', 'phone', 'postcode', 'topic_count', 'fav_count', 'faved_count', 'insite_count', 'outsite_count', 'level_id', 'point', 'sina_app_key', 'sina_app_secret', 'is_syn_sina', 'tencent_app_key', 'tencent_app_secret', 'is_syn_tencent', 't_access_token', 't_openkey', 't_openid', 'sina_token', 'is_borrow_out', 'is_borrow_int', 'creditpassed', 'creditpassed_time', 'workpassed', 'workpassed_time', 'incomepassed', 'incomepassed_time', 'housepassed', 'housepassed_time', 'carpassed', 'carpassed_time', 'marrypassed', 'marrypassed_time', 'edupassed', 'edupassed_time', 'skillpassed', 'skillpassed_time', 'videopassed', 'videopassed_time', 'mobiletruepassed', 'mobiletruepassed_time', 'residencepassed', 'residencepassed_time', 'alipay_id', 'qq_id', 'info_down', 'taobao_id', 'qq', 'inv_uid', 'coupon', 'weixin_id', 'score_access', 'experience'], 'required'],
            [['create_time', 'update_time', 'group_id', 'is_effect', 'is_delete', 'idcardpassed', 'idcardpassed_time', 'mobilepassed', 'score', 'pid', 'login_time', 'referral_count', 'pwd_verify_create_time', 'integrate_id', 'sina_id', 'renren_id', 'kaixin_id', 'sohu_id', 'verify_create_time', 'pay_verify_create_time', 'login_pay_time', 'focus_count', 'focused_count', 'n_province_id', 'n_city_id', 'province_id', 'city_id', 'sex', 'step', 'byear', 'bmonth', 'bday', 'graduatedyear', 'has_send_video', 'haschild', 'hashouse', 'houseloan', 'hascar', 'carloan', 'car_year', 'locate_time', 'topic_count', 'fav_count', 'faved_count', 'insite_count', 'outsite_count', 'level_id', 'point', 'is_syn_sina', 'is_syn_tencent', 'is_borrow_out', 'is_borrow_int', 'creditpassed', 'creditpassed_time', 'workpassed', 'workpassed_time', 'incomepassed', 'incomepassed_time', 'housepassed', 'housepassed_time', 'carpassed', 'carpassed_time', 'marrypassed', 'marrypassed_time', 'edupassed', 'edupassed_time', 'skillpassed', 'skillpassed_time', 'videopassed', 'videopassed_time', 'mobiletruepassed', 'mobiletruepassed_time', 'residencepassed', 'residencepassed_time', 'is_company', 'inv_uid', 'active_num1', 'active_num2', 'score_access'], 'integer'],
            [['money', 'quota', 'lock_money', 'xpoint', 'ypoint', 'coupon', 'experience'], 'number'],
            [['user_name', 'user_pwd', 'pay_pwd', 'login_ip', 'email', 'mobile', 'verify', 'code', 'password_verify', 'bind_verify', 'pay_verify', 'tencent_id', 'referer', 'sina_app_key', 'sina_app_secret', 'tencent_app_key', 'tencent_app_secret', 'alipay_id', 'qq_id', 'info_down', 'taobao_id', 'weixin_id'], 'string', 'max' => 255],
            [['heepay_no', 'university'], 'string', 'max' => 100],
            [['idno', 'edu_validcode', 'postcode'], 'string', 'max' => 20],
            [['real_name', 'car_brand', 'car_number', 'phone', 'qq', 'company_num'], 'string', 'max' => 50],
            [['graduation', 'marriage'], 'string', 'max' => 15],
            [['address'], 'string', 'max' => 150],
            [['t_access_token', 't_openkey', 't_openid', 'sina_token'], 'string', 'max' => 250],
            [['token'], 'string', 'max' => 64]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_name' => 'User Name',
            'user_pwd' => 'User Pwd',
            'pay_pwd' => 'Pay Pwd',
            'heepay_no' => 'Heepay No',
            'create_time' => 'Create Time',
            'update_time' => 'Update Time',
            'login_ip' => 'Login Ip',
            'group_id' => 'Group ID',
            'is_effect' => 'Is Effect',
            'is_delete' => 'Is Delete',
            'email' => 'Email',
            'idno' => 'Idno',
            'idcardpassed' => 'Idcardpassed',
            'idcardpassed_time' => 'Idcardpassed Time',
            'real_name' => 'Real Name',
            'mobile' => 'Mobile',
            'mobilepassed' => 'Mobilepassed',
            'score' => 'Score',
            'money' => 'Money',
            'quota' => 'Quota',
            'lock_money' => 'Lock Money',
            'verify' => 'Verify',
            'code' => 'Code',
            'pid' => 'Pid',
            'login_time' => 'Login Time',
            'referral_count' => 'Referral Count',
            'password_verify' => 'Password Verify',
            'pwd_verify_create_time' => 'Pwd Verify Create Time',
            'integrate_id' => 'Integrate ID',
            'sina_id' => 'Sina ID',
            'renren_id' => 'Renren ID',
            'kaixin_id' => 'Kaixin ID',
            'sohu_id' => 'Sohu ID',
            'bind_verify' => 'Bind Verify',
            'verify_create_time' => 'Verify Create Time',
            'pay_verify' => 'Pay Verify',
            'pay_verify_create_time' => 'Pay Verify Create Time',
            'tencent_id' => 'Tencent ID',
            'referer' => 'Referer',
            'login_pay_time' => 'Login Pay Time',
            'focus_count' => 'Focus Count',
            'focused_count' => 'Focused Count',
            'n_province_id' => 'N Province ID',
            'n_city_id' => 'N City ID',
            'province_id' => 'Province ID',
            'city_id' => 'City ID',
            'sex' => 'Sex',
            'step' => 'Step',
            'byear' => 'Byear',
            'bmonth' => 'Bmonth',
            'bday' => 'Bday',
            'graduation' => 'Graduation',
            'graduatedyear' => 'Graduatedyear',
            'university' => 'University',
            'edu_validcode' => 'Edu Validcode',
            'has_send_video' => 'Has Send Video',
            'marriage' => 'Marriage',
            'haschild' => 'Haschild',
            'hashouse' => 'Hashouse',
            'houseloan' => 'Houseloan',
            'hascar' => 'Hascar',
            'carloan' => 'Carloan',
            'car_brand' => 'Car Brand',
            'car_year' => 'Car Year',
            'car_number' => 'Car Number',
            'address' => 'Address',
            'phone' => 'Phone',
            'postcode' => 'Postcode',
            'locate_time' => 'Locate Time',
            'xpoint' => 'Xpoint',
            'ypoint' => 'Ypoint',
            'topic_count' => 'Topic Count',
            'fav_count' => 'Fav Count',
            'faved_count' => 'Faved Count',
            'insite_count' => 'Insite Count',
            'outsite_count' => 'Outsite Count',
            'level_id' => 'Level ID',
            'point' => 'Point',
            'sina_app_key' => 'Sina App Key',
            'sina_app_secret' => 'Sina App Secret',
            'is_syn_sina' => 'Is Syn Sina',
            'tencent_app_key' => 'Tencent App Key',
            'tencent_app_secret' => 'Tencent App Secret',
            'is_syn_tencent' => 'Is Syn Tencent',
            't_access_token' => 'T Access Token',
            't_openkey' => 'T Openkey',
            't_openid' => 'T Openid',
            'sina_token' => 'Sina Token',
            'is_borrow_out' => 'Is Borrow Out',
            'is_borrow_int' => 'Is Borrow Int',
            'creditpassed' => 'Creditpassed',
            'creditpassed_time' => 'Creditpassed Time',
            'workpassed' => 'Workpassed',
            'workpassed_time' => 'Workpassed Time',
            'incomepassed' => 'Incomepassed',
            'incomepassed_time' => 'Incomepassed Time',
            'housepassed' => 'Housepassed',
            'housepassed_time' => 'Housepassed Time',
            'carpassed' => 'Carpassed',
            'carpassed_time' => 'Carpassed Time',
            'marrypassed' => 'Marrypassed',
            'marrypassed_time' => 'Marrypassed Time',
            'edupassed' => 'Edupassed',
            'edupassed_time' => 'Edupassed Time',
            'skillpassed' => 'Skillpassed',
            'skillpassed_time' => 'Skillpassed Time',
            'videopassed' => 'Videopassed',
            'videopassed_time' => 'Videopassed Time',
            'mobiletruepassed' => 'Mobiletruepassed',
            'mobiletruepassed_time' => 'Mobiletruepassed Time',
            'residencepassed' => 'Residencepassed',
            'residencepassed_time' => 'Residencepassed Time',
            'alipay_id' => 'Alipay ID',
            'qq_id' => 'Qq ID',
            'info_down' => 'Info Down',
            'taobao_id' => 'Taobao ID',
            'qq' => 'Qq',
            'is_company' => 'Is Company',
            'company_num' => 'Company Num',
            'inv_uid' => 'Inv Uid',
            'coupon' => 'Coupon',
            'active_num1' => 'Active Num1',
            'active_num2' => 'Active Num2',
            'weixin_id' => 'Weixin ID',
            'score_access' => 'Score Access',
            'token' => 'Token',
            'experience' => 'Experience',
        ];
    }
    //是否投标
    public  function isLoad(){
        return WwdDealLoad::find()->where(['user_id'=>$this->id])->count();
    }
}
