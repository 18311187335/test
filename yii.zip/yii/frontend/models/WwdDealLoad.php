<?php

namespace app\models;

use Yii;
use yii\db\Query;

/**
 * This is the model class for table "{{%deal_load}}".
 *
 * @property integer $id
 * @property integer $deal_id
 * @property integer $user_id
 * @property string $user_name
 * @property double $money
 * @property integer $create_time
 * @property integer $is_repay
 * @property integer $is_transfer
 * @property string $agent_bill_no
 */
class WwdDealLoad extends \yii\db\ActiveRecord
{
    public $dealinfo;  //业务使用
    public $more_list_money;       //业务使用 可以扩展model方法处理，后期优化
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%deal_load}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['deal_id', 'user_id', 'user_name', 'money', 'create_time', 'is_repay', 'is_transfer', 'agent_bill_no'], 'required'],
            [['deal_id', 'user_id', 'create_time', 'is_repay', 'is_transfer'], 'integer'],
            [['money'], 'number'],
            [['user_name', 'agent_bill_no'], 'string', 'max' => 50]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'deal_id' => 'Deal ID',
            'user_id' => 'User ID',
            'user_name' => 'User Name',
            'money' => 'Money',
            'create_time' => 'Create Time',
            'is_repay' => 'Is Repay',
            'is_transfer' => 'Is Transfer',
            'agent_bill_no' => 'Agent Bill No',
        ];
    }
    //关联查询
    public function getDeal(){
        return $this->hasOne(WwdDeal::className(),['id'=>'deal_id']); //字段名为引用表的字段 这里的andwhare 和oncondition 区别在于一个是on条件，一个是where的and条件
    }
    //指定用户的总投资金额
    public static function sumCapital($uid,$status = [1,2,4]){
        return  self::find()->joinWith('deal')->where([self::tableName().'.user_id'=>$uid])->andWhere(['in',WwdDeal::tableName().'.deal_status',$status])->sum('money');
    }
    //指定用户的总投资列表
    public static function allDealByuid($uid,$status = [1,2,4],$is_transfer = 0){
        $tableName = self::tableName();
        return  self::find()->joinWith('deal')->where([$tableName.'.user_id'=>$uid,$tableName.'.is_transfer'=>$is_transfer])->andWhere(['in',WwdDeal::tableName().'.deal_status',$status])->all();
    }
    //获取指定投标列表
    public static function getLoadListByDealid($dealid){
        return self::find()->where(['deal_id'=>$dealid])->orderBy('create_time DESC')->all();
    }
    //获取指定用户的投资记录(Profile)
    public static function getLoadRecord($uid,$dealStatus,$limit){
        if(empty($dealStatus)){
            return false;
        }
        $dealInfo = [];
        $result = [];
        $i  = 1;
        $loadRes = self::find()->where(['user_id'=>$uid,'is_transfer'=>0])->orderBy('create_time DESC')->all();
        foreach($loadRes as $lr){
            $dealId = $lr['deal_id'];
            if(!isset($dealInfo[$dealId])){
                $dealInfo[$dealId] = WwdDeal::findOne(['id'=>$dealId]);
            }
            $dealinfo = $dealInfo[$dealId];
            if(!in_array($dealinfo['deal_status'],$dealStatus)){
                continue;
            }
            $lr['dealinfo'] = $dealinfo;
            $result[] = $lr;
            if($i == $limit){
                return $result;
            }
            $i++;
        }
        return $result;
    }
    //获取待收本金
    public static function getWaitCapital($uid){
        $money  = 0;
        $dealStatus = [1,2,4];
        $dealInfo = [];
        $loadRes = self::find()->where(['user_id'=>$uid,'is_transfer'=>0])->all();
        foreach($loadRes as $lr){
            $dealId = $lr['deal_id'];
            if(!isset($dealInfo[$dealId])){
                $dealInfo[$dealId] = WwdDeal::findOne(['id'=>$dealId]);
            }
            $dealinfo = $dealInfo[$dealId];
            if(in_array($dealinfo['deal_status'],$dealStatus)){
                $money += $lr['money'];
            }
        }
        return $money;
    }
    //获取指定用户的全部利息
    public static function getTotalLixi($uid){
        $dealStatus = [1,2,4];
        $dealInfo = [];
        $result = [];
        $loadRes = self::find()->where(['user_id'=>$uid,'is_transfer'=>0])->all();
        foreach($loadRes as $lr){
            $dealId = $lr['deal_id'];
            if(!isset($dealInfo[$dealId])){
                $dealInfo[$dealId] = WwdDeal::findOne(['id'=>$dealId]);
            }
            $dealinfo = $dealInfo[$dealId];
            if(in_array($dealinfo['deal_status'],$dealStatus)){
                $lr['dealinfo'] = $dealinfo;
                $result[] = $lr;
            }
        }
        return $result;
    }
}
