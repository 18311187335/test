<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%message}}".
 *
 * @property integer $id
 * @property string $title
 * @property string $content
 * @property integer $create_time
 * @property integer $update_time
 * @property string $admin_reply
 * @property integer $admin_id
 * @property string $rel_table
 * @property integer $rel_id
 * @property integer $user_id
 * @property integer $pid
 * @property integer $is_effect
 */
class WwdMessage extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%message}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['title', 'content', 'create_time', 'update_time', 'admin_reply', 'admin_id', 'rel_table', 'rel_id', 'user_id', 'pid', 'is_effect'], 'required'],
            [['content', 'admin_reply'], 'string'],
            [['create_time', 'update_time', 'admin_id', 'rel_id', 'user_id', 'pid', 'is_effect'], 'integer'],
            [['title', 'rel_table'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'title' => 'Title',
            'content' => 'Content',
            'create_time' => 'Create Time',
            'update_time' => 'Update Time',
            'admin_reply' => 'Admin Reply',
            'admin_id' => 'Admin ID',
            'rel_table' => 'Rel Table',
            'rel_id' => 'Rel ID',
            'user_id' => 'User ID',
            'pid' => 'Pid',
            'is_effect' => 'Is Effect',
        ];
    }
}
