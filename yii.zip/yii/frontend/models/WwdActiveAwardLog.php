<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "{{%active_award_log}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property double $coupon
 * @property integer $is_del
 * @property integer $is_pass
 * @property integer $dateline
 */
class WwdActiveAwardLog extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%active_award_log}}';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['user_id', 'coupon', 'is_del', 'is_pass', 'dateline'], 'required'],
            [['user_id', 'is_del', 'is_pass', 'dateline'], 'integer'],
            [['coupon'], 'number']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'user_id' => 'User ID',
            'coupon' => 'Coupon',
            'is_del' => 'Is Del',
            'is_pass' => 'Is Pass',
            'dateline' => 'Dateline',
        ];
    }
}
