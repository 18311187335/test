﻿// JavaScript Document

$(document).ready(function(){
	$(".header_Box_Left a:first").css({"background":"none"});
	$(".Bid_Company_Info_Avds:last").css({"margin-right":"0px"});
	$(".Notice_List ul:last").css({"float":"right"});
});


$(document).ready(function() {
	$('.ContaintHydtNav01 li').hover(function(){
	$(this).toggleClass('DtHover');
	});
	
	$('.ContaintReport').hover(function(){
	$(this).toggleClass('ReportHover');
	});
	
	$('.ConSaleTparS_02 span').hover(function(){
	$(this).toggleClass('SaleHover');
	});
	
	$('.Con_Product_List_01').hover(function(){
	$(this).toggleClass('ProHover');
	});
});




/*数字递增*/
$(document).ready(function () {
	var s=1;
	$(".DetialQyzt_Info_Zt01 .DQyzt_T31").each(function() {
		$(this).children(".QyztNum").html(s);
		s=s+1;
    });
	
  });
  
 $(document).ready(function () {
	var s=1;
	$(".DetialBuy_Order_List_Nav01 .DetialBuy_L01 span").each(function() {
		$(this).children(".BuyNum").html(s);
		s=s+1;
    });
	
  });	


//tab切换
$(document).ready(function () {

	$('#ConSecondT02 a').click(function () {
	
		//reset all the items
		$('#ConSecondT02 a').removeClass('active');
		
		//set current item as active
		$(this).addClass('active');	
		
		//scroll it to the right position
		$('#ConSecondContent').scrollTo($(this).attr('rel'), 300);
		
		//disable click event
	    return false;		
	});	
	
});



$(function(){
$(".Flinks a:last").css({"padding-right":"0"});
$(".ContaintJgNav01 li:last").css({"padding-right":"0"});
$(".DetialQyzt_Table02:last").css({"border-bottom":"none"});
$(".DetialQyzt_Info_Zt01:last").css({"border-bottom":"none"});
$(".DetialBuy_Order_List_Nav01:last").css({"border-bottom":"none"});
$(".DetialListRight_Info_nav01 li:odd").css({"padding-left":"10px"});
$(".DetialBuy_Con_Info01 ul:last").css({"border-left":"1px solid #dadde4"});
$(".ConSafeNav_Company01 li:first").css({"margin-right":"12px"});
$(".ConSafeNav_Company01 li:eq(1)").css({"margin-right":"12px"});
$(".ConSafeNav_Company01 li:eq(3)").css({"margin-right":"12px"});
$(".ConSafeNav_Company01 li:eq(4)").css({"margin-right":"12px"});
$(".PeopleIntegral_List04 li:eq(3)").css({"border-right":"none"});
$(".PeopleIntegral_List04 li:last").css({"border-right":"none"});
});

/*下拉菜单*/
var timeout         = 100;
var closetimer		= 0;
var ddmenuitem      = 0;

function jsddm_open()
{	jsddm_canceltimer();
	jsddm_close();
	ddmenuitem = $(this).find('.MenuTpar04').eq(0).css('visibility', 'visible');}

function jsddm_close()
{	if(ddmenuitem) ddmenuitem.css('visibility', 'hidden');}

function jsddm_timer()
{	closetimer = window.setTimeout(jsddm_close, timeout);}

function jsddm_canceltimer()
{	if(closetimer)
	{	window.clearTimeout(closetimer);
		closetimer = null;}}

$(document).ready(function()
{	$('#Mainmenu > li').bind('mouseover', jsddm_open);
	$('#Mainmenu > li').bind('mouseout',  jsddm_timer);});

document.onclick = jsddm_close;


/*多级下拉菜单*/
(function($) {
    $.fn.menu = function(b) {
        var c,
        item,
        httpAdress;
        b = jQuery.extend({
            Speed: 500,
            autostart: 1,
            autohide: 1
        },
        b);
        c = $(this);
        item = c.children("ul").parent("li").children("p");
        httpAdress = window.location;
        item.addClass("inactive");
        function _item() {
            var a = $(this);
            if (b.autohide) {
                a.parent().parent().find(".active").parent("li").children("ul").slideUp(b.Speed / 1.2, 
                function() {
                    $(this).parent("li").children("p").removeAttr("class");
                    $(this).parent("li").children("p").attr("class", "inactive")
                })
            }
            if (a.attr("class") == "inactive") {
                a.parent("li").children("ul").slideDown(b.Speed, 
                function() {
                    a.removeAttr("class");
                    a.addClass("active")
                })
            }
            if (a.attr("class") == "active") {
                a.removeAttr("class");
                a.addClass("inactive");
                a.parent("li").children("ul").slideUp(b.Speed)
            }
        }
        item.unbind('click').click(_item);
        if (b.autostart) {
            c.children("p").each(function() {
                if (this.href == httpAdress) {
                    $(this).parent("li").parent("ul").slideDown(b.Speed, 
                    function() {
                        $(this).parent("li").children(".inactive").removeAttr("class");
                        $(this).parent("li").children("p").addClass("active")
                    })
                }
            })
        }
    }
})(jQuery);

/*展开收起*/
function displaycol(id,thisobj,msgid){
        var elemet = document.getElementById(id);
        var elemet2 = document.getElementById(thisobj);
        if(elemet.style.display == 'none')
        {
        if(document.getElementById('search_type')!=null){
          document.getElementById('search_type').value = "1";
        }
          elemet.style.display = 'block';
          elemet2.style.display='none'; 
         }else{
         if(document.getElementById('search_type')!=null){
          document.getElementById('search_type').value = "0";
         }
          elemet.style.display = 'none';
          elemet2.style.display='block';
         }
        
        var ajaxurl = APP_ROOT+"/index.php?ctl=uc_msg&act=msg_action_ajax";
    	$.ajax({
    		url: ajaxurl,
    		dataType: "json",
    		type: "POST",
    		data:"msgid="+msgid.toString()+"&action=read",
    		success: function(msg){
    			if(msg.status==1){
    				elemet2.style.fontWeight = "normal";
    			}
    		}
    	});	
        
        
    }



//JavaScript Document

$(document).ready(function(){
	$(".Notice_List ul:last").css({"float":"right"});
	$(".Reviews03 span:first").css({"margin-left":"0px"});
	$(".Reviews03 span:eq(5)").css({"margin-left":"0px"});
	$(".management09 p:last").css({"float":"right"});
	$(".management09 p:last").css({"padding-right":"8px"});
	$(".about_Content p:last").css({"padding-bottom":"30px"});
	$(".ReviewsTpar_02 span:last").css({"margin-left":"15px"});
	$(".ReviewsTpar_02 span:last").css({"margin-right":"3px"});
	$(".center_People_Right a:last").css({"margin-left":"10px"});

});

$(document).ready(function(){

	$('#reviews_Tab a').mouseover(function(){
		$(this).addClass("current").siblings().removeClass();
		$("#reviews_Tab_Reviews > ul").eq($("#reviews_Tab a").index(this)).show().siblings().hide();
	    });

	$('.AboutContentRight_Tabs a').mouseover(function(){
		$(this).addClass("TabHover").siblings().removeClass();
		$(".AboutContentRight_Tabs_Reviews > div").eq($(".AboutContentRight_Tabs a").index(this)).show().siblings().hide();
	    });

	$('#update_Code a').click(function(){
		$(this).addClass("traHover01").siblings().removeClass();
		$("#update_Code_Reviews01 > ul").eq($("#update_Code a").index(this)).show().siblings().hide();
	    });		
});


function incharge_money(obj){
	//先把非数字的都替换掉，除了数字和小数点
	obj.value = obj.value.replace(/[^\d.]/g,"");
	//必须保证第一个为数字而不是小数点	
	obj.value = obj.value.replace(/^\./g,"");
	//保证只有出现一个小数点而没有多个.
	obj.value = obj.value.replace(/\.{2,}/g,".");
	//保证小数点只出现一次，而不能出现两次以上
	obj.value = obj.value.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
	//保证小数点后只出现最多2个数字
	obj.value = (obj.value.match(/\d+(\.\d{0,2})?/)||[''])[0];
	
	var tmp = obj.value.split(".");
	var tmp_str = tmp[0].split("").reverse();
	
	var str = "";
	for(var i=0;i<tmp_str.length;i++){
		str += tmp_str[i];
		if(i%3==2 && i<tmp_str.length-1){
			str += ",";
		}
	}
	tmp_str = str.split("").reverse().join("");
	if(tmp[1]!=undefined){
		tmp_str += "."+tmp[1];
	}
	
	if(document.getElementById("incharge_money")!=null){
		document.getElementById("incharge_money").innerHTML = tmp_str;
	}
	
	if(document.getElementById("carry_money")!=null){
		document.getElementById("carry_money").innerHTML = tmp_str;
	}
	
	
}




function upPage(p,pageid){
	nowPage=p;
	//内容变换
	for (var i=0;i<j;i++){
	obj[i].style.display="none";
	}
	for (var i=p*listNum;i<(p+1)*listNum;i++){
	if(obj[i])
		obj[i].style.display="block";
	}
	//分页链接变换
	strS = '<a href="##" onclick="upPage(0,\''+pageid+'\')">首页</a>  ';
	var PageNum_2=PageNum%2==0?Math.ceil(PageNum/2)+1:Math.ceil(PageNum/2);
	var PageNum_3=PageNum%2==0?Math.ceil(PageNum/2):Math.ceil(PageNum/2)+1;
	var strC="",startPage,endPage;
	if (PageNum>=PagesLen) {
		startPage=0;
		endPage=PagesLen-1;
		}
	else if (nowPage<PageNum_2){
		startPage=0;endPage=PagesLen-1>PageNum?PageNum:PagesLen-1;
		}//首页
	else {
		startPage=nowPage+PageNum_3>=PagesLen?PagesLen-PageNum-1: nowPage-PageNum_2+1;
		var t=startPage+PageNum;
		endPage=t>PagesLen?PagesLen-1:t;
		}
	for (var i=startPage;i<=endPage;i++){
	 if (i==nowPage)
		 strC+='<span class="current">'+(i+1)+'</span> ';
	 else 
		 strC+='<a href="##" onclick="upPage('+i+',\''+pageid+'\')">'+(i+1)+'</a> ';
	}
	strE=' <a href="##" onclick="upPage('+(PagesLen-1)+',\''+pageid+'\')">尾页</a>  ';
	strE2=nowPage+1+"/"+PagesLen+"页"+"  共"+j+"条";
	document.getElementById(pageid).innerHTML=strS+strC+strE+strE2;
}


function zhuanpan_con_ajax(){
	if(document.getElementById("turning").value == 1){
		return false;
	}
	document.getElementById("turning").value = 1;

	$("#start_choujiang_button").unbind('click').css("cursor","default");
	
	$.ajax({

		url:APP_ROOT + "/index.php?ctl=active&act=choujiang&ajax=1",

		data:"",

		type:"POST",

		dataType:"json",

		success:function(result){
			if(result.status){
				var result2 = result.info;
				$("#start_choujiang").rotate({
					duration:3000,
					angle: 180,
					animateTo:1980+result2.angle,
					easing: $.easing.easeOutSine,
					callback: function(){
						if(result2.is_award == 0){
							$.showSuccess("很遗憾，您没有中奖。",function(){
								document.getElementById("turning").value = 0;
								$("#start_choujiang_button").unbind('click').css("cursor","pointer");
							});
						}else{
							$.showSuccess("恭喜您，您已中奖，奖品为"+result2.prize,function(){
								document.getElementById("turning").value = 0;
								$("#start_choujiang_button").unbind('click').css("cursor","pointer");
							});
						}
						document.getElementById("count").innerHTML = parseInt(document.getElementById("count").innerHTML,10)-1;
					}
				});
			}else{
				$.showErr(result.info,function(){
					if(result.jump){
						window.location.href = result.jump;
						}else{
							document.getElementById("turning").value = 0;
							$("#start_choujiang_button").unbind('click').css("cursor","pointer");
						}
					});
			}
		}

	});
	
}

function show_wechat(){
	var div = document.getElementById("Wechat");
	if(div.style.display == "block"){
		div.style.display = "none";
	}else{
		div.style.display = "block";
	}
}

function show_qqchat(val){
	if(val){
		document.getElementById("WechatInfo").style.display = "block";
	}else{
		document.getElementById("WechatInfo").style.display = "none";
	}
}

function show_wechat2(){
	var div = document.getElementById("Wechat_Info");
	if(div.style.display == "block"){
		div.style.display = "none";
	}else{
		div.style.display = "block";
	}
}

function show_qqchat2(val){
	if(val){
		document.getElementById("WechatInfo02").style.display = "block";
	}else{
		document.getElementById("WechatInfo02").style.display = "none";
	}
}

	
