/**
 * Created by King on 2015/7/23.
 */
function img_Over03() {
    var div = document.getElementById("product_Detial_Order01_Info");
    if (div.style.display == "none") {
        div.style.display = "block";
    }
}
function img_Over04() {
    var div = document.getElementById("product_Detial_Order01_Info");
    if (div.style.display == "block") {
        div.style.display = "none"
    }
}
function img_Over05() {
    var div = document.getElementById("product_Detial_Order01_Info01");
    if (div.style.display == "none") {
        div.style.display = "block";
    }
}
function img_Over06() {
    var div = document.getElementById("product_Detial_Order01_Info01");
    if (div.style.display == "block") {
        div.style.display = "none"
    }
}
function img_Over07() {
    var div = document.getElementById("product_Detial_Order02_Info");
    if (div.style.display == "none") {
        div.style.display = "block";
    }
}
function img_Over08() {
    var div = document.getElementById("product_Detial_Order02_Info");
    if (div.style.display == "block") {
        div.style.display = "none"
    }
}
function income(obj, rate, repay_time, maxmoney, repay_time_type) {
    obj.value = obj.value.replace(/\D/g, '');
    if (parseInt(obj.value, 10) > maxmoney) {
        obj.value = maxmoney;
    }
    if (repay_time_type == 1) {
        var val = obj.value * rate / 100 / 12 * repay_time;
    } else {
        var val = obj.value * rate / 100 / 365 * repay_time;
    }
    document.getElementById("income").innerHTML = val.toFixed(2);
    if (obj.value == "") {
        objvalue = 0;
    } else {
        objvalue = parseInt(obj.value, 10);
    }
}
function check_money(minmoney, maxmoney) {
    minmoney = parseInt(minmoney, 10);
    maxmoney = parseInt(maxmoney, 10);
    var loadmoney = document.getElementById("loadmoney").value;
    if (loadmoney == '输入您的投资金额') {
        $.showErr("请输入投标金额");
        return false;
    } else if (parseInt(loadmoney, 10) % minmoney != 0 && minmoney != 0) {
        $.showErr("请输入" + minmoney.toString() + "的整倍数");
        return false;
    } else if (parseInt(loadmoney, 10) < minmoney) {
        $.showErr("投资额度不能低于最低额度");
        return false;
    } else if (parseInt(loadmoney, 10) > maxmoney && maxmoney > 0) {
        $.showErr("投资额度不能高于最高额度");
        return false;
    } else if (parseInt(loadmoney, 10) > (parseFloat(document.getElementById("user_money").value) + parseFloat(document.getElementById("user_coupon").value))) {
        $.showErr("余额不够，请充值", function () {
            window.open(APP_ROOT + "/index.php?ctl=uc_money&act=incharge");
        });
        return false;
    }
}
var obj, j;
var page = 0;
var nowPage = 0;//当前页
var listNum = 10;//每页显示<ul>数
var PagesLen;//总页数
var PageNum = 4;//分页链接接数(5个)
function upPage(p,pageid){
    nowPage=p;
    //内容变换
    for (var i=0;i<j;i++){
        obj[i].style.display="none";
    }
    for (var i=p*listNum;i<(p+1)*listNum;i++){
        if(obj[i])
            obj[i].style.display="block";
    }
    //分页链接变换
    strS = '<a href="##" onclick="upPage(0,\''+pageid+'\')">首页</a>  ';
    var PageNum_2=PageNum%2==0?Math.ceil(PageNum/2)+1:Math.ceil(PageNum/2);
    var PageNum_3=PageNum%2==0?Math.ceil(PageNum/2):Math.ceil(PageNum/2)+1;
    var strC="",startPage,endPage;
    if (PageNum>=PagesLen) {
        startPage=0;
        endPage=PagesLen-1;
    }
    else if (nowPage<PageNum_2){
        startPage=0;endPage=PagesLen-1>PageNum?PageNum:PagesLen-1;
    }//首页
    else {
        startPage=nowPage+PageNum_3>=PagesLen?PagesLen-PageNum-1: nowPage-PageNum_2+1;
        var t=startPage+PageNum;
        endPage=t>PagesLen?PagesLen-1:t;
    }
    for (var i=startPage;i<=endPage;i++){
        if (i==nowPage)
            strC+='<span class="current">'+(i+1)+'</span> ';
        else
            strC+='<a href="##" onclick="upPage('+i+',\''+pageid+'\')">'+(i+1)+'</a> ';
    }
    strE=' <a href="##" onclick="upPage('+(PagesLen-1)+',\''+pageid+'\')">尾页</a>  ';
    strE2=nowPage+1+"/"+PagesLen+"页"+"  共"+j+"条";
    document.getElementById(pageid).innerHTML=strS+strC+strE+strE2;
}