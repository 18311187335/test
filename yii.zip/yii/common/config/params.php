<?php
return [
    'webdomain'=>'jiacaimao.aneng.cn',
    'webroot'=>'http://jiacaimao.aneng.cn',
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'support@example.com',
    'user.passwordResetTokenExpire' => 3600,
    'dealStats' => [    //项目状态
        1 => '投资中',
        2 => '还款中',
        3 => '已还款'
    ],
    'dealLimits' => [    //项目期限
        1 => '3个月以下',
        2 => '3-6个月',
        3 => '6-12个月',
        4 => '12个月以上'
    ],
    'profitRatios' => [ //项目收益
        1 => '8%以下',
        2 => '8%-12%',
        3 => '12-15%',
        4 => '15%以上'
    ],
    "point_fold"=>1,        //积分倍数
    "AUTH_KEY"=>"fanwe",
    "USER_VERIFY"=>1,
    'MANAGE_FEE'=>'0',              //管理费
    'MANAGE_IMPOSE_FEE_DAY1'=>'0.1',
    'MANAGE_IMPOSE_FEE_DAY2'=>'0.5',
    'IMPOSE_FEE_DAY1'=>'0.05',
    'IMPOSE_FEE_DAY2'=>'0.1',
    'PAGE_SIZE'=>10,
    'point_fold'=>1,                 //积分倍数
    "agent_user_id_pre" => "test", //绑定汇付宝的 agent_user_id前缀，后接用户id
    "code_pre" => "testaba",        //项目编号前缀，后接项目id
    "fangkuan_pre" => "fangkuan",  //项目放款编号前缀，后接项目id
    "tixian_pre" => "tixian",       //提现编号前缀，后接项目时间戳和uid
    "heepay_conf"=>[
        "P2PBindAgreeUser"=>"http://p.heepay.com/Account/P2PBindAgreeUser.aspx",//账户绑定
        "P2PUnbindUser"=>"http://p.heepay.com/Account/P2PUnbindUser.aspx",//账户解绑
        "P2PBindAgreeUserV2"=>"http://p.heepay.com/Account/P2PBindAgreeUserV2.aspx",//账户绑定新版本
        "P2PUpdateAgreeUserMobile"=>"https://p.heepay.com/Account/P2PUpdateAgreeUserMobile.aspx",//用户修改绑定手机号
        "P2PRealityAgreeUser"=>"http://p.heepay.com/Account/P2PRealityAgreeUser.aspx",//实名认证
        "P2PQueryReality"=>"http://p.heepay.com/Account/P2PQueryReality.aspx",//查询是否实名
        "TransitAgentToPerson"=>"https://www.heepay.com/P2P/TransitAgentToPerson.aspx",//商户迁移用户资金
        "P2PAgreeBankCharge"=>"http://p.heepay.com/Bank/P2PAgreeBankCharge.aspx",//生成用户充值地址
        "AgreeUserVoteProject"=>"https://www.heepay.com/P2P/AgreeUserVoteProject.aspx",//满标投资
        "AgreeAccountLendProject"=>"https://www.heepay.com/P2P/AgreeAccountLendProject.aspx",//满标放款
        "AgreeUserVoteTransferProject"=>"https://www.heepay.com/P2P/AgreeUserVoteTransferProject.aspx",//流转标投资
        "CancelProject"=>"https://www.heepay.com/P2P/CancelProject.aspx",//满标撤标
        "AgreeUserRepayment"=>"https://www.heepay.com/P2P/AgreeUserRepayment.aspx",//还款扣款
        "AddRepayDetail"=>"https://www.heepay.com/API/P2P/AddRepayDetail.aspx",//增加还款明细
        "AgreeAccountApplyExeRepayment"=>"https://www.heepay.com/P2P/AgreeAccountApplyExeRepayment.aspx",//申请执行还款
        "P2PCashBankManager"=>"http://p.heepay.com/Cash/P2PCashBankManager.aspx",//用户申请提现
        "QueryAgreeUserBalance"=>"https://www.heepay.com/P2P/QueryAgreeUserBalance.aspx",//用户可用余额查询
        "P2PAgentQueryUsers"=>"http://p.heepay.com/Account/P2PAgentQueryUsers.aspx",//商户分页查询绑定用户
        "AgentQueryRealities"=>"https://www.heepay.com/P2P/AgentQueryRealities.aspx",//商户分页查询实名数据
        "AgentQueryBankCharges"=>"https://www.heepay.com/P2P/AgentQueryBankCharges.aspx",//商户分页查询用户储值数据
        "AgentQueryProjects"=>"https://www.heepay.com/P2P/AgentQueryProjects.aspx",//商户分页查询投资项目
        "AgentQueryProjectMembers"=>"https://www.heepay.com/P2P/AgentQueryProjectMembers.aspx",//商户分页查询投资明细
        "AgentQueryRepayments"=>"https://www.heepay.com/P2P/AgentQueryRepayments.aspx",//商户分页查询还款批次
        "AgentQueryRepaymentDetails"=>"https://www.heepay.com/P2P/AgentQueryRepaymentDetails.aspx",//商户分页查询还款明细
        "AgentQueryFetchCashs"=>"https://www.heepay.com/P2P/AgentQueryFetchCashs.aspx",//商户分页查询提现
    ]
];
