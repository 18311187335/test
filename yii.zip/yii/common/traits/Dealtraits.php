<?php
/**
 * Created by PhpStorm.
 * User: King
 * Date: 2015/7/30
 * Time: 20:02
 */

namespace common\traits;

use app\models\WwdUser;

trait Dealtraits
{
    /**
     * 使用
     * use Dealtraits;//可直接引用$this->testt方法
     */

    public function testt(){
        $user = WwdUser::findAll(['id'=>5441]);
        var_dump($user);
    }
}