<?php

namespace common\includes;

use yii\web\UploadedFile;
use components\LuLu;
use components\helpers\TFileHelper;
use yii\base\InvalidParamException;

class CommonUtility
{

	public static function getYesNo($var = null)
	{
		$ret = ['1' => '是', '0' => '否'];
		if($var !== null)
		{
			return $ret[$var];
		}
		return $ret;
	}
	//用于时间转换【历史问题】
	public static function to_date($utc_time, $format = 'Y-m-d H:i:s'){
		if (empty ($utc_time )) {
			return '';
		}
		$time = $utc_time + date('Z'); //8小时秒数 PRC 与 GMT时区偏移
		return date ($format, $time );
	}
    //还原格式化后的时间戳
    public static function to_timespan($str, $format = 'Y-m-d H:i:s'){
        $time = intval(strtotime($str));
        if($time!=0)
            $time = $time - date('Z'); //8小时秒数 PRC 与 GMT时区偏移
        return $time;
    }
    //下个月时间戳
    public static function next_replay_month($time){
        return self::to_timespan(date("Y-m-d", strtotime('+1 month',$time)), "Y-m-d");
    }
    /**
     * 等额本息还款计算方式
     * $money 贷款金额
     * $rate 月利率
     * $remoth 还几个月
     * 返回  每月还款额
     */
    public static function pl_it_formula($money, $rate, $remoth){
        return $money * ($rate * pow(1 + $rate, $remoth) / (pow(1 + $rate, $remoth) - 1));
    }

    /**
     * 按月还款计算方式
     * $total_money 贷款金额
     * $rate 年利率
     * 返回月应该还多少利息
     */
    public static function av_it_formula($total_money, $rate)
    {
        return $total_money * $rate;
    }

    /**
     * 等额本息还款计算方式
     * $money 贷款金额
     * $rate 日利率
     * $remoth 还几天
     * 返回  每月还款额
     */
    public static function pl_it_formula_day($money, $rate, $remoth)
    {
        return $money * ($rate * pow(1 + $rate, $remoth) / (pow(1 + $rate, $remoth) - 1));
    }

    /**
     * 按月还款计算方式
     * $total_money 贷款金额
     * $rate 日利率
     * 返回月应该还多少利息
     */
    public static function av_it_formula_day($total_money, $rate, $day)
    {
        return $total_money * $rate * $day;
    }

	public static function getDataType($id = null)
	{
		$dataType = ['0' => '字符串', '1' => '数字', '2' => '布尔型', '3' => '日期', '4' => '数组', '5' => 'JSON'];
		
		if($id !== null)
		{
			return $dataType[$id];
		}
		
		return $dataType;
	}

	public static function getStatus($id = null)
	{
		$status = ['1' => '通过', '0' => '审核'];
		
		if($id !== null)
		{
			return $status[$id];
		}
		
		return $status;
	}

	public static function getTitleFormat($id = null)
	{
		$format = ['b' => '加粗', 'i' => '斜体', 'u' => '下划线', 's' => '删除线'];
		
		if($id !== null)
		{
			return $format[$id];
		}
		return $format;
	}

	public static function getTitleFormatValue($array)
	{
		if($array === null || ! is_array($array))
		{
			return '';
		}
		return implode(',', $array);
	}

	public static function getTitleFormatArray($var)
	{
		$format = '';
		if(is_string($var))
		{
			$format = $var;
		}
		else if(isset($var['title_format']))
		{
			$format = $var['title_format'];
		}
		
		return explode(',', trim($format, ','));
	}

	public static function formatTitle($title, $format)
	{
		$format = self::getTitleFormatArray($format);
		if(isset($format['b']))
		{
			$title = '<b>' . $title . '</b>';
		}
		if(isset($format['i']))
		{
			$title = '<i>' . $title . '</i>';
		}
		if(isset($format['u']))
		{
			$title = '<u>' . $title . '</u>';
		}
		if(isset($format['s']))
		{
			$title = '<s>' . $title . '</s>';
		}
		return $title;
	}


	public static function getFlagValue($var)
	{
		if(is_string($var))
		{
			$var = explode(',', $var);
		}
		if(! is_array($var))
		{
			return 0;
		}
		
		$ret = 0;
		foreach($var as $value)
		{
			$ret += intval($value);
		}
		return $ret;
	}

	public static function getTitlePic($var)
	{
		$titlePic = '';
		if(is_string($var))
		{
			$titlePic = $var;
		}
		else if(isset($var['title_pic']))
		{
			$titlePic = $var['title_pic'];
		}
		if(stripos($titlePic, 'http') === false)
		{
			return 'data/' . $titlePic;
		}
		return $titlePic;
	}
	
	// 碎片类型
	public static function getFragmentType($id = null)
	{
		$ret = ['1' => '代码碎片', '2' => '静态碎片', '3' => '动态碎片'];
		if($id !== null)
		{
			if(isset($ret[$id]))
			{
				return $ret[$id];
			}
			return '';
		}
		return $ret;
	}

	public static function uploadFile($name)
	{
		$uploadedFile = UploadedFile::getInstanceByName($name);
		
		if($uploadedFile === null || $uploadedFile->hasError)
		{
			return null;
		}
		
		$ymd = date("Ymd");
		
		$save_path = \Yii::getAlias('@data/attachment/image_test') . '/' . $ymd . "/";
		$save_url = 'attachment/image/' . $ymd . "/";
		
		if(! file_exists($save_path))
		{
			mkdir($save_path);
		}
		
		$file_name = $uploadedFile->getBaseName();
		$file_ext = $uploadedFile->getExtension();
		
		// 新文件名
		$new_file_name = date("YmdHis") . '_' . rand(10000, 99999) . '.' . $file_ext;
		
		$uploadedFile->saveAs($save_path . $new_file_name);
		
		return ['path' => $save_path, 'url' => $save_url, 'name' => $file_name, 'new_name' => $new_file_name, 'ext' => $file_ext];
	}

	private static $currentTheme = null;

	public static function getCurrentTheme()
	{
		if(self::$currentTheme == null)
		{
			// todo
			self::$currentTheme = 'default';
		}
		return self::$currentTheme;
	}

	public static function getThemeUrl($resource = null)
	{
		$currentTheme = self::getCurrentTheme();
		
		if($resource === null)
		{
			return LuLu::getWebUrl() . '/static/themes/' . $currentTheme . '/';
		}
		return LuLu::getWebUrl() . '/static/themes/' . $currentTheme . '/' . $resource;
	}

	public static function getThemePath($path = null)
	{
		$currentTheme = self::getCurrentTheme();
		
		$frontend = \Yii::getAlias('@frontend');
		
		if(is_array($path))
		{
			$dir = array_merge([$frontend, 'themes', $currentTheme], $path);
		}
		else if(is_string($path))
		{
			$dir = [$frontend, 'themes', $currentTheme, $path];
		}
		else
		{
			$dir = [$frontend, 'themes', $currentTheme];
		}
		
		return TFileHelper::buildPath($dir);
	}

	public static function getFrontViews($dir, $prefix)
	{
		$themePath = self::getThemePath($dir);
		
		return TFileHelper::getFiles($themePath, $prefix);
	}

	public static function getBackViews($dir=null, $prefix=null)
	{
		$backend = \Yii::getAlias('@backend');
		if($dir==null)
		{
			$pathArray = [$backend, 'views'];
		}
		else 
		{
			if(is_string($dir))
			{
				$pathArray = [$backend, 'views', $dir];
			}
			else if(is_array($dir))
			{
				$pathArray = array_merge([$backend, 'views'], $dir);
			}
		}
		return TFileHelper::getFiles($pathArray, $prefix);
	}

	public static function getFiles($dir = null, $prefix = null, $isBack = null)
	{
		$root = '';
		if($isBack === null)
		{
			$root = \Yii::getAlias('@webroot');
		}
		else if($isBack)
		{
			$root = \Yii::getAlias('@backend');
		}
		else
		{
			$root = \Yii::getAlias('@frontend');
		}
		
		if($dir !== null)
		{
			if(is_string($dir))
			{
				$pathArray = [$root, $dir];
			}
			else if(is_array($dir))
			{
				$pathArray = array_merge([$root], $dir);
			}
		}
		else 
		{
			$pathArray=[$root];
		}
		
		return TFileHelper::getFiles($pathArray, $prefix);
	}
	
	public static function getAttachUrl($url, $echo = true)
	{
		if($echo)
		{
			echo LuLu::getWebUrl() . '/data/attachment/' . $url;
		}
		return LuLu::getWebUrl() . '/data/attachment/' . $url;
	}
	
	public static function getCachedValue($cacheItem,$cacheKey=null)
	{
		$cache = LuLu::getAppParam($cacheItem);
	
		if($cache === null)
		{
			throw new InvalidParamException('cache item:' . $cacheItem . ' does not exist');
		}
	
		if($cacheKey === null)
		{
			return $cache;
		}
		
		if(array_key_exists($cacheKey,$cache))
		{
			return $cache[$cacheKey];
		}
	
		throw new InvalidParamException('cache key:' . $cacheKey .'('. $cacheItem . '} does not exist');
	}
	// 隐藏用户名
	public static function name_hide($name){
		$username = mb_substr($name,0,1,"utf-8");
		if(strlen($username)==1){
			$username .= mb_substr($name, 1,1,"utf-8");
		}
		$username .= str_repeat("*",mb_strlen($name,"utf-8")-mb_strlen($username,"utf-8"));
		return $username;
	}
	/**
	 * 检查身份证
	 * 0失败1成功
	 */
	public static function getIDCardInfo($IDCard){
		$iW = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
		$szVerCode = "10X98765432";
		$sum = 0;
		for ($i = 0; $i < 17; $i++) {
			$sum += $IDCard[$i] * $iW[$i];
		}
		$iy = $sum % 11;
		$verifyBit = $szVerCode[$iy];
		if ($verifyBit == $IDCard[17]) {
			return 1;
		} else {
			return 0;
		}
	}
}
