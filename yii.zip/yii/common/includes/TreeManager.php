<?php

namespace common\includes;

use components\base\BaseActiveRecord;
use yii\helpers\Html;
use components\LuLu;
use yii\base\InvalidParamException;
use components\helpers\TStringHelper;
use yii\base\Object;
use components\helpers\TFileHelper;

class TreeManager 
{
	public static function getParents($data,$id,$parentKey='parent_id')
	{
		
	}
	
}