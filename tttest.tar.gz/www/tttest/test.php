<?php
echo "Hello World";
file_get_contents("http://www.baidu.com");
preg_match_all('/\<img\s+src=.*?\s*\/?\>/i',$str, $images);

$imgs="";
    
foreach($images[0] as $img){
    $imgs.=$img.'<br>';
}

 echo file_put_contents("test.txt", $imgs);
