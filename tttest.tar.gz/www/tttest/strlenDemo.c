#include<string.h>
#include<stdio.h>
int main(void){
    char *s="GoldenGlobalView";
    printf("%s has %d chars",s,strlen(s));
    return 0;
}
