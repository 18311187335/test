/*
*fread 次数1000000  buffer大小为offset*1
*/
#include <stdio.h>
#include <string.h>
int main(){
    FILE *fp;
    char msg[]="fileContent";
    char buf[20];
    fp = fopen("tttt","w+");
    if(NULL == fp){
        printf("the file doesn't exist!\n");
        return -1;
    }
    int offset=sizeof(msg);
    int m=1;
    for(m=1;m<1000000;m++){
        fread(buf,offset*1,1,fp);
    }

    // fseek(fp,0,SEEK_SET);
    // fread(buf,1,1,fp);
    // buf[strlen(msg)]='\0';
    // printf("buf = %s\n",buf);
    // printf("strlen(buf)=%d\n",strlen(buf));
    return 0;
}
