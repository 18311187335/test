//fread size=10
#include <stdio.h>
#include <string.h>
int main(void){
FILE *stream;
    char buf[20];
    int size=10;
    stream=fopen("tttt","w+");
    while(!feof(stream)){
        fread(buf,size,1,stream);
    }
fclose(stream);
    return 0;
}
