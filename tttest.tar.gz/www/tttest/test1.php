<?php
$str = 'a1234'; 
if (preg_match("^[a-zA-Z0-9]{4,16}$", $str)) { 
    echo "验证通过";}else { 
        echo "验证失败";}?> 

