<?php
header("Content-Type: text/plain");
set_time_limit(0);
$infoString = "Hello World";
$n=0;
while( isset($infoString) )
{
echo $infoString.$n."\n";
$n++;
sleep(5);
}
