#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>  //包含了Linux C 中的函数getcwd()
#define FILEPATH_MAX (80)
int main(){
    char *twd = getcwd(NULL,0);
    printf("%s\r\n",twd);
    return 0;  
} 
