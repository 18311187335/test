#include <stdio.h>
#include <string.h>
int main(){
    FILE *fp;
    char msg[]="fileContent";
    fp = fopen("tttt","w+");
    if(NULL == fp){
        printf("the file doesn't exist!\n");
        return -1;
    }
    int offset=sizeof(msg)*10;
    int n;
    for(n=1;n<1000000;n++){
        fwrite(msg,offset,1,fp);
    }
    return 0;
}
