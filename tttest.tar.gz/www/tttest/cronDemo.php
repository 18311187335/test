<?php
$num =mt_rand(1,1000);
file_put_contents("test.txt",md5($num)."\n",FILE_APPEND);
